import { Router, type Request, type Response } from "express";
import { createHash } from "crypto";
import { Readable } from "stream";
import { logger } from "../lib/logger";

const router = Router();

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const API_BASE = "https://api.meowtv.ru";
const DECRYPTION_KEY = "9b7e3d1a4f6c2e8d0a5f1c7b3e9d4a6f";
const TMDB_KEY = "adc48d20c0956934fb224de5c40bb85d";

const SERVERS = [
  { id: "lynx", label: "Lynx" },
  { id: "pseudo", label: "Pseudo" },
  { id: "tik", label: "TCloud" },
  { id: "ipcloud", label: "IPCloud" },
  { id: "v5:Hindi", label: "Hindi" },
  { id: "v4:Hindi", label: "Hindi v2" },
  { id: "v6:Hindi", label: "Hindi v3" },
];

const MANIFEST = {
  id: "community.meowtv.addon",
  version: "1.4.0",
  name: "MeowTV",
  description:
    "Streams from MeowTV.ru — Lynx, Pseudo, TCloud, IPCloud, English, Hindi, Hindi v2, Hindi v3",
  logo: "https://meowtv.ru/favicon.ico",
  background:
    "https://image.tmdb.org/t/p/original/jlGmlFOcfo8n5tURmhC7YVd4Iyy.jpg",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: [],
  behaviorHints: { adult: false, configurable: false },
};

function setCors(res: Response) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
}

// ─── Determine the public base URL for this server ───────────────────────────

function getServerBase(req: Request): string {
  const host = req.get("x-forwarded-host") || req.get("host") || "";
  const proto = req.get("x-forwarded-proto") || req.protocol || "https";
  return `${proto}://${host}`;
}

// ─── URL type detection ───────────────────────────────────────────────────────

function isDirectVideo(url: string): boolean {
  const path = (url.split("?")[0] ?? "").toLowerCase();
  return (
    path.endsWith(".mp4") ||
    path.endsWith(".mkv") ||
    path.endsWith(".webm") ||
    path.endsWith(".avi") ||
    path.endsWith(".mov")
  );
}

function isHlsPlaylist(url: string): boolean {
  const path = (url.split("?")[0] ?? "").toLowerCase();
  return path.endsWith(".m3u8") || path.endsWith(".txt");
}

// ─── Proxy URL builders ───────────────────────────────────────────────────────

interface RefetchMeta {
  type: "movie" | "series";
  imdb: string;
  server: string;
  season?: number;
  episode?: number;
}

function makeM3u8ProxyUrl(
  serverBase: string,
  targetUrl: string,
  headers: Record<string, string> | undefined,
  meta?: RefetchMeta
): string {
  const u = Buffer.from(targetUrl).toString("base64url");
  const h =
    headers && Object.keys(headers).length > 0
      ? "&h=" + Buffer.from(JSON.stringify(headers)).toString("base64url")
      : "";
  let m = "";
  if (meta) {
    m += `&t=${encodeURIComponent(meta.type)}&i=${encodeURIComponent(meta.imdb)}&s=${encodeURIComponent(meta.server)}`;
    if (meta.season !== undefined) m += `&sn=${meta.season}`;
    if (meta.episode !== undefined) m += `&ep=${meta.episode}`;
  }
  return `${serverBase}/stremio/proxy.m3u8?u=${u}${h}${m}`;
}

function makeBinaryProxyUrl(
  serverBase: string,
  targetUrl: string,
  headers: Record<string, string> | undefined
): string {
  const u = Buffer.from(targetUrl).toString("base64url");
  const h =
    headers && Object.keys(headers).length > 0
      ? "&h=" + Buffer.from(JSON.stringify(headers)).toString("base64url")
      : "";
  return `${serverBase}/stremio/proxy?u=${u}${h}`;
}

// ─── Shared fetch helper ──────────────────────────────────────────────────────

function buildUpstreamHeaders(
  extra: Record<string, string>
): Record<string, string> {
  return {
    "User-Agent": UA,
    // Default headers required by MeowTV CDN partners.
    // Per-stream headers from decrypted data override these.
    Referer: "https://meowtv.ru/",
    Origin: "https://meowtv.ru",
    ...extra,
  };
}

// ─── Binary proxy — streams ANY upstream resource without text processing ─────
//
// Used for:
//   · AES-128 encryption keys  (16 binary bytes — MUST NOT go through text proxy)
//   · Video segments (.ts)     (large binary — text proxy would OOM the server)
//   · Any other binary assets
//
// Route:  GET /stremio/proxy?u=<base64url-url>[&h=<base64url-headers-json>]

router.get(
  "/proxy",
  async (req: Request, res: Response): Promise<void> => {
    setCors(res);

    const encUrl = req.query["u"] as string | undefined;
    const encHeaders = req.query["h"] as string | undefined;

    if (!encUrl) {
      res.status(400).send("Missing u parameter");
      return;
    }

    let targetUrl: string;
    let extraHeaders: Record<string, string> = {};

    try {
      targetUrl = Buffer.from(encUrl, "base64url").toString("utf-8");
    } catch {
      res.status(400).send("Invalid u parameter");
      return;
    }

    if (encHeaders) {
      try {
        extraHeaders = JSON.parse(
          Buffer.from(encHeaders, "base64url").toString("utf-8")
        ) as Record<string, string>;
      } catch {
        // ignore bad headers encoding
      }
    }

    try {
      const upstream = await fetch(targetUrl, {
        headers: buildUpstreamHeaders(extraHeaders),
      });

      if (!upstream.ok) {
        res.status(502).send(`Upstream ${upstream.status}`);
        return;
      }

      const ct = upstream.headers.get("content-type");
      if (ct) res.setHeader("Content-Type", ct);
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

      if (!upstream.body) {
        res.end();
        return;
      }

      // Stream binary body directly — never buffer the whole thing
      const nodeStream = Readable.fromWeb(
        upstream.body as import("stream/web").ReadableStream
      );
      nodeStream.pipe(res);
    } catch (e) {
      logger.warn({ err: e, targetUrl }, "Binary proxy error");
      if (!res.headersSent) res.status(500).send("Proxy error");
    }
  }
);

// ─── HLS text proxy — rewrites M3U8 playlist URLs at every level ─────────────
//
// Handles .m3u8 and .txt HLS playlists. Rewrites:
//   · Sub-playlist lines   → chained through this same proxy (headers propagate)
//   · Segment lines (.ts)  → through binary proxy (so CDN gets required headers)
//   · EXT-X-KEY URI=       → through binary proxy (preserves binary key integrity)
//
// Route:  GET /stremio/proxy.m3u8?u=<base64url-url>[&h=<base64url-headers-json>]

router.get(
  "/proxy.m3u8",
  async (req: Request, res: Response): Promise<void> => {
    setCors(res);

    const encUrl = req.query["u"] as string | undefined;
    const encHeaders = req.query["h"] as string | undefined;

    if (!encUrl) {
      res.status(400).send("Missing u parameter");
      return;
    }

    let targetUrl: string;
    let extraHeaders: Record<string, string> = {};

    try {
      targetUrl = Buffer.from(encUrl, "base64url").toString("utf-8");
    } catch {
      res.status(400).send("Invalid u parameter");
      return;
    }

    if (encHeaders) {
      try {
        extraHeaders = JSON.parse(
          Buffer.from(encHeaders, "base64url").toString("utf-8")
        ) as Record<string, string>;
      } catch {
        // ignore bad headers encoding
      }
    }

    // Optional metadata for on-404 stream refresh (English CDN tokens expire quickly)
    const refetchType = req.query["t"] as string | undefined;
    const refetchImdb = req.query["i"] as string | undefined;
    const refetchServer = req.query["s"] as string | undefined;
    const refetchSeason = req.query["sn"]
      ? parseInt(req.query["sn"] as string)
      : undefined;
    const refetchEpisode = req.query["ep"]
      ? parseInt(req.query["ep"] as string)
      : undefined;
    const hasRefetchParams = !!(refetchType && refetchImdb && refetchServer);

    const serverBase = getServerBase(req);

    // Retry loop: attempt with cached URL first; on 404 re-fetch a fresh stream URL once.
    let currentUrl = targetUrl;
    let currentHeaders = extraHeaders;
    let attempt = 0;

    while (attempt < 2) {
      attempt++;

      let upstream: globalThis.Response;
      try {
        upstream = await fetch(currentUrl, {
          headers: buildUpstreamHeaders(currentHeaders),
        });
      } catch (e) {
        logger.warn({ err: e, targetUrl: currentUrl }, "HLS proxy fetch error");
        if (!res.headersSent) res.status(500).send("Proxy error");
        return;
      }

      if (!upstream.ok) {
        if (upstream.status === 404 && attempt === 1 && hasRefetchParams) {
          // The CDN token has expired — re-fetch a fresh stream URL and retry.
          try {
            const freshTmdbId = await imdbToTmdb(
              refetchImdb!,
              refetchType! as "movie" | "series"
            );
            if (freshTmdbId) {
              const freshData = await fetchServerStream(
                refetchType! as "movie" | "series",
                freshTmdbId,
                refetchServer!,
                refetchSeason,
                refetchEpisode
              );
              if (freshData?.url && !isDirectVideo(freshData.url)) {
                logger.info(
                  { server: refetchServer, imdb: refetchImdb },
                  "M3U8 proxy: CDN token expired — refreshed stream URL"
                );
                currentUrl = freshData.url;
                currentHeaders = freshData.headers ?? {};
                continue;
              }
            }
          } catch (e) {
            logger.warn(
              { err: e, server: refetchServer },
              "M3U8 proxy: stream refresh failed"
            );
          }
        }
        res.status(502).send(`Upstream ${upstream.status}`);
        return;
      }

      // Safety check: if upstream returns binary/video content instead of text
      // (e.g. the URL turned out to be a direct MP4), stream it as binary rather
      // than trying to read it as text — which would OOM-kill the server.
      const ct = upstream.headers.get("content-type") ?? "";
      const ctLower = ct.toLowerCase();
      const looksLikeText =
        ctLower.includes("mpegurl") ||
        ctLower.includes("text/") ||
        ctLower.includes("application/x-mpegurl") ||
        ct === "";

      if (!looksLikeText) {
        // Unexpected binary — stream through binary-safe path
        logger.warn(
          { targetUrl: currentUrl, ct },
          "M3U8 proxy received non-text content, falling back to binary stream"
        );
        res.setHeader("Content-Type", ct);
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        if (upstream.body) {
          const nodeStream = Readable.fromWeb(
            upstream.body as import("stream/web").ReadableStream
          );
          nodeStream.pipe(res);
        } else {
          res.end();
        }
        return;
      }

      const body = await upstream.text();

      // Use the FINAL URL after redirects as the base for relative URL resolution.
      // This fixes servers like Hindi v2 where lizer123.site 302-redirects to a CDN:
      // without this fix, relative segment paths resolve against lizer123.site instead
      // of the actual CDN, producing broken segment URLs.
      const effectiveUrl = upstream.url || currentUrl;
      const lastSlash = effectiveUrl.lastIndexOf("/");
      const base = effectiveUrl.slice(0, lastSlash + 1);
      const origin = new URL(effectiveUrl).origin;

      function resolveAbsolute(href: string): string {
        const t = href.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (t.startsWith("//")) return "https:" + t;
        if (t.startsWith("/")) return origin + t;
        return base + t;
      }

      // Rewrite M3U8 line-by-line using tag context.
      // Using tag context (not just URL extension) correctly handles cases where
      // variant playlist URLs don't end in .m3u8 — e.g. lizer123.site wraps paths
      // in base64, so #EXT-X-STREAM-INF URLs end in "==" not ".m3u8".
      //
      // Rules:
      //   · URL after #EXT-X-STREAM-INF / #EXT-X-I-FRAME-STREAM-INF → M3U8 proxy
      //   · URL after #EXTINF → binary proxy (segment)
      //   · URL after other tags / no tag → fallback to extension detection
      //   · URI= inside tag lines → binary proxy (keys, init segments)
      const rawLines = body.split(/\r?\n/);
      const rewrittenLines: string[] = [];
      let lastTag = "";

      for (const rawLine of rawLines) {
        const trimmed = rawLine.trim();

        if (!trimmed) {
          rewrittenLines.push(rawLine);
          continue;
        }

        if (trimmed.startsWith("#")) {
          lastTag = trimmed;
          // Rewrite URI= in tag lines (EXT-X-KEY, EXT-X-MAP, etc.) → binary proxy
          const rewrittenTag = rawLine.replace(/URI="([^"]+)"/g, (_m, uri: string) => {
            return `URI="${makeBinaryProxyUrl(serverBase, resolveAbsolute(uri), currentHeaders)}"`;
          });
          rewrittenLines.push(rewrittenTag);
        } else {
          // URL line — determine type from tag context + URL extension
          const absUrl = resolveAbsolute(trimmed);
          const lowerPath = (absUrl.split("?")[0] ?? "").toLowerCase();

          const isPlaylist =
            lastTag.startsWith("#EXT-X-STREAM-INF") ||
            lastTag.startsWith("#EXT-X-I-FRAME-STREAM-INF") ||
            lowerPath.endsWith(".m3u8") ||
            lowerPath.endsWith(".txt");

          if (isPlaylist) {
            rewrittenLines.push(makeM3u8ProxyUrl(serverBase, absUrl, currentHeaders));
          } else {
            rewrittenLines.push(makeBinaryProxyUrl(serverBase, absUrl, currentHeaders));
          }

          lastTag = ""; // tag consumed by its URL
        }
      }

      const rewritten = rewrittenLines.join("\n");

      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.send(rewritten);
      return;
    }
    // All retry attempts exhausted without a successful response
    if (!res.headersSent) res.status(502).send("Upstream 404");
  }
);

// ─── Altcha proof-of-work solver ─────────────────────────────────────────────

interface AltchaChallenge {
  algorithm: string;
  challenge: string;
  salt: string;
  maxnumber: number;
  signature: string;
}

function solveAltcha(c: AltchaChallenge): string {
  for (let n = 0; n <= c.maxnumber; n++) {
    const hash = createHash("sha256")
      .update(c.salt + n.toString())
      .digest("hex");
    if (hash === c.challenge) {
      return Buffer.from(
        JSON.stringify({
          algorithm: c.algorithm,
          challenge: c.challenge,
          number: n,
          salt: c.salt,
          signature: c.signature,
        })
      ).toString("base64");
    }
  }
  throw new Error("Failed to solve altcha within maxnumber");
}

// ─── Fresh ticket per request (tickets are single-use) ───────────────────────

async function getFreshTicket(): Promise<string> {
  const challengeRes = await fetch(`${API_BASE}/altcha/challenge`, {
    headers: {
      "User-Agent": UA,
      Origin: "https://meowtv.ru",
      Referer: "https://meowtv.ru/",
    },
  });
  if (!challengeRes.ok) throw new Error("Challenge fetch failed");
  const challengeData = (await challengeRes.json()) as AltchaChallenge;
  const altcha = solveAltcha(challengeData);

  const ticketRes = await fetch(`${API_BASE}/streams/ticket`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": UA,
      Origin: "https://meowtv.ru",
      Referer: "https://meowtv.ru/",
    },
    body: JSON.stringify({ altcha }),
  });
  if (!ticketRes.ok) throw new Error("Ticket fetch failed");
  const { ticket } = (await ticketRes.json()) as { ticket: string };
  return ticket;
}

// ─── Stream decryption ────────────────────────────────────────────────────────

interface EncryptedStream {
  n: string;
  d: string;
}

interface StreamData {
  url: string;
  language: string;
  headers?: Record<string, string>;
}

function decryptStream(enc: EncryptedStream): StreamData {
  const keyBytes = createHash("sha256")
    .update(DECRYPTION_KEY + enc.n)
    .digest();
  const dataBytes = Buffer.from(enc.d, "base64");
  const result = Buffer.allocUnsafe(dataBytes.length);
  for (let i = 0; i < dataBytes.length; i++) {
    result[i] = dataBytes[i]! ^ keyBytes[i % keyBytes.length]!;
  }
  return JSON.parse(result.toString("utf-8")) as StreamData;
}

// ─── IMDB → TMDB ID conversion ───────────────────────────────────────────────

// Only successful (non-null) lookups are cached.
// Failed/missing results are NOT cached so they are retried on the next request.
// This prevents a transient API error or rate-limit from permanently blacklisting a title.
const tmdbCache = new Map<string, number>();

async function imdbToTmdb(
  imdbId: string,
  type: "movie" | "series"
): Promise<number | null> {
  const cacheKey = `${type}:${imdbId}`;
  const cached = tmdbCache.get(cacheKey);
  if (cached !== undefined) return cached;

  try {
    const res = await fetch(
      `https://api.themoviedb.org/3/find/${imdbId}?external_source=imdb_id&api_key=${TMDB_KEY}`,
      { headers: { "User-Agent": UA } }
    );
    if (!res.ok) return null;
    const data = (await res.json()) as {
      movie_results: Array<{ id: number }>;
      tv_results: Array<{ id: number }>;
    };
    const id =
      type === "movie"
        ? (data.movie_results?.[0]?.id ?? null)
        : (data.tv_results?.[0]?.id ?? null);
    // Only cache when we actually got a valid ID
    if (id !== null) tmdbCache.set(cacheKey, id);
    return id;
  } catch {
    return null;
  }
}

// ─── Fetch one server's stream ────────────────────────────────────────────────

async function fetchServerStream(
  type: "movie" | "series",
  tmdbId: number,
  serverId: string,
  season?: number,
  episode?: number
): Promise<StreamData | null> {
  try {
    const ticket = await getFreshTicket();
    const mediaType = type === "movie" ? "movie" : "tv";
    const path =
      type === "movie"
        ? `/streams/movie/${tmdbId}?s=${encodeURIComponent(serverId)}`
        : `/streams/tv/${tmdbId}/${season}/${episode}?s=${encodeURIComponent(serverId)}`;

    const res = await fetch(`${API_BASE}${path}`, {
      headers: {
        "User-Agent": UA,
        Origin: "https://meowtv.ru",
        Referer: `https://meowtv.ru/play/${mediaType}/${tmdbId}`,
        "x-stream-ticket": ticket,
      },
    });

    if (!res.ok) return null;

    const enc = (await res.json()) as EncryptedStream;
    if (!enc.n || !enc.d) return null;
    return decryptStream(enc);
  } catch (e) {
    logger.warn({ err: e, serverId }, "Stream fetch failed");
    return null;
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────────

router.get("/manifest.json", (_req: Request, res: Response) => {
  setCors(res);
  res.json(MANIFEST);
});


router.get(
  "/stream/:type/:id.json",
  async (req: Request, res: Response): Promise<void> => {
    setCors(res);

    const rawType = req.params["type"] as string;
    const rawId = Array.isArray(req.params["id"])
      ? req.params["id"][0]!
      : (req.params["id"] as string);

    if (!rawType || !rawId) {
      res.json({ streams: [] });
      return;
    }

    const isMovie = rawType === "movie";
    const isSeries = rawType === "series";
    if (!isMovie && !isSeries) {
      res.json({ streams: [] });
      return;
    }

    let imdbId: string;
    let season: number | undefined;
    let episode: number | undefined;

    if (isSeries) {
      const parts = rawId.split(":");
      if (parts.length < 3) {
        res.json({ streams: [] });
        return;
      }
      imdbId = parts[0]!;
      season = parseInt(parts[1]!, 10);
      episode = parseInt(parts[2]!, 10);
    } else {
      imdbId = rawId;
    }

    if (!imdbId.startsWith("tt")) {
      res.json({ streams: [] });
      return;
    }

    logger.info({ rawType, rawId }, "MeowTV stream request");

    const type = isMovie ? "movie" : "series";
    const tmdbId = await imdbToTmdb(imdbId, type);
    if (!tmdbId) {
      logger.warn({ imdbId }, "TMDB ID not found");
      res.json({ streams: [] });
      return;
    }

    logger.info({ imdbId, tmdbId }, "TMDB ID resolved");

    const serverBase = getServerBase(req);

    const results = await Promise.allSettled(
      SERVERS.map((srv) =>
        fetchServerStream(type, tmdbId, srv.id, season, episode).then(
          (data) => ({ label: srv.label, serverId: srv.id, data })
        )
      )
    );

    const streams: Array<{
      name: string;
      title: string;
      url: string;
      behaviorHints: Record<string, unknown>;
    }> = [];

    for (const result of results) {
      if (result.status !== "fulfilled") continue;
      const { label, serverId, data } = result.value;
      if (!data?.url) continue;

      let streamUrl: string;
      let behaviorHints: Record<string, unknown>;

      if (isDirectVideo(data.url)) {
        // Direct video file (e.g. MP4 from Lynx/Hindi):
        // Pass straight to Stremio with proxyHeaders so ExoPlayer injects the
        // required Referer. Do NOT route through the text proxy — it would try
        // to read a gigabyte MP4 as text and OOM-kill the server.
        const hdrs: Record<string, string> = {
          "User-Agent": UA,
          Referer: "https://meowtv.ru/",
          ...(data.headers ?? {}),
        };
        streamUrl = data.url;
        behaviorHints = { notWebReady: true, proxyHeaders: { request: hdrs } };
        logger.info({ label, url: data.url.slice(0, 80) }, "Direct video stream");
      } else {
        // HLS stream for all other servers — route through our proxy which:
        //   1. Injects Referer/Origin headers server-side
        //   2. Rewrites sub-playlist URLs to chain through the proxy
        //   3. Rewrites segment & key URLs through the binary proxy
        //   4. Re-fetches a fresh stream URL on 404 (token expiry)
        streamUrl = makeM3u8ProxyUrl(serverBase, data.url, data.headers, {
          type,
          imdb: imdbId,
          server: serverId,
          season,
          episode,
        });
        behaviorHints = { notWebReady: true };
        logger.info({ label, url: data.url.slice(0, 80) }, "HLS stream (proxied)");
      }

      streams.push({
        name: `MeowTV — ${label}`,
        title: label,
        url: streamUrl!,
        behaviorHints: behaviorHints!,
      });
    }

    logger.info({ count: streams.length }, "Streams resolved");
    res.json({ streams });
  }
);

router.options("/{*path}", (_req: Request, res: Response) => {
  setCors(res);
  res.sendStatus(200);
});

export default router;
