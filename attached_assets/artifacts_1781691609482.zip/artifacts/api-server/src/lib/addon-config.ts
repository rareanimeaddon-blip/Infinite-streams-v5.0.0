import { readFileSync, writeFileSync, existsSync } from "fs";
import { fileURLToPath } from "url";
import path from "path";
import { logger } from "./logger.js";

const CONFIG_PATH = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "../../addon-config.json",
);

interface AddonConfig {
  kartoonsToken: string;
  kartoonsBase: string;
  updatedAt?: string;
}

const DEFAULT_CONFIG: AddonConfig = {
  kartoonsToken:
    process.env.KARTOONS_TOKEN ?? "DNU1ZBzyTpwPldcjg09_RBKp5KgrQaMv0tdqDr9SX48",
  kartoonsBase: "https://api.kartoons.me/api/stremio",
};

let _config: AddonConfig | null = null;

export function getAddonConfig(): AddonConfig {
  if (_config) return _config;

  try {
    if (existsSync(CONFIG_PATH)) {
      const raw = readFileSync(CONFIG_PATH, "utf-8");
      _config = { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
      logger.info({ configPath: CONFIG_PATH }, "loaded addon config from disk");
      return _config;
    }
  } catch (err) {
    logger.warn({ err }, "failed to read addon config, using defaults");
  }

  _config = { ...DEFAULT_CONFIG };
  return _config;
}

export function saveAddonConfig(updates: Partial<AddonConfig>): AddonConfig {
  const current = getAddonConfig();
  _config = { ...current, ...updates, updatedAt: new Date().toISOString() };

  try {
    writeFileSync(CONFIG_PATH, JSON.stringify(_config, null, 2), "utf-8");
    logger.info({ configPath: CONFIG_PATH }, "saved addon config to disk");
  } catch (err) {
    logger.error({ err }, "failed to save addon config");
  }

  return _config;
}

export function parseManifestUrl(
  manifestUrl: string,
): { base: string; token: string } | null {
  try {
    const u = new URL(manifestUrl);
    const token = u.searchParams.get("token");
    if (!token) return null;

    const base = `${u.protocol}//${u.host}${u.pathname.replace("/manifest.json", "")}`;
    return { base, token };
  } catch {
    return null;
  }
}
