import NodeCache from "node-cache";

const cache = new NodeCache({ stdTTL: 3600, checkperiod: 600 });

export function getCache<T>(key: string): T | undefined {
  return cache.get<T>(key);
}

export function setCache<T>(key: string, value: T, ttlSeconds = 3600): void {
  cache.set(key, value, ttlSeconds);
}

export function deleteCache(key: string): void {
  cache.del(key);
}
