import axios from "axios";
import { logger } from "./logger.js";

let challengeToken: string | null = null;
let challengeTokenExpiry: number | null = null;

const KARTOONS_API = "https://api.kartoons.me/api";

export function getChallengeToken(): string | null {
  if (challengeToken && challengeTokenExpiry && Date.now() < challengeTokenExpiry) {
    return challengeToken;
  }
  return null;
}

export function setChallengeToken(token: string, expiresInMs = 3600000) {
  challengeToken = token;
  challengeTokenExpiry = Date.now() + expiresInMs;
  logger.info({ expiresAt: new Date(challengeTokenExpiry).toISOString() }, "challenge token stored");
}

export function clearChallengeToken() {
  challengeToken = null;
  challengeTokenExpiry = null;
}

export async function verifyChallengeWithTurnstile(turnstileToken: string): Promise<string | null> {
  try {
    const res = await axios.post<{
      success: boolean;
      token?: string;
      challenge_token?: string;
      expiresIn?: number;
      message?: string;
    }>(
      `${KARTOONS_API}/challenge/verify`,
      { turnstile_token: turnstileToken },
      {
        headers: {
          "Content-Type": "application/json",
          Origin: "https://kartoons.me",
          Referer: "https://kartoons.me/",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        timeout: 10000,
      },
    );
    const data = res.data;
    const token = data.token || data.challenge_token;
    if (data.success && token) {
      const expiresInMs = data.expiresIn ? data.expiresIn * 1000 : 3600000;
      setChallengeToken(token, expiresInMs);
      return token;
    }
    logger.warn({ data }, "challenge verify returned non-success");
    return null;
  } catch (err) {
    logger.error({ err }, "challenge verify failed");
    return null;
  }
}

export function kartoonsApiHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const token = getChallengeToken();
  return {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    Accept: "application/json",
    Origin: "https://kartoons.me",
    Referer: "https://kartoons.me/",
    ...(token ? { "X-Challenge-Token": token } : {}),
    ...extra,
  };
}
