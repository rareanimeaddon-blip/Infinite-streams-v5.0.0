import axios from "axios";
import { getCache, setCache } from "./cache.js";
import { logger } from "./logger.js";

const TMDB_BASE = "https://api.themoviedb.org/3";

export interface TmdbResult {
  imdbId: string | null;
  title: string;
  type: "movie" | "series";
  poster?: string;
  year?: string;
}

function apiKey(): string {
  return process.env.TMDB_API_KEY ?? "";
}

export async function searchTmdb(
  title: string,
  type: "movie" | "tv",
): Promise<TmdbResult | null> {
  const cacheKey = `tmdb:search:${type}:${title.toLowerCase().trim()}`;
  const cached = getCache<TmdbResult | null>(cacheKey);
  if (cached !== undefined) return cached;

  try {
    const searchRes = await axios.get(`${TMDB_BASE}/search/${type}`, {
      params: { api_key: apiKey(), query: title, language: "en-US" },
      timeout: 8000,
    });

    const results: Record<string, unknown>[] = searchRes.data.results ?? [];
    if (results.length === 0) {
      setCache(cacheKey, null, 86400);
      return null;
    }

    const first = results[0] as Record<string, unknown>;
    const tmdbId = first.id as number;

    const extRes = await axios.get(
      `${TMDB_BASE}/${type}/${tmdbId}/external_ids`,
      { params: { api_key: apiKey() }, timeout: 8000 },
    );

    const imdbId = (extRes.data.imdb_id as string | undefined) ?? null;
    const posterPath = first.poster_path as string | undefined;
    const result: TmdbResult = {
      imdbId,
      title: (first.title ?? first.name ?? title) as string,
      type: type === "movie" ? "movie" : "series",
      poster: posterPath
        ? `https://image.tmdb.org/t/p/w500${posterPath}`
        : undefined,
      year: (
        ((first.release_date ?? first.first_air_date) as string) ?? ""
      ).split("-")[0],
    };

    setCache(cacheKey, result, 604800);
    return result;
  } catch (err) {
    logger.warn({ err, title, type }, "TMDB search failed");
    return null;
  }
}

export async function findByImdbId(imdbId: string): Promise<TmdbResult | null> {
  const cacheKey = `tmdb:imdb:${imdbId}`;
  const cached = getCache<TmdbResult | null>(cacheKey);
  if (cached !== undefined) return cached;

  try {
    const res = await axios.get(`${TMDB_BASE}/find/${imdbId}`, {
      params: { api_key: apiKey(), external_source: "imdb_id" },
      timeout: 8000,
    });

    const movieResults: Record<string, unknown>[] =
      res.data.movie_results ?? [];
    const tvResults: Record<string, unknown>[] = res.data.tv_results ?? [];

    if (movieResults.length > 0) {
      const m = movieResults[0] as Record<string, unknown>;
      const posterPath = m.poster_path as string | undefined;
      const result: TmdbResult = {
        imdbId,
        title: m.title as string,
        type: "movie",
        poster: posterPath
          ? `https://image.tmdb.org/t/p/w500${posterPath}`
          : undefined,
        year: ((m.release_date as string) ?? "").split("-")[0],
      };
      setCache(cacheKey, result, 604800);
      return result;
    }

    if (tvResults.length > 0) {
      const t = tvResults[0] as Record<string, unknown>;
      const posterPath = t.poster_path as string | undefined;
      const result: TmdbResult = {
        imdbId,
        title: t.name as string,
        type: "series",
        poster: posterPath
          ? `https://image.tmdb.org/t/p/w500${posterPath}`
          : undefined,
        year: ((t.first_air_date as string) ?? "").split("-")[0],
      };
      setCache(cacheKey, result, 604800);
      return result;
    }

    setCache(cacheKey, null, 3600);
    return null;
  } catch (err) {
    logger.warn({ err, imdbId }, "TMDB findByImdbId failed");
    return null;
  }
}
