import { Router, type IRouter, type Response } from "express";
import { findByImdbId } from "../../lib/tmdb.js";
import {
  searchKartoonsAddon,
  getEpisodeId,
  getStreamsFromAddon,
} from "../../lib/kartoons-addon.js";
import { logger } from "../../lib/logger.js";

const router: IRouter = Router();

router.get("/stream/:type/:id.json", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  const { type, id } = req.params;
  logger.info({ type, id }, "stream request");

  try {
    const itemType = type === "movie" ? "movie" : "series";

    if (id.startsWith("kartoons:")) {
      await handleKartoonsId(id, itemType, res);
      return;
    }

    const parts = id.split(":");
    const imdbId = parts[0];
    const season = parts[1] ? parseInt(parts[1]) : undefined;
    const episode = parts[2] ? parseInt(parts[2]) : undefined;

    if (!imdbId.startsWith("tt")) {
      res.json({ streams: [] });
      return;
    }

    const tmdb = await findByImdbId(imdbId);
    if (!tmdb?.title) {
      logger.warn({ imdbId }, "TMDB could not resolve IMDB ID");
      res.json({ streams: [] });
      return;
    }

    const kartoonsShowId = await searchKartoonsAddon(tmdb.title, itemType);
    if (!kartoonsShowId) {
      logger.info({ title: tmdb.title }, "not found in kartoons addon");
      res.json({ streams: [] });
      return;
    }

    let streamId = kartoonsShowId;

    if (itemType === "series" && season !== undefined && episode !== undefined) {
      const episodeId = await getEpisodeId(kartoonsShowId, season, episode);
      if (!episodeId) {
        logger.info({ kartoonsShowId, season, episode }, "episode not found");
        res.json({ streams: [] });
        return;
      }
      streamId = episodeId;
    }

    const streams = await getStreamsFromAddon(streamId, itemType);
    res.json({ streams });
  } catch (err) {
    logger.error({ err }, "stream handler error");
    res.json({ streams: [] });
  }
});

async function handleKartoonsId(
  id: string,
  itemType: "movie" | "series",
  res: Response,
): Promise<void> {
  const parts = id.split(":");

  if (itemType === "movie") {
    const kartoonsId = parts.slice(0, 2).join(":");
    const streams = await getStreamsFromAddon(kartoonsId, "movie");
    res.json({ streams });
    return;
  }

  if (parts.length >= 4) {
    const kartoonsShowId = parts.slice(0, 2).join(":");
    const season = parseInt(parts[2]);
    const episode = parseInt(parts[3]);

    if (!isNaN(season) && !isNaN(episode)) {
      const episodeId = await getEpisodeId(kartoonsShowId, season, episode);
      if (episodeId) {
        const streams = await getStreamsFromAddon(episodeId, "series");
        res.json({ streams });
        return;
      }
    }
  }

  res.json({ streams: [] });
}

export default router;
