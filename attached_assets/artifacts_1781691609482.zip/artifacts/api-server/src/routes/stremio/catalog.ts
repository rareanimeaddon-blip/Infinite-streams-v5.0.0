import { Router, type IRouter, type Request, type Response } from "express";
import { getCatalog } from "../../lib/scraper.js";
import {
  getAddonCatalogMap,
  searchAddonCatalog,
  type AddonMeta,
} from "../../lib/kartoons-addon.js";
import { searchTmdb } from "../../lib/tmdb.js";
import { getCache, setCache } from "../../lib/cache.js";
import { logger } from "../../lib/logger.js";

const router: IRouter = Router();

interface MetaObject {
  id: string;
  type: string;
  name: string;
  poster?: string;
  background?: string;
  genres?: string[];
  description?: string;
  releaseInfo?: string;
  imdbRating?: string;
}

const CATALOG_CONFIGS: Record<
  string,
  {
    itemType: "movie" | "series";
    category?: "Anime" | "Cartoon";
    addonCatalogId: string;
    stremioType: "series" | "movie";
  }
> = {
  kartoons_anime: {
    itemType: "series",
    category: "Anime",
    addonCatalogId: "kartoons_shows",
    stremioType: "series",
  },
  kartoons_cartoons: {
    itemType: "series",
    category: "Cartoon",
    addonCatalogId: "kartoons_shows",
    stremioType: "series",
  },
  kartoons_movies: {
    itemType: "movie",
    addonCatalogId: "kartoons_movies",
    stremioType: "movie",
  },
};

async function enrichWithImdbId(
  kartoonsId: string,
  name: string,
  type: "movie" | "series",
  addonMeta: AddonMeta,
): Promise<MetaObject> {
  const cacheKey = `enrich:v3:${kartoonsId}`;
  const cached = getCache<MetaObject>(cacheKey);
  if (cached) return cached;

  const tmdbType = type === "movie" ? "movie" : "tv";
  const tmdb = await searchTmdb(name, tmdbType);

  const result: MetaObject = tmdb?.imdbId
    ? {
        id: tmdb.imdbId,
        type,
        name: tmdb.title || name,
        poster: tmdb.poster ?? addonMeta.poster,
        background: addonMeta.background,
        genres: addonMeta.genres,
        description: addonMeta.description,
        releaseInfo: addonMeta.releaseInfo,
        imdbRating: addonMeta.imdbRating,
      }
    : {
        id: kartoonsId,
        type,
        name,
        poster: addonMeta.poster,
        background: addonMeta.background,
        genres: addonMeta.genres,
        description: addonMeta.description,
        releaseInfo: addonMeta.releaseInfo,
        imdbRating: addonMeta.imdbRating,
      };

  const ttl = tmdb?.imdbId ? 604800 : 3600;
  setCache(cacheKey, result, ttl);
  return result;
}

async function catalogHandler(req: Request, res: Response) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  const { catalogId } = req.params;
  const extra = (req.params.extra ?? "") as string;
  const decoded = extra ? decodeURIComponent(extra) : "";
  const searchMatch = decoded.match(/search=([^&]+)/);
  const skipMatch = decoded.match(/skip=(\d+)/);
  const searchQuery = searchMatch
    ? decodeURIComponent(searchMatch[1].replace(/\+/g, " "))
    : null;
  const skip = skipMatch ? parseInt(skipMatch[1]) : 0;

  logger.info({ catalogId, searchQuery, skip }, "catalog request");

  const config = CATALOG_CONFIGS[catalogId];
  if (!config) {
    return res.json({ metas: [] });
  }

  try {
    if (searchQuery) {
      const addonMetas = await searchAddonCatalog(
        config.stremioType,
        config.addonCatalogId,
        searchQuery,
      );

      if (!addonMetas.length) {
        return res.json({ metas: [] });
      }

      const enriched = await Promise.allSettled(
        addonMetas.slice(0, 20).map((m) =>
          enrichWithImdbId(m.id, m.name, config.itemType, m),
        ),
      );

      const metas = enriched
        .filter(
          (r): r is PromiseFulfilledResult<MetaObject> =>
            r.status === "fulfilled",
        )
        .map((r) => r.value);

      return res.json({ metas });
    }

    const [items, addonMap] = await Promise.all([
      getCatalog(config.itemType, skip, config.category),
      getAddonCatalogMap(config.stremioType, config.addonCatalogId),
    ]);

    if (!items.length) {
      return res.json({ metas: [] });
    }

    const settled = await Promise.allSettled(
      items.map((item) => {
        const kartoonsId = `kartoons:${item.id}`;
        const addonMeta: AddonMeta =
          addonMap.get(kartoonsId) ?? {
            id: kartoonsId,
            name: item.title,
            type: config.itemType,
            poster: item.poster,
          };
        return enrichWithImdbId(kartoonsId, item.title, config.itemType, addonMeta);
      }),
    );

    const metas = settled
      .filter(
        (r): r is PromiseFulfilledResult<MetaObject> =>
          r.status === "fulfilled",
      )
      .map((r) => r.value);

    return res.json({ metas });
  } catch (err) {
    logger.error({ err }, "catalog handler error");
    return res.json({ metas: [] });
  }
}

router.get("/catalog/:type/:catalogId/:extra.json", catalogHandler);
router.get("/catalog/:type/:catalogId.json", catalogHandler);

export default router;
