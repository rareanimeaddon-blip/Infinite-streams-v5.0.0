import { Router, type IRouter } from "express";
import manifestRouter from "./manifest.js";
import catalogRouter from "./catalog.js";
import streamRouter from "./stream.js";
import configureRouter from "./configure.js";

const router: IRouter = Router();

router.use((_, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  next();
});

router.use(manifestRouter);
router.use(catalogRouter);
router.use(streamRouter);
router.use(configureRouter);

export default router;
