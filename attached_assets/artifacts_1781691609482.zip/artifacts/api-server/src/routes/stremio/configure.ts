import { Router, type IRouter } from "express";
import {
  getAddonConfig,
  saveAddonConfig,
  parseManifestUrl,
} from "../../lib/addon-config.js";
import { testAddonConnection } from "../../lib/kartoons-addon.js";

const router: IRouter = Router();

function renderPage(opts: {
  manifestUrl: string;
  addonBase: string;
  lastUpdated?: string;
  message?: { type: "success" | "error"; text: string };
}) {
  const { manifestUrl, addonBase, lastUpdated, message } = opts;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kartoons Stremio Addon — Configure</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }
    .card {
      background: #1e293b;
      border-radius: 16px;
      padding: 40px;
      max-width: 540px;
      width: 100%;
      box-shadow: 0 25px 50px rgba(0,0,0,0.5);
    }
    .header { display: flex; align-items: center; gap: 12px; margin-bottom: 6px; }
    .logo { font-size: 28px; }
    h1 { font-size: 22px; font-weight: 700; }
    .subtitle { color: #64748b; font-size: 13px; margin-bottom: 28px; }
    .section {
      background: #0f172a;
      border-radius: 10px;
      padding: 18px;
      margin-bottom: 16px;
    }
    .section-title {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #64748b;
      margin-bottom: 10px;
    }
    .url-display {
      font-family: monospace;
      font-size: 12px;
      color: #94a3b8;
      word-break: break-all;
      line-height: 1.6;
    }
    .url-display span { color: #e2e8f0; }
    .copy-btn {
      margin-top: 10px;
      background: #334155;
      border: none;
      color: #94a3b8;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 12px;
      cursor: pointer;
      transition: background 0.15s;
    }
    .copy-btn:hover { background: #475569; color: #e2e8f0; }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
    }
    .badge.active { background: #064e3b; color: #6ee7b7; }
    .badge.inactive { background: #422006; color: #fed7aa; }
    label {
      display: block;
      font-size: 13px;
      color: #94a3b8;
      margin-bottom: 6px;
    }
    label strong { color: #cbd5e1; }
    input[type="text"], input[type="password"] {
      width: 100%;
      background: #0f172a;
      border: 1.5px solid #334155;
      border-radius: 8px;
      padding: 10px 14px;
      color: #e2e8f0;
      font-size: 13px;
      font-family: monospace;
      outline: none;
      transition: border-color 0.15s;
    }
    input:focus { border-color: #3b82f6; }
    input::placeholder { color: #475569; font-family: monospace; }
    .input-hint {
      font-size: 11px;
      color: #475569;
      margin-top: 5px;
    }
    .btn-row {
      display: flex;
      gap: 10px;
      margin-top: 16px;
    }
    .btn {
      flex: 1;
      padding: 10px 18px;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.15s;
    }
    .btn:hover { opacity: 0.85; }
    .btn-primary { background: #3b82f6; color: #fff; }
    .btn-secondary { background: #334155; color: #cbd5e1; flex: 0; padding: 10px 16px; }
    .msg {
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 13px;
      margin-top: 14px;
      display: none;
    }
    .msg.success { background: #064e3b; color: #6ee7b7; }
    .msg.error { background: #4c0519; color: #fda4af; }
    .msg.info { background: #1e3a5f; color: #93c5fd; }
    .divider { border: none; border-top: 1px solid #1e293b; margin: 6px 0 14px; }
    .meta { font-size: 11px; color: #475569; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="logo">🎬</div>
      <h1>Kartoons Addon</h1>
    </div>
    <div class="subtitle">Configure the official Kartoons source and install this addon in Stremio.</div>

    ${message ? `<div class="msg ${message.type}" style="display:block;margin-bottom:16px">${message.text}</div>` : ""}

    <!-- Current Status -->
    <div class="section">
      <div class="section-title">Source Status</div>
      <div id="status-badge" class="badge inactive">⏳ Checking…</div>
      <div class="meta" id="status-detail">Testing connection to Kartoons source…</div>
      ${lastUpdated ? `<div class="meta">Last updated: ${new Date(lastUpdated).toLocaleString()}</div>` : ""}
      <hr class="divider">
      <div class="section-title">Current source manifest URL</div>
      <div class="url-display"><span id="current-manifest">${manifestUrl}</span></div>
    </div>

    <!-- Update Source -->
    <div class="section">
      <div class="section-title">Update Source</div>
      <label><strong>New Kartoons manifest URL</strong></label>
      <input
        type="text"
        id="manifest-input"
        placeholder="https://api.kartoons.me/api/stremio/manifest.json?token=…"
      />
      <div class="input-hint">Paste the full manifest URL including the token parameter.</div>
      <div class="btn-row">
        <button class="btn btn-secondary" onclick="testManifest()">Test</button>
        <button class="btn btn-primary" onclick="saveManifest()">Save &amp; Apply</button>
      </div>
      <div class="msg" id="update-msg"></div>
    </div>

    <!-- Install addon -->
    <div class="section">
      <div class="section-title">Install this addon in Stremio</div>
      <div class="url-display"><span id="addon-url">${addonBase}/manifest.json</span></div>
      <button class="copy-btn" onclick="copyAddonUrl()">Copy install URL</button>
    </div>
  </div>

  <script>
    const addonBase = ${JSON.stringify(addonBase)};

    document.getElementById('addon-url').textContent = addonBase + '/manifest.json';

    async function checkStatus() {
      try {
        const r = await fetch(addonBase + '/configure/test-connection');
        const d = await r.json();
        const badge = document.getElementById('status-badge');
        const detail = document.getElementById('status-detail');
        if (d.ok) {
          badge.className = 'badge active';
          badge.textContent = '✅ Connected';
          detail.textContent = 'Kartoons source is working — ' + d.catalogCount + ' catalogs available.';
        } else {
          badge.className = 'badge inactive';
          badge.textContent = '❌ Not connected';
          detail.textContent = 'Error: ' + (d.error || 'Cannot reach Kartoons source');
        }
      } catch {
        document.getElementById('status-badge').textContent = '⚠️ Check failed';
      }
    }
    checkStatus();

    function showMsg(id, type, text) {
      const el = document.getElementById(id);
      el.className = 'msg ' + type;
      el.style.display = 'block';
      el.textContent = text;
    }

    async function testManifest() {
      const url = document.getElementById('manifest-input').value.trim();
      if (!url) { showMsg('update-msg', 'error', 'Please paste a manifest URL first.'); return; }
      showMsg('update-msg', 'info', 'Testing connection…');
      try {
        const r = await fetch(addonBase + '/configure/test-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ manifestUrl: url })
        });
        const d = await r.json();
        if (d.ok) {
          showMsg('update-msg', 'success', '✅ Connection successful! ' + d.catalogCount + ' catalogs found. You can now save.');
        } else {
          showMsg('update-msg', 'error', '❌ ' + (d.error || 'Connection failed'));
        }
      } catch {
        showMsg('update-msg', 'error', '❌ Network error while testing.');
      }
    }

    async function saveManifest() {
      const url = document.getElementById('manifest-input').value.trim();
      if (!url) { showMsg('update-msg', 'error', 'Please paste a manifest URL first.'); return; }
      showMsg('update-msg', 'info', 'Saving and testing…');
      try {
        const r = await fetch(addonBase + '/configure/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ manifestUrl: url })
        });
        const d = await r.json();
        if (d.ok) {
          document.getElementById('current-manifest').textContent = url;
          showMsg('update-msg', 'success', '✅ Saved! Addon is now using the new source. Streams will work immediately.');
          document.getElementById('manifest-input').value = '';
          checkStatus();
        } else {
          showMsg('update-msg', 'error', '❌ ' + (d.error || 'Save failed'));
        }
      } catch {
        showMsg('update-msg', 'error', '❌ Network error while saving.');
      }
    }

    function copyAddonUrl() {
      const url = addonBase + '/manifest.json';
      navigator.clipboard.writeText(url).then(() => {
        const btn = document.querySelector('.copy-btn');
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy install URL', 2000);
      });
    }
  </script>
</body>
</html>`;
}

router.get("/configure", async (_req, res) => {
  const config = getAddonConfig();
  const manifestUrl = `${config.kartoonsBase}/manifest.json?token=${config.kartoonsToken}`;
  const addonBase =
    process.env.REPLIT_DOMAINS
      ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}/api/stremio`
      : "/api/stremio";

  res.setHeader("Content-Type", "text/html");
  res.send(
    renderPage({
      manifestUrl,
      addonBase,
      lastUpdated: config.updatedAt,
    }),
  );
});

router.get("/configure/test-connection", async (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");
  const result = await testAddonConnection();
  res.json(result);
});

router.post("/configure/test-url", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  const { manifestUrl } = req.body as { manifestUrl?: string };
  if (!manifestUrl) {
    return res.status(400).json({ ok: false, error: "manifestUrl required" });
  }

  const parsed = parseManifestUrl(manifestUrl);
  if (!parsed) {
    return res
      .status(400)
      .json({ ok: false, error: "Invalid URL — must include ?token= parameter" });
  }

  try {
    const { default: axios } = await import("axios");
    const r = await axios.get(`${parsed.base}/manifest.json?token=${parsed.token}`, {
      timeout: 10000,
    });
    if (r.data?.catalogs) {
      return res.json({ ok: true, catalogCount: r.data.catalogs.length });
    }
    return res.json({ ok: false, error: "Unexpected response from manifest URL" });
  } catch (err) {
    return res.json({
      ok: false,
      error: err instanceof Error ? err.message : "Connection failed",
    });
  }
});

router.post("/configure/update", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  const { manifestUrl } = req.body as { manifestUrl?: string };
  if (!manifestUrl) {
    return res.status(400).json({ ok: false, error: "manifestUrl required" });
  }

  const parsed = parseManifestUrl(manifestUrl);
  if (!parsed) {
    return res
      .status(400)
      .json({ ok: false, error: "Invalid URL — must include ?token= parameter" });
  }

  try {
    const { default: axios } = await import("axios");
    const r = await axios.get(`${parsed.base}/manifest.json?token=${parsed.token}`, {
      timeout: 10000,
    });
    if (!r.data?.catalogs) {
      return res.json({ ok: false, error: "URL does not point to a valid Stremio addon" });
    }

    saveAddonConfig({
      kartoonsToken: parsed.token,
      kartoonsBase: parsed.base,
    });

    return res.json({ ok: true, catalogCount: r.data.catalogs.length });
  } catch (err) {
    return res.json({
      ok: false,
      error: err instanceof Error ? err.message : "Connection failed",
    });
  }
});

export default router;
