import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.get("/manifest.json", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  const manifest = {
    id: "community.kartoons.stremio",
    version: "2.0.0",
    name: "Kartoons",
    description:
      "Browse 479 shows and 515 movies from Kartoons.me — Hindi & English anime and cartoons. Naruto, Dragon Ball, Doraemon, Shin Chan, Solo Leveling, and more. Works with IMDB/TMDB/Cinemeta.",
    logo: "https://kartoons.me/logo.png",
    background:
      "https://image.tmdb.org/t/p/original/xuJ0F9RfKvVSJNDg2usurQ9WvY5.jpg",
    resources: ["catalog", "stream"],
    types: ["movie", "series"],
    catalogs: [
      {
        type: "series",
        id: "kartoons_anime",
        name: "Kartoons — Anime",
        extra: [
          { name: "search", isRequired: false },
          { name: "skip", isRequired: false },
        ],
        genres: [
          "Action",
          "Adventure",
          "Animation",
          "Comedy",
          "Drama",
          "Fantasy",
          "Horror",
          "Kids",
          "Mystery",
          "Romance",
          "Science Fiction",
          "Thriller",
        ],
      },
      {
        type: "series",
        id: "kartoons_cartoons",
        name: "Kartoons — Cartoons",
        extra: [
          { name: "search", isRequired: false },
          { name: "skip", isRequired: false },
        ],
        genres: [
          "Action",
          "Adventure",
          "Animation",
          "Comedy",
          "Family",
          "Fantasy",
          "Kids",
        ],
      },
      {
        type: "movie",
        id: "kartoons_movies",
        name: "Kartoons — Movies",
        extra: [
          { name: "search", isRequired: false },
          { name: "skip", isRequired: false },
        ],
        genres: [
          "Action",
          "Adventure",
          "Animation",
          "Anime",
          "Comedy",
          "Drama",
          "Family",
          "Fantasy",
          "Horror",
          "Kids",
          "Mystery",
          "Romance",
          "Science Fiction",
          "Thriller",
        ],
      },
    ],
    idPrefixes: ["tt", "kartoons"],
    behaviorHints: {
      adult: false,
      p2p: false,
      configurable: false,
      configurationRequired: false,
    },
    contactEmail: "admin@kartoons.me",
  };

  res.json(manifest);
});

export default router;
