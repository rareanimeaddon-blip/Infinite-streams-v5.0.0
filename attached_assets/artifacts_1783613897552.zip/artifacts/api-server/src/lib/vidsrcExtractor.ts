import * as cheerio from "cheerio";
import { Parser } from "m3u8-parser";
import { logger } from "./logger";

const SOURCE_URL = "https://vidsrc-embed.ru/embed";

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0",
];

function randomUserAgent(): string {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]!;
}

function baseHeaders(baseDom: string) {
  return {
    accept: "*/*",
    "accept-language": "en-US,en;q=0.9",
    Referer: `${baseDom}/`,
    "Referrer-Policy": "origin",
    "User-Agent": randomUserAgent(),
  };
}

export interface QualityStream {
  resolution?: string;
  title: string;
  url: string;
}

export interface ExtractedStream {
  serverName: string;
  streamUrl: string;
  referer: string;
  qualities: QualityStream[];
}

interface ServerEntry {
  name: string | null;
  dataHash: string | null;
}

function parseServers(html: string): { servers: ServerEntry[]; baseDom: string; title: string } {
  const $ = cheerio.load(html);
  const title = $("title").text() ?? "";
  const iframeSrc = $("#player_iframe").attr("src") ?? $("iframe").attr("src") ?? "";
  let baseDom = "https://cloudnestra.com";
  let iframeHash: string | null = null;
  try {
    const normalized = iframeSrc.startsWith("//") ? `https:${iframeSrc}` : iframeSrc;
    if (normalized) {
      const parsed = new URL(normalized);
      baseDom = parsed.origin;
      const match = parsed.pathname.match(/\/rcp\/(.+)$/);
      if (match) iframeHash = match[1] ?? null;
    }
  } catch {
    // keep default
  }

  const servers: ServerEntry[] = [];
  $(".serversList .server").each((_i, el) => {
    const server = $(el);
    servers.push({
      name: server.text().trim(),
      dataHash: server.attr("data-hash") ?? null,
    });
  });

  if (servers.length === 0 && iframeHash) {
    servers.push({ name: "Default", dataHash: iframeHash });
  }

  return { servers, baseDom, title };
}

function extractSrcAttr(html: string): string | null {
  const match = html.match(/src:\s*'([^']*)'/);
  return match?.[1] ?? null;
}

async function resolveProrcp(baseDom: string, prorcpPath: string): Promise<string | null> {
  try {
    const res = await fetch(`${baseDom}/prorcp/${prorcpPath}`, {
      headers: baseHeaders(baseDom),
    });
    if (!res.ok) return null;
    const html = await res.text();

    const fileMatch = html.match(/file:\s*'([^']*)'/);
    if (fileMatch?.[1]) return fileMatch[1];

    const masterMatch = html.match(/var master_urls\s*=\s*"([^"]+)"/);
    if (!masterMatch?.[1]) return null;
    let masterUrls = masterMatch[1];

    const genCalls = [...html.matchAll(/\$\.get\("([^"]+generate\.php)"/g)].map((m) => m[1]);
    const placeholders = [
      ...new Set([...html.matchAll(/replaceAll\("(__[A-Z]+__)",\s*token\)/g)].map((m) => m[1])),
    ];

    for (let i = 0; i < genCalls.length && i < placeholders.length; i++) {
      const genUrl = genCalls[i];
      const placeholder = placeholders[i];
      if (!genUrl || !placeholder) continue;
      try {
        const tokenRes = await fetch(genUrl, { headers: baseHeaders(baseDom) });
        if (!tokenRes.ok) continue;
        const token = (await tokenRes.text()).trim();
        masterUrls = masterUrls.split(placeholder).join(token);
      } catch (err) {
        logger.error({ err, genUrl }, "Failed to fetch token for master url");
      }
    }

    const firstUrl = masterUrls.split(/\s+or\s+/)[0];
    return firstUrl ?? null;
  } catch (err) {
    logger.error({ err }, "Failed to resolve prorcp stream");
    return null;
  }
}

async function parseHlsQualities(masterUrl: string): Promise<QualityStream[]> {
  try {
    const res = await fetch(masterUrl);
    if (!res.ok) return [];
    const content = await res.text();
    if (!content.includes("#EXT-X-STREAM-INF")) return [];

    const parser = new Parser();
    parser.push(content);
    parser.end();

    const playlists = (parser.manifest.playlists ?? []) as Array<{
      uri: string;
      attributes?: { BANDWIDTH?: number; RESOLUTION?: { width: number; height: number } };
    }>;

    return playlists
      .sort((a, b) => (b.attributes?.BANDWIDTH ?? 0) - (a.attributes?.BANDWIDTH ?? 0))
      .map((playlist) => {
        const resolution = playlist.attributes?.RESOLUTION;
        const url = playlist.uri.startsWith("http")
          ? playlist.uri
          : new URL(playlist.uri, masterUrl).toString();
        const title = resolution ? `${resolution.height}p` : "Auto";
        return {
          resolution: resolution ? `${resolution.width}x${resolution.height}` : undefined,
          title,
          url,
        };
      });
  } catch (err) {
    logger.error({ err, masterUrl }, "Failed to parse HLS master playlist");
    return [];
  }
}

function embedUrl(imdbId: string, season?: number, episode?: number): string {
  if (season !== undefined && episode !== undefined) {
    return `${SOURCE_URL}/tv/${imdbId}/${season}-${episode}`;
  }
  return `${SOURCE_URL}/movie/${imdbId}`;
}

export async function extractVidsrcStreams(
  imdbId: string,
  season?: number,
  episode?: number,
): Promise<ExtractedStream[]> {
  const url = embedUrl(imdbId, season, episode);

  const embedRes = await fetch(url, { headers: baseHeaders("https://vidsrc-embed.ru") });
  if (!embedRes.ok) {
    logger.warn({ url, status: embedRes.status }, "Vidsrc embed page fetch failed");
    return [];
  }
  const embedHtml = await embedRes.text();
  const { servers, baseDom } = parseServers(embedHtml);

  if (servers.length === 0) {
    return [];
  }

  const results = await Promise.all(
    servers.map(async (server): Promise<ExtractedStream | null> => {
      if (!server.dataHash) return null;
      try {
        const rcpRes = await fetch(`${baseDom}/rcp/${server.dataHash}`, {
          headers: baseHeaders(baseDom),
        });
        if (!rcpRes.ok) return null;
        const rcpHtml = await rcpRes.text();
        const src = extractSrcAttr(rcpHtml);
        if (!src || !src.startsWith("/prorcp/")) return null;

        const streamUrl = await resolveProrcp(baseDom, src.replace("/prorcp/", ""));
        if (!streamUrl) return null;

        const qualities = await parseHlsQualities(streamUrl);

        return {
          serverName: server.name ?? "VidSrc",
          streamUrl,
          referer: `${baseDom}/`,
          qualities,
        };
      } catch (err) {
        logger.error({ err, server: server.name }, "Failed to extract stream from server");
        return null;
      }
    }),
  );

  return results.filter((r): r is ExtractedStream => r !== null);
}
