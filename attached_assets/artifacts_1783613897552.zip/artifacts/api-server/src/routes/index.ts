import { Router, type IRouter } from "express";
import healthRouter from "./health";
import addonRouter from "./addon";

const router: IRouter = Router();

router.use(healthRouter);
router.use(addonRouter);

export default router;
