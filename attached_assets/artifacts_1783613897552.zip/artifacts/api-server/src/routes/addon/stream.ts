import { Router, type IRouter } from "express";
import { logger } from "../../lib/logger";
import { extractVidsrcStreams } from "../../lib/vidsrcExtractor";
import { buildProxyUrl, proxyBase } from "./proxy";

const router: IRouter = Router();

router.get("/stream/:type/:id.json", async (req, res) => {
  const { type, id } = req.params;

  try {
    let extracted;

    if (type === "movie") {
      const imdbId = id.split(":")[0]!;
      extracted = await extractVidsrcStreams(imdbId);
    } else if (type === "series") {
      const [imdbId, seasonStr, episodeStr] = id.split(":");
      const season = Number(seasonStr);
      const episode = Number(episodeStr);
      if (!imdbId || Number.isNaN(season) || Number.isNaN(episode)) {
        res.json({ streams: [] });
        return;
      }
      extracted = await extractVidsrcStreams(imdbId, season, episode);
    } else {
      res.json({ streams: [] });
      return;
    }

    const base = proxyBase(req);

    const streams = extracted.flatMap((source) => {
      if (source.qualities.length > 0) {
        return source.qualities.map((quality) => ({
          name: "MovieDB",
          title: `${source.serverName} - ${quality.title}`,
          url: buildProxyUrl(base, quality.url, source.referer),
        }));
      }

      return [
        {
          name: "MovieDB",
          title: source.serverName,
          url: buildProxyUrl(base, source.streamUrl, source.referer),
        },
      ];
    });

    res.json({ streams });
  } catch (err) {
    logger.error({ err, type, id }, "Failed to resolve streams");
    res.json({ streams: [] });
  }
});

export default router;
