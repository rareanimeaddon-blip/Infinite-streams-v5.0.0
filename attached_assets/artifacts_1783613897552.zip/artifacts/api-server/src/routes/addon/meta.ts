import { Router, type IRouter } from "express";
import { logger } from "../../lib/logger";

const router: IRouter = Router();

const CINEMETA_BASE = "https://v3-cinemeta.strem.io";

router.get("/meta/:type/:id.json", async (req, res) => {
  const { type, id } = req.params;
  try {
    const upstream = await fetch(`${CINEMETA_BASE}/meta/${type}/${id}.json`);
    if (!upstream.ok) {
      res.status(404).json({ meta: null });
      return;
    }
    const data = await upstream.json();
    res.json(data);
  } catch (err) {
    logger.error({ err, type, id }, "Failed to fetch meta from Cinemeta");
    res.status(502).json({ meta: null });
  }
});

export default router;
