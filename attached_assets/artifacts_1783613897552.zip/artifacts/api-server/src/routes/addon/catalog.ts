import { Router, type IRouter } from "express";
import { logger } from "../../lib/logger";

const router: IRouter = Router();

const CINEMETA_BASE = "https://v3-cinemeta.strem.io";

async function proxyCatalog(
  type: string,
  id: string,
  extra: string | undefined,
  res: import("express").Response,
) {
  const path = extra
    ? `/catalog/${type}/${id}/${extra}.json`
    : `/catalog/${type}/${id}.json`;

  try {
    const upstream = await fetch(`${CINEMETA_BASE}${path}`);
    if (!upstream.ok) {
      res.json({ metas: [] });
      return;
    }
    const data = await upstream.json();
    res.json(data);
  } catch (err) {
    logger.error({ err, path }, "Failed to fetch catalog from Cinemeta");
    res.json({ metas: [] });
  }
}

router.get("/catalog/:type/:id.json", async (req, res) => {
  await proxyCatalog(req.params.type, req.params.id, undefined, res);
});

router.get("/catalog/:type/:id/:extra.json", async (req, res) => {
  await proxyCatalog(req.params.type, req.params.id, req.params.extra, res);
});

export default router;
