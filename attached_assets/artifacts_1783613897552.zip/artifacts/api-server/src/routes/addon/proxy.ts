import { Router, type IRouter, type Request } from "express";
import { logger } from "../../lib/logger";
import { createLink, resolveLink } from "../../lib/streamLinkStore";

const router: IRouter = Router();

function proxyBase(req: Request): string {
  return `${req.protocol}://${req.get("host")}/api/proxy`;
}

function buildProxyUrl(base: string, targetUrl: string, referer: string): string {
  const isPlaylist = targetUrl.split("?")[0]?.toLowerCase().endsWith(".m3u8");
  const id = createLink(targetUrl, referer);
  return isPlaylist ? `${base}/m3u8/${id}.m3u8` : `${base}/segment/${id}.ts`;
}

router.get("/proxy/m3u8/:id.m3u8", async (req, res) => {
  const link = resolveLink(req.params.id);

  if (!link) {
    res.status(410).send("Link expired");
    return;
  }
  const { url: targetUrl, referer } = link;

  try {
    const upstream = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        ...(referer ? { Referer: referer } : {}),
      },
    });

    if (!upstream.ok) {
      res.status(upstream.status).send("Failed to fetch playlist");
      return;
    }

    const body = await upstream.text();
    const base = proxyBase(req);

    const rewritten = body
      .split("\n")
      .map((line) => {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) {
          if (trimmed.startsWith("#EXT-X-KEY") || trimmed.startsWith("#EXT-X-MAP")) {
            return line.replace(/URI="([^"]+)"/, (_m, uri: string) => {
              const abs = new URL(uri, targetUrl).toString();
              return `URI="${buildProxyUrl(base, abs, referer)}"`;
            });
          }
          return line;
        }
        const abs = new URL(trimmed, targetUrl).toString();
        return buildProxyUrl(base, abs, referer);
      })
      .join("\n");

    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(rewritten);
  } catch (err) {
    logger.error({ err, targetUrl }, "Failed to proxy m3u8 playlist");
    res.status(502).send("Failed to proxy playlist");
  }
});

router.get("/proxy/segment/:id.ts", async (req, res) => {
  const link = resolveLink(req.params.id);

  if (!link) {
    res.status(410).send("Link expired");
    return;
  }
  const { url: targetUrl, referer } = link;

  try {
    const upstream = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        ...(referer ? { Referer: referer } : {}),
        ...(req.headers.range ? { Range: req.headers.range as string } : {}),
      },
    });

    if (!upstream.ok && upstream.status !== 206) {
      res.status(upstream.status).send("Failed to fetch segment");
      return;
    }

    const upstreamContentType = upstream.headers.get("content-type");
    const looksMisleading =
      !upstreamContentType ||
      upstreamContentType.includes("text/html") ||
      upstreamContentType.includes("text/plain");
    const contentType = looksMisleading ? "video/mp2t" : upstreamContentType;
    const contentRange = upstream.headers.get("content-range");
    const acceptRanges = upstream.headers.get("accept-ranges") ?? "bytes";

    const arrayBuffer = await upstream.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    res.status(upstream.status);
    if (contentType) res.setHeader("Content-Type", contentType);
    if (contentRange) res.setHeader("Content-Range", contentRange);
    res.setHeader("Accept-Ranges", acceptRanges);
    res.setHeader("Content-Length", String(buffer.length));
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.end(buffer);
  } catch (err) {
    logger.error({ err, targetUrl }, "Failed to proxy segment");
    if (!res.headersSent) res.status(502).send("Failed to proxy segment");
    else res.end();
  }
});

export { buildProxyUrl, proxyBase };
export default router;
