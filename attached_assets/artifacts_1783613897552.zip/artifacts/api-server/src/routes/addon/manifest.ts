import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.get("/manifest.json", (_req, res) => {
  res.json({
    id: "wiki.moviedb.streamaddon",
    version: "1.0.0",
    name: "MovieDB Streams",
    description:
      "Browse popular and trending movies & series (via Cinemeta) and stream them directly in Stremio using sources extracted from moviedb.wiki's video providers.",
    resources: ["catalog", "meta", "stream"],
    types: ["movie", "series"],
    idPrefixes: ["tt"],
    catalogs: [
      {
        type: "movie",
        id: "top",
        name: "Popular Movies",
        extra: [{ name: "search", isRequired: false }, { name: "skip", isRequired: false }],
      },
      {
        type: "series",
        id: "top",
        name: "Popular Series",
        extra: [{ name: "search", isRequired: false }, { name: "skip", isRequired: false }],
      },
    ],
    behaviorHints: {
      configurable: false,
      adult: false,
    },
    logo: "https://image.tmdb.org/t/p/w200/8UlWHLMpgZm9bx6QYh0NFoq67TZ.png",
  });
});

export default router;
