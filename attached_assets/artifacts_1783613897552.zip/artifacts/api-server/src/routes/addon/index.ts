import { Router, type IRouter } from "express";
import manifestRouter from "./manifest";
import catalogRouter from "./catalog";
import metaRouter from "./meta";
import streamRouter from "./stream";
import proxyRouter from "./proxy";

const router: IRouter = Router();

router.use(manifestRouter);
router.use(catalogRouter);
router.use(metaRouter);
router.use(streamRouter);
router.use(proxyRouter);

export default router;
