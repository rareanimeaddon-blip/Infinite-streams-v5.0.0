import app from "./app";
import { logger } from "./lib/logger";

// Defense-in-depth: a stray unhandled error from a proxied/piped stream
// (e.g. a client disconnecting mid-download) must never take the whole
// server down. Log it and keep running instead of crashing the process.
process.on("uncaughtException", (err) => {
  logger.error({ err }, "uncaughtException (process kept alive)");
});
process.on("unhandledRejection", (reason) => {
  logger.error({ err: reason }, "unhandledRejection (process kept alive)");
});

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
