import * as cheerio from "cheerio";
import { logger } from "./logger";

/**
 * Port of the relevant parts of AnimeDekhoProvider (Cloudstream plugin):
 * search AnimeDekho, locate the right anime/episode page, and pull out the
 * "HydraX" server entry, which is the site's label for the Abyss player.
 *
 * The site gates its server list behind a cookie (discovered by inspecting
 * the live site, and matching the `Cookie: toronites_server=vidstream`
 * header used by the original Cloudstream extractor's loadLinks routine).
 */

const BASE_URL = "https://animedekho.app";

const BROWSER_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
};

const UNLOCK_HEADERS = {
  ...BROWSER_HEADERS,
  Cookie: "toronites_server=vidstream",
};

export interface AnimeSearchResult {
  title: string;
  year?: string;
  url: string;
}

/** Normalizes a title for loose comparison (lowercase, strip punctuation). */
function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/** Strips punctuation the site's search chokes on (colons, apostrophes, etc). */
function sanitizeQuery(query: string): string {
  return query
    .replace(/[:!?'".,]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export async function searchAnime(query: string): Promise<AnimeSearchResult[]> {
  const res = await fetch(`${BASE_URL}/?s=${encodeURIComponent(sanitizeQuery(query))}`, {
    headers: BROWSER_HEADERS,
  });
  if (!res.ok) throw new Error(`AnimeDekho search failed: ${res.status}`);
  const html = await res.text();
  const $ = cheerio.load(html);

  const results: AnimeSearchResult[] = [];
  $("ul[data-results] li article, article").each((_, el) => {
    const article = $(el);
    const href = article.find("a.lnk-blk").attr("href");
    const title = article.find("header h2, h2.entry-title").first().text().trim();
    const year = article.find(".entry-meta .year").first().text().trim() || undefined;
    if (href && title) {
      results.push({ title, year, url: href });
    }
  });
  return results;
}

/** Picks the best search result for a given title (and optional year). */
export function pickBestMatch(
  results: AnimeSearchResult[],
  title: string,
  year?: string,
): AnimeSearchResult | null {
  if (results.length === 0) return null;
  const target = normalizeTitle(title);

  const scored = results.map((result) => {
    const candidate = normalizeTitle(result.title);
    let score = 0;
    if (candidate === target) score += 10;
    else if (candidate.includes(target) || target.includes(candidate)) score += 5;
    else {
      const targetWords = new Set(target.split(" "));
      const overlap = candidate.split(" ").filter((w) => targetWords.has(w)).length;
      score += overlap;
    }
    if (year && result.year && result.year === year) score += 3;
    return { result, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0].score > 0 ? scored[0].result : null;
}

interface EpisodeEntry {
  season: number;
  episode: number;
  url: string;
}

/** For series: parses the season/episode list off an anime's main page. */
export async function getEpisodePage(
  animeUrl: string,
  season: number,
  episode: number,
): Promise<string | null> {
  const res = await fetch(animeUrl, { headers: BROWSER_HEADERS });
  if (!res.ok) throw new Error(`AnimeDekho anime page failed: ${res.status}`);
  const html = await res.text();
  const $ = cheerio.load(html);

  const entries: EpisodeEntry[] = [];
  $("ul.seasons-lst li").each((_, el) => {
    const li = $(el);
    const label = li.find("h3.title span").first().text().trim(); // e.g. "S1-E1"
    const href = li.find("a").attr("href");
    const match = label.match(/S(\d+)-E(\d+)/i);
    if (match && href) {
      entries.push({ season: Number(match[1]), episode: Number(match[2]), url: href });
    }
  });

  const found = entries.find((e) => e.season === season && e.episode === episode);
  return found?.url ?? null;
}

/**
 * Given an episode (or movie) page URL, finds the "HydraX" server entry and
 * resolves it to the actual abyss embed URL (e.g. https://abyssplayer.com/xxx).
 */
export async function getAbyssEmbedUrl(pageUrl: string): Promise<string | null> {
  const res = await fetch(pageUrl, { headers: UNLOCK_HEADERS });
  if (!res.ok) throw new Error(`AnimeDekho page fetch failed: ${res.status}`);
  const html = await res.text();
  const $ = cheerio.load(html);

  let hydraxDataSrc: string | null = null;
  $("aside.bx.options a[data-src]").each((_, el) => {
    const name = $(el).find("span.num").text().trim();
    if (name.toLowerCase() === "hydrax") {
      hydraxDataSrc = $(el).attr("data-src") ?? null;
    }
  });

  if (!hydraxDataSrc) {
    logger.warn({ pageUrl }, "animedekho: no HydraX server entry found");
    return null;
  }

  const decodedUrl = Buffer.from(hydraxDataSrc, "base64").toString("utf-8");

  // HydraX entries are either a direct embed URL or a `?trdekho=...` AJAX
  // redirector that itself returns an <iframe> pointing at the real embed.
  if (decodedUrl.includes("trdekho=")) {
    const ajaxRes = await fetch(decodedUrl, { headers: UNLOCK_HEADERS });
    if (!ajaxRes.ok) throw new Error(`AnimeDekho trdekho fetch failed: ${ajaxRes.status}`);
    const ajaxHtml = await ajaxRes.text();
    const $$ = cheerio.load(ajaxHtml);
    const src = $$("iframe").attr("src");
    return src ?? null;
  }

  return decodedUrl;
}
