import * as cheerio from "cheerio";
import { logger } from "./logger";

/**
 * Port of the "Abyass" ExtractorApi from the AnimeDekho Cloudstream plugin.
 *
 * Flow (reverse engineered from decompiled bytecode):
 *  1. GET the abyss embed page (e.g. https://abyssplayer.com/<id>) with
 *     headers pretending to come from playhydrax.com.
 *  2. Concatenate all <script> tag contents and pull out `const datas = "..."`.
 *  3. POST that encrypted string to https://enc-dec.app/api/dec-abyss as
 *     { text: "<encrypted>" } to get back the real source list.
 *  4. Filter sources with status === true and build playable stream links.
 */

const ABYSS_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
  Origin: "https://playhydrax.com",
  Referer: "https://playhydrax.com/",
};

const DATAS_REGEX = /const\s+datas\s*=\s*"([^"]*)"/;

interface AbyssSource {
  url: string;
  size: number;
  type: string;
  codec: string;
  status: boolean;
}

interface AbyssResponse {
  status: number;
  result: {
    sources: AbyssSource[];
  };
}

export interface AbyssStream {
  name: string;
  url: string;
  quality: string;
  codec: string;
  size: number;
  headers: Record<string, string>;
}

function getQualityFromName(type: string): string {
  const match = type.match(/(\d{3,4})p?/i);
  if (match) return `${match[1]}p`;
  return type || "Unknown";
}

/**
 * Resolves a raw abyssplayer.com / playhydrax.com embed URL into a list of
 * direct, playable stream URLs.
 */
export async function resolveAbyssStreams(embedUrl: string): Promise<AbyssStream[]> {
  const pageRes = await fetch(embedUrl, { headers: ABYSS_HEADERS });
  if (!pageRes.ok) {
    throw new Error(`Abyss embed page request failed: ${pageRes.status}`);
  }
  const html = await pageRes.text();
  const $ = cheerio.load(html);

  const scripts = $("script")
    .map((_, el) => $(el).text())
    .get()
    .join("\n");

  const match = scripts.match(DATAS_REGEX);
  if (!match || !match[1]) {
    logger.warn({ embedUrl }, "abyss: could not find encrypted datas string in page");
    return [];
  }
  const encrypted = match[1];

  const decRes = await fetch("https://enc-dec.app/api/dec-abyss", {
    method: "POST",
    headers: { ...ABYSS_HEADERS, "Content-Type": "application/json" },
    body: JSON.stringify({ text: encrypted }),
  });
  if (!decRes.ok) {
    throw new Error(`enc-dec.app request failed: ${decRes.status}`);
  }
  const decoded = (await decRes.json()) as AbyssResponse;

  const sources = decoded?.result?.sources ?? [];
  return sources
    .filter((source) => source.status)
    .map((source) => ({
      name: `Abyss [${source.codec?.toUpperCase?.() ?? source.codec}]`,
      url: source.url,
      quality: getQualityFromName(source.type),
      codec: source.codec,
      size: source.size,
      headers: { Referer: "https://playhydrax.com/" },
    }));
}
