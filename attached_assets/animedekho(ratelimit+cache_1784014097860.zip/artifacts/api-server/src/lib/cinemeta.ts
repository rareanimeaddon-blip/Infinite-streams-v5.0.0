/**
 * Minimal client for Stremio's community Cinemeta addon, used to translate a
 * Stremio content id (imdb id, optionally with :season:episode) into a
 * human-readable title + year we can search AnimeDekho with.
 */

export interface CinemetaMeta {
  name: string;
  year?: string;
  releaseInfo?: string;
}

export async function fetchCinemetaMeta(
  type: "movie" | "series",
  imdbId: string,
): Promise<CinemetaMeta | null> {
  const res = await fetch(`https://v3-cinemeta.strem.io/meta/${type}/${imdbId}.json`);
  if (!res.ok) return null;
  const data = (await res.json()) as { meta?: CinemetaMeta };
  if (!data?.meta?.name) return null;
  return data.meta;
}

export interface ParsedStremioId {
  imdbId: string;
  season?: number;
  episode?: number;
}

/** Parses ids like "tt1234567" or "tt1234567:1:2" (season:episode). */
export function parseStremioId(id: string): ParsedStremioId {
  const [imdbId, season, episode] = id.split(":");
  return {
    imdbId,
    season: season ? Number.parseInt(season, 10) : undefined,
    episode: episode ? Number.parseInt(episode, 10) : undefined,
  };
}
