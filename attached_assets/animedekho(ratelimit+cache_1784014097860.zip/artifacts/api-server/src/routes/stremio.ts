import { Router, type IRouter, type Request, type Response } from "express";
import { Readable } from "node:stream";
import { logger } from "../lib/logger";
import { fetchCinemetaMeta, parseStremioId } from "../lib/cinemeta";
import { searchAnime, pickBestMatch, getEpisodePage, getAbyssEmbedUrl } from "../lib/animedekho";
import { resolveAbyssStreams, type AbyssStream } from "../lib/abyss";

const router: IRouter = Router();

const MANIFEST = {
  id: "app.animedekho.abyss",
  version: "1.1.0",
  name: "AnimeDekho (Abyss)",
  description:
    "Resolves anime movie/episode streams from AnimeDekho via the Abyss player. Use alongside Cinemeta or another catalog addon.",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: [],
};

router.get("/manifest.json", (_req: Request, res: Response) => {
  res.json(MANIFEST);
});

// Short sliding-window cache of resolved Abyss streams, keyed by
// `${type}:${id}`. Purpose: a single "play" produces many HTTP range
// requests in a row (buffering/seeking) — without this, every single one
// of those would re-run the full search/scrape/decrypt chain, which is
// slow and risks getting *our own* lookups rate-limited by AnimeDekho /
// enc-dec.app. Each cache hit slides the expiry forward, so continuous
// playback keeps reusing the same resolve. Once requests stop for
// CACHE_TTL_MS (i.e. playback stopped, or "play" is pressed again later),
// the entry goes stale and the next request mints a completely fresh
// Abyss link — which is what actually fixes the Cloudflare block.
const CACHE_TTL_MS = 60_000;
const resolutionCache = new Map<string, { streams: AbyssStream[]; expiresAt: number }>();

function cacheKeyFor(type: string, id: string): string {
  return `${type}:${id}`;
}

async function resolveAbyssStreamsCached(
  type: "movie" | "series",
  id: string,
): Promise<AbyssStream[]> {
  const key = cacheKeyFor(type, id);
  const cached = resolutionCache.get(key);
  const now = Date.now();

  if (cached && cached.expiresAt > now) {
    cached.expiresAt = now + CACHE_TTL_MS; // slide the window forward
    return cached.streams;
  }

  const streams = await resolveFreshAbyssStreams(type, id);
  if (streams.length > 0) {
    resolutionCache.set(key, { streams, expiresAt: now + CACHE_TTL_MS });
  } else {
    resolutionCache.delete(key);
  }
  return streams;
}

/**
 * Runs the full AnimeDekho -> Abyss resolution chain from scratch. This is
 * only called directly by `/stream` (to build the initial quality list)
 * and by the cache-miss path above -- it always produces a brand new,
 * single-use Abyss token/URL.
 */
async function resolveFreshAbyssStreams(
  type: "movie" | "series",
  id: string,
): Promise<AbyssStream[]> {
  const { imdbId, season, episode } = parseStremioId(id);

  const meta = await fetchCinemetaMeta(type, imdbId);
  if (!meta) {
    logger.warn({ id }, "stremio: no cinemeta metadata found");
    return [];
  }

  const year = meta.year ?? meta.releaseInfo?.slice(0, 4);
  const results = await searchAnime(meta.name);
  const match = pickBestMatch(results, meta.name, year);
  if (!match) {
    logger.warn({ id, title: meta.name }, "stremio: no matching anime found on animedekho");
    return [];
  }

  let pageUrl: string;
  if (type === "series") {
    if (!season || !episode) {
      return [];
    }
    const episodeUrl = await getEpisodePage(match.url, season, episode);
    if (!episodeUrl) {
      logger.warn({ id, title: meta.name, season, episode }, "stremio: episode page not found");
      return [];
    }
    pageUrl = episodeUrl;
  } else {
    pageUrl = match.url;
  }

  const abyssEmbedUrl = await getAbyssEmbedUrl(pageUrl);
  if (!abyssEmbedUrl) {
    return [];
  }

  return resolveAbyssStreams(abyssEmbedUrl);
}

/** Stable-ish key used to re-locate "the same" quality on a later, fresh resolve. */
function qualityKey(stream: AbyssStream, index: number): string {
  const safeQuality = stream.quality.replace(/[^a-zA-Z0-9]/g, "");
  const safeCodec = (stream.codec || "unknown").replace(/[^a-zA-Z0-9]/g, "");
  return `${safeQuality}-${safeCodec}-${index}`;
}

function pickStreamByQualityKey(streams: AbyssStream[], key: string): AbyssStream | null {
  const exact = streams.find((stream, index) => qualityKey(stream, index) === key);
  if (exact) return exact;

  // Fresh resolves can shuffle order/count slightly; fall back to matching
  // just the quality label (ignoring codec/index) before giving up.
  const [qualityPart] = key.split("-");
  const sameQuality = streams.find(
    (stream) => stream.quality.replace(/[^a-zA-Z0-9]/g, "") === qualityPart,
  );
  return sameQuality ?? streams[0] ?? null;
}

router.get("/stream/:type/:id.json", async (req: Request, res: Response) => {
  const { type, id } = req.params as { type: string; id: string };

  // Never let Stremio (or any intermediary) cache this response -- every
  // play/replay must hit this handler again so a fresh token gets minted.
  res.set("Cache-Control", "no-store, no-cache, must-revalidate");

  if (type !== "movie" && type !== "series") {
    res.json({ streams: [] });
    return;
  }

  try {
    const abyssStreams = await resolveAbyssStreamsCached(type, id);

    const baseUrl = `${req.protocol}://${req.get("host")}/api`;

    const streams = abyssStreams.map((stream, index) => ({
      name: "AnimeDekho",
      title: `${stream.name} - ${stream.quality}`,
      // Point at our own proxy instead of the raw Abyss URL. The proxy
      // re-runs the whole resolution chain and mints a brand new
      // single-use link at the moment the player actually requests it,
      // instead of us handing out one link that gets reused (and rate
      // limited / blocked) across every subsequent play.
      url: `${baseUrl}/abyss-proxy/${type}/${encodeURIComponent(id)}/${qualityKey(stream, index)}`,
      behaviorHints: {
        bingeGroup: `animedekho-abyss-${stream.quality}`,
      },
    }));

    res.json({ streams });
  } catch (error) {
    logger.error({ err: error, id }, "stremio: failed to resolve streams");
    res.json({ streams: [] });
  }
});

/**
 * Proxy that actually serves the video bytes. Hit fresh on every playback
 * attempt (Stremio requests this URL each time the user presses play), so
 * every hit re-runs the full resolution chain and fetches a brand new
 * Abyss source + token server-side, then streams it through -- the client
 * device never talks to the Abyss/sssrr CDN directly, and never reuses an
 * already-consumed link.
 */
router.get(
  "/abyss-proxy/:type/:id/:quality",
  async (req: Request, res: Response) => {
    const { type, id, quality } = req.params as {
      type: string;
      id: string;
      quality: string;
    };

    if (type !== "movie" && type !== "series") {
      res.status(400).end();
      return;
    }

    // Ties the upstream fetch's lifetime to the client connection: if the
    // player stops/seeks and closes this request, we abort the upstream
    // fetch too instead of letting it dangle and then error out later.
    const abortController = new AbortController();
    req.on("close", () => abortController.abort());

    try {
      const abyssStreams = await resolveAbyssStreamsCached(type, id);
      if (abyssStreams.length === 0) {
        res.status(404).end();
        return;
      }

      const match = pickStreamByQualityKey(abyssStreams, quality);
      if (!match) {
        res.status(404).end();
        return;
      }

      const upstreamHeaders: Record<string, string> = { ...match.headers };
      const rangeHeader = req.headers.range;
      if (typeof rangeHeader === "string") {
        upstreamHeaders["Range"] = rangeHeader;
      }

      const upstream = await fetch(match.url, {
        headers: upstreamHeaders,
        signal: abortController.signal,
      });

      if (!upstream.ok && upstream.status !== 206) {
        logger.warn(
          { id, quality, status: upstream.status },
          "abyss-proxy: upstream fetch failed",
        );
        res.status(502).end();
        return;
      }

      res.status(upstream.status);
      res.set("Cache-Control", "no-store");
      for (const header of ["content-type", "content-length", "content-range", "accept-ranges"]) {
        const value = upstream.headers.get(header);
        if (value) res.setHeader(header, value);
      }

      if (!upstream.body) {
        res.end();
        return;
      }

      const upstreamStream = Readable.fromWeb(
        upstream.body as import("node:stream/web").ReadableStream,
      );

      // Client disconnects (seek/stop/pause) surface as errors on this
      // stream (socket closed, fetch aborted). Without this handler, that
      // error was unhandled and crashed the entire process. It's an
      // expected, routine event here -- just tear down quietly.
      upstreamStream.on("error", (err: NodeJS.ErrnoException) => {
        if (err?.name !== "AbortError") {
          logger.debug({ err, id, quality }, "abyss-proxy: upstream stream ended early");
        }
        if (!res.writableEnded) res.end();
      });
      res.on("error", () => {
        upstreamStream.destroy();
      });

      upstreamStream.pipe(res);
    } catch (error) {
      const err = error as NodeJS.ErrnoException;
      if (err?.name === "AbortError") {
        // Client disconnected before/while we were resolving -- nothing
        // to do, this is routine (seek/stop), not a failure.
        return;
      }
      logger.error({ err: error, id, quality }, "abyss-proxy: failed to resolve/stream");
      if (!res.headersSent) {
        res.status(502).end();
      } else {
        res.end();
      }
    }
  },
);

export default router;
