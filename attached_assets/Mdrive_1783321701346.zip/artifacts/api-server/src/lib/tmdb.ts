/**
 * TMDB API client
 * Handles movie/series lookups, IMDB ID resolution, and catalog fetching
 */

const TMDB_BASE = "https://api.themoviedb.org/3";
// Falls back to a widely-used public TMDB v3 demo key so the addon works
// out of the box. Set TMDB_API_KEY to use your own key instead.
const API_KEY = process.env.TMDB_API_KEY || "439c478a771f35c05022f9feabcca01c";

export interface TmdbMovie {
  id: number;
  title: string;
  original_title?: string;
  overview: string;
  release_date: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  vote_count: number;
  genre_ids?: number[];
  genres?: { id: number; name: string }[];
  imdb_id?: string;
  external_ids?: { imdb_id?: string };
}

export interface TmdbSeries {
  id: number;
  name: string;
  original_name?: string;
  overview: string;
  first_air_date: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  vote_count: number;
  genre_ids?: number[];
  genres?: { id: number; name: string }[];
  number_of_seasons?: number;
  external_ids?: { imdb_id?: string };
}

export interface FindResult {
  movie_results: TmdbMovie[];
  tv_results: TmdbSeries[];
}

async function tmdbFetch<T>(path: string, params: Record<string, string> = {}): Promise<T> {
  const url = new URL(`${TMDB_BASE}${path}`);
  url.searchParams.set("api_key", API_KEY);
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v);
  }
  const res = await fetch(url.toString(), {
    headers: { "Accept": "application/json" },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) throw new Error(`TMDB ${path} => ${res.status}`);
  return res.json() as Promise<T>;
}

/** Find by IMDB ID (tt...) */
export async function findByImdbId(imdbId: string): Promise<FindResult> {
  return tmdbFetch<FindResult>(`/find/${imdbId}`, { external_source: "imdb_id" });
}

/** Get movie details by TMDB ID */
export async function getMovie(tmdbId: number): Promise<TmdbMovie> {
  return tmdbFetch<TmdbMovie>(`/movie/${tmdbId}`, { append_to_response: "external_ids" });
}

/** Get series details by TMDB ID */
export async function getSeries(tmdbId: number): Promise<TmdbSeries> {
  return tmdbFetch<TmdbSeries>(`/tv/${tmdbId}`, { append_to_response: "external_ids" });
}

/** Search movies by title */
export async function searchMovies(query: string, year?: string): Promise<TmdbMovie[]> {
  const params: Record<string, string> = { query };
  if (year) params.year = year;
  const res = await tmdbFetch<{ results: TmdbMovie[] }>("/search/movie", params);
  return res.results || [];
}

/** Search series by title */
export async function searchSeries(query: string): Promise<TmdbSeries[]> {
  const res = await tmdbFetch<{ results: TmdbSeries[] }>("/search/tv", { query });
  return res.results || [];
}

/** Trending movies */
export async function trendingMovies(page = "1"): Promise<TmdbMovie[]> {
  const res = await tmdbFetch<{ results: TmdbMovie[] }>("/trending/movie/week", { page });
  return res.results || [];
}

/** Trending series */
export async function trendingSeries(page = "1"): Promise<TmdbSeries[]> {
  const res = await tmdbFetch<{ results: TmdbSeries[] }>("/trending/tv/week", { page });
  return res.results || [];
}

/** Build poster URL */
export function posterUrl(path: string | null | undefined): string {
  if (!path) return "https://via.placeholder.com/300x450/1a1a2e/ffffff?text=No+Image";
  return `https://image.tmdb.org/t/p/w500${path}`;
}

/** Build backdrop URL */
export function backdropUrl(path: string | null | undefined): string {
  if (!path) return "";
  return `https://image.tmdb.org/t/p/w1280${path}`;
}

/** Convert TMDB genres to string */
export function genreNames(genres?: { name: string }[]): string[] {
  return (genres || []).map((g) => g.name);
}
