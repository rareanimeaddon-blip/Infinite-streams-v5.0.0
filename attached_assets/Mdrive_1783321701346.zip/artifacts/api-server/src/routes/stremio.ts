/**
 * Stremio Addon Routes
 *
 * Install URL: https://{domain}/api/stremio/manifest.json
 *
 * Supports:
 * - Catalog: TMDB trending movies & series
 * - Meta: TMDB movie/series metadata
 * - Stream: MoviesDrive scraper → real download links
 */

import { Router } from "express";
import {
  findByImdbId,
  getMovie,
  getSeries,
  searchMovies,
  searchSeries,
  trendingMovies,
  trendingSeries,
  posterUrl,
  backdropUrl,
  genreNames,
} from "../lib/tmdb";
import { getStreams, type StreamLink } from "../lib/moviesdrive";

const router = Router();

// ─── In-memory stream cache (1 hour TTL) ─────────────────────────────────────
interface CacheEntry { streams: object[]; ts: number }
const STREAM_CACHE = new Map<string, CacheEntry>();
const CACHE_TTL = 60 * 60 * 1000; // 1 hour

function getCached(key: string): object[] | null {
  const entry = STREAM_CACHE.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_TTL) { STREAM_CACHE.delete(key); return null; }
  return entry.streams;
}

function setCached(key: string, streams: object[]): void {
  STREAM_CACHE.set(key, { streams, ts: Date.now() });
}

// ─── CORS helper ────────────────────────────────────────────────────────────
router.use((_req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  next();
});

// ─── Landing page ─────────────────────────────────────────────────────────────
router.get("/", (_req, res) => {
  res.setHeader("Content-Type", "text/html");
  res.send(LANDING_HTML);
});

// ─── Manifest ────────────────────────────────────────────────────────────────
const MANIFEST = {
  id: "com.moviesdrive.stremio.addon",
  version: "1.1.0",
  name: "MoviesDrive",
  description:
    "Stream movies and series from MoviesDrive. Supports IMDB, TMDB, and Cinemeta IDs. Multiple quality options from 720p to 4K.",
  logo: "https://new4.moviesdrives.my/wp-content/uploads/2026/01/cropped-Gemini_Generated_Image_qt93aqt93aqt93aq-1-192x192.png",
  resources: ["catalog", "meta", "stream"],
  types: ["movie", "series"],
  catalogs: [
    {
      type: "movie",
      id: "md-trending-movies",
      name: "MoviesDrive – Trending Movies",
      extra: [{ name: "search", isRequired: false }, { name: "genre", isRequired: false }, { name: "skip", isRequired: false }],
    },
    {
      type: "series",
      id: "md-trending-series",
      name: "MoviesDrive – Trending Series",
      extra: [{ name: "search", isRequired: false }, { name: "genre", isRequired: false }, { name: "skip", isRequired: false }],
    },
  ],
  idPrefixes: ["tt", "tmdb:"],
  behaviorHints: { adult: false, p2p: false },
};

router.get("/manifest.json", (_req, res) => {
  res.json(MANIFEST);
});

// ─── Catalog ──────────────────────────────────────────────────────────────────
router.get("/catalog/:type/:id.json", async (req, res) => {
  const { type } = req.params;
  const { search, skip } = req.query as Record<string, string>;
  const page = skip ? String(Math.floor(Number(skip) / 20) + 1) : "1";

  try {
    if (type === "movie") {
      let movies;
      if (search) {
        movies = await searchMovies(search);
      } else {
        movies = await trendingMovies(page);
      }

      const metas = await Promise.allSettled(
        movies.map(async (m) => {
          let imdbId = m.imdb_id;
          if (!imdbId) {
            try {
              const detail = await getMovie(m.id);
              imdbId = detail.external_ids?.imdb_id || detail.imdb_id;
            } catch { /* skip */ }
          }

          return {
            id: imdbId || `tmdb:${m.id}`,
            type: "movie",
            name: m.title,
            poster: posterUrl(m.poster_path),
            background: backdropUrl(m.backdrop_path),
            description: m.overview,
            releaseInfo: m.release_date?.slice(0, 4) || "",
            imdbRating: m.vote_average ? m.vote_average.toFixed(1) : undefined,
          };
        })
      );

      res.json({
        metas: metas.flatMap((r) => (r.status === "fulfilled" ? [r.value] : [])),
      });
    } else if (type === "series") {
      let series;
      if (search) {
        series = await searchSeries(search);
      } else {
        series = await trendingSeries(page);
      }

      const metas = await Promise.allSettled(
        series.map(async (s) => {
          let imdbId: string | undefined;
          try {
            const detail = await getSeries(s.id);
            imdbId = detail.external_ids?.imdb_id;
          } catch { /* skip */ }

          return {
            id: imdbId || `tmdb:${s.id}`,
            type: "series",
            name: s.name,
            poster: posterUrl(s.poster_path),
            background: backdropUrl(s.backdrop_path),
            description: s.overview,
            releaseInfo: s.first_air_date?.slice(0, 4) || "",
            imdbRating: s.vote_average ? s.vote_average.toFixed(1) : undefined,
          };
        })
      );

      res.json({
        metas: metas.flatMap((r) => (r.status === "fulfilled" ? [r.value] : [])),
      });
    } else {
      res.json({ metas: [] });
    }
  } catch {
    res.json({ metas: [] });
  }
});

// ─── Meta ─────────────────────────────────────────────────────────────────────
router.get("/meta/:type/:id.json", async (req, res) => {
  const { type, id } = req.params;

  try {
    if (type === "movie") {
      let detail;
      if (id.startsWith("tt")) {
        const found = await findByImdbId(id);
        const m = found.movie_results[0];
        if (!m) { res.json({ meta: null }); return; }
        detail = await getMovie(m.id);
      } else if (id.startsWith("tmdb:")) {
        detail = await getMovie(Number(id.slice(5)));
      } else {
        res.json({ meta: null }); return;
      }

      res.json({
        meta: {
          id,
          type: "movie",
          name: detail.title,
          poster: posterUrl(detail.poster_path),
          background: backdropUrl(detail.backdrop_path),
          description: detail.overview,
          releaseInfo: detail.release_date?.slice(0, 4) || "",
          imdbRating: detail.vote_average ? detail.vote_average.toFixed(1) : undefined,
          genres: genreNames(detail.genres),
        },
      });
    } else if (type === "series") {
      let detail;
      let imdbId = id;
      if (id.startsWith("tt")) {
        const found = await findByImdbId(id);
        const s = found.tv_results[0];
        if (!s) { res.json({ meta: null }); return; }
        detail = await getSeries(s.id);
      } else if (id.startsWith("tmdb:")) {
        detail = await getSeries(Number(id.slice(5)));
      } else {
        res.json({ meta: null }); return;
      }

      const extId = detail.external_ids?.imdb_id;
      if (extId) imdbId = extId;

      // Build seasons/episodes
      const videos: object[] = [];
      const numSeasons = detail.number_of_seasons || 1;
      for (let s = 1; s <= numSeasons; s++) {
        // We create placeholder episodes — real episode data needs another API call
        videos.push({
          id: `${imdbId}:${s}:1`,
          title: `Season ${s} Episode 1`,
          season: s,
          episode: 1,
        });
      }

      res.json({
        meta: {
          id: imdbId,
          type: "series",
          name: detail.name,
          poster: posterUrl(detail.poster_path),
          background: backdropUrl(detail.backdrop_path),
          description: detail.overview,
          releaseInfo: detail.first_air_date?.slice(0, 4) || "",
          imdbRating: detail.vote_average ? detail.vote_average.toFixed(1) : undefined,
          genres: genreNames(detail.genres),
          videos,
        },
      });
    } else {
      res.json({ meta: null });
    }
  } catch {
    res.json({ meta: null });
  }
});

// ─── Stream ───────────────────────────────────────────────────────────────────
router.get("/stream/:type/:id.json", async (req, res) => {
  const { type, id } = req.params;
  const isSeries = type === "series";

  // Stremio sends series ids as "<meta-id>:season:episode", e.g.
  // "tt1234567:4:4" OR "tmdb:687163:4:4". The meta id itself may contain a
  // colon (the "tmdb:" prefix), so a plain id.split(":") mis-parses it —
  // idParts[0] would be just "tmdb" and season/episode would be shifted by
  // one. Split off only the trailing ":season:episode" suffix instead.
  let baseId = id;
  let season: number | undefined;
  let episode: number | undefined;
  if (isSeries) {
    const seriesMatch = id.match(/^(.+):(\d+):(\d+)$/);
    if (seriesMatch) {
      baseId = seriesMatch[1];
      season = Number(seriesMatch[2]);
      episode = Number(seriesMatch[3]);
    }
  }

  // Cache key includes the full id (already includes season/episode for series)
  const cacheKey = `${type}:${id}`;
  const cached = getCached(cacheKey);
  if (cached) { res.json({ streams: cached }); return; }

  try {
    const { title, year, originalTitle, imdbId } = await resolveIdToTitle(type, baseId);
    if (!title) { res.json({ streams: [] }); return; }

    let streamLinks: StreamLink[] = await getStreams({
      title,
      year,
      imdbId,
      type: isSeries ? "series" : "movie",
      season,
      episode,
    });

    if (!streamLinks.length && originalTitle && originalTitle !== title) {
      streamLinks = await getStreams({
        title: originalTitle,
        year,
        imdbId,
        type: isSeries ? "series" : "movie",
        season,
        episode,
      });
    }

    const streams = streamLinks.map((sl) => ({
      name: `MoviesDrive\n${sl.quality}`,
      title: `${sl.size ? sl.size + " · " : ""}${sl.type}`,
      url: sl.url,
      behaviorHints: {
        // These are direct CDN links that require a specific Referer header
        // to play — Stremio can't play them as a plain web-native URL.
        notWebReady: true,
        bingeGroup: `moviesdrive-${baseId}`,
        proxyHeaders: {
          request: { Referer: "https://mdrive.lol/" },
        },
      },
    }));

    // Only cache non-empty results. Caching an empty result for a full hour
    // means a single transient failure (slow upstream, momentary Cloudflare
    // hiccup, etc.) gets "frozen" and every subsequent request replays the
    // same empty list even though the content is really there — this was
    // reported as "the site has it but the addon doesn't show streams".
    if (streams.length) setCached(cacheKey, streams);
    res.json({ streams });
  } catch (err) {
    req.log.error({ err }, "stremio stream route failed");
    res.json({ streams: [] });
  }
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function resolveIdToTitle(
  type: string,
  id: string
): Promise<{ title: string; year?: string; originalTitle?: string; imdbId?: string | null }> {
  try {
    if (id.startsWith("tt")) {
      const found = await findByImdbId(id);

      if (type === "movie" && found.movie_results.length) {
        const m = found.movie_results[0];
        const detail = await getMovie(m.id).catch(() => null);
        const originalTitle =
          detail?.original_title && detail.original_title !== m.title
            ? detail.original_title
            : undefined;
        return { title: m.title, year: m.release_date?.slice(0, 4), originalTitle, imdbId: id };
      }

      if (type === "series" && found.tv_results.length) {
        const s = found.tv_results[0];
        const detail = await getSeries(s.id).catch(() => null);
        const originalTitle =
          detail?.original_name && detail.original_name !== s.name
            ? detail.original_name
            : undefined;
        return { title: s.name, year: s.first_air_date?.slice(0, 4), originalTitle, imdbId: id };
      }

      // TMDB didn't know this IMDB ID — fall back to Cinemeta (same source as Stremio)
      const fallback = await cinemetaTitle(type, id);
      if (fallback.title) return { ...fallback, imdbId: id };

    } else if (id.startsWith("tmdb:")) {
      const tmdbId = Number(id.split(":")[1]);
      if (type === "movie") {
        const m = await getMovie(tmdbId);
        const originalTitle =
          m.original_title && m.original_title !== m.title ? m.original_title : undefined;
        return {
          title: m.title,
          year: m.release_date?.slice(0, 4),
          originalTitle,
          imdbId: m.external_ids?.imdb_id || m.imdb_id || null,
        };
      } else {
        const s = await getSeries(tmdbId);
        const originalTitle =
          s.original_name && s.original_name !== s.name ? s.original_name : undefined;
        return {
          title: s.name,
          year: s.first_air_date?.slice(0, 4),
          originalTitle,
          imdbId: s.external_ids?.imdb_id || null,
        };
      }
    }
  } catch { /* fall through */ }
  return { title: "" };
}

/**
 * Last-resort title resolution via Cinemeta — the exact metadata source Stremio
 * uses, so any ID Stremio sends will resolve here even if TMDB hasn't indexed it.
 */
async function cinemetaTitle(
  type: string,
  imdbId: string
): Promise<{ title: string; year?: string }> {
  try {
    const ctype = type === "series" ? "series" : "movie";
    const res = await fetch(
      `https://v3-cinemeta.strem.io/meta/${ctype}/${imdbId}.json`,
      { signal: AbortSignal.timeout(8000) }
    );
    if (!res.ok) return { title: "" };
    const j = await res.json() as { meta?: { name?: string; year?: number | string; releaseInfo?: string } };
    const meta = j.meta;
    if (!meta?.name) return { title: "" };
    const year =
      String(meta.year || meta.releaseInfo || "").match(/\d{4}/)?.[0] ?? undefined;
    return { title: meta.name, year };
  } catch { return { title: "" }; }
}

// ─── Landing page HTML ────────────────────────────────────────────────────────
const LANDING_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MoviesDrive Stremio Addon</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0f0f1a;color:#e0e0f0;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:40px 20px}
  .logo{font-size:56px;margin-bottom:12px}
  h1{font-size:2.2rem;font-weight:700;color:#fff}
  .subtitle{color:#9090b0;margin-top:8px;font-size:1.1rem}
  .badge-row{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap;justify-content:center}
  .badge{background:#1e1e33;border:1px solid #2d2d4e;border-radius:20px;padding:5px 14px;font-size:.85rem;color:#8080c0}
  .install-box{background:#1a1a2e;border:1px solid #2d2d50;border-radius:16px;padding:32px;max-width:640px;width:100%;margin-top:40px}
  .install-box h2{color:#a0a0ff;font-size:1.1rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:20px}
  .step{display:flex;gap:16px;align-items:flex-start;margin-bottom:20px}
  .step-num{background:#6060c0;color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;flex-shrink:0}
  .step-content h3{font-size:1rem;color:#d0d0ff;margin-bottom:4px}
  .step-content p{color:#8080a0;font-size:.9rem;line-height:1.5}
  .url-box{background:#0d0d1a;border:1px solid #3535ff44;border-radius:10px;padding:14px 18px;margin-top:24px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}
  .url-text{font-family:monospace;font-size:.9rem;color:#8080ff;word-break:break-all;flex:1}
  .copy-btn{background:#4040aa;color:#fff;border:none;border-radius:8px;padding:8px 16px;cursor:pointer;font-size:.85rem;white-space:nowrap}
  .copy-btn:hover{background:#5050cc}
  .install-btn{display:block;background:linear-gradient(135deg,#6060c0,#4040a0);color:#fff;text-decoration:none;border-radius:12px;padding:14px 28px;text-align:center;font-size:1.1rem;font-weight:600;margin-top:20px;transition:opacity .2s}
  .install-btn:hover{opacity:.85}
  .features{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;max-width:640px;width:100%;margin-top:32px}
  .feature-card{background:#1a1a2e;border:1px solid #2a2a45;border-radius:12px;padding:20px}
  .feature-icon{font-size:1.8rem;margin-bottom:10px}
  .feature-card h3{color:#c0c0ff;font-size:.95rem;margin-bottom:6px}
  .feature-card p{color:#7070a0;font-size:.82rem;line-height:1.4}
  .footer{margin-top:48px;color:#505070;font-size:.8rem;text-align:center}
</style>
</head>
<body>
<div class="logo">🎬</div>
<h1>MoviesDrive Addon</h1>
<p class="subtitle">for Stremio</p>
<div class="badge-row">
  <span class="badge">IMDB IDs</span>
  <span class="badge">TMDB IDs</span>
  <span class="badge">Cinemeta</span>
  <span class="badge">720p – 4K</span>
  <span class="badge">Hindi + English</span>
</div>
<div class="install-box">
  <h2>How to Install</h2>
  <div class="step">
    <div class="step-num">1</div>
    <div class="step-content">
      <h3>Open Stremio</h3>
      <p>Launch the Stremio app on any device — Windows, Mac, Linux, Android, or iOS.</p>
    </div>
  </div>
  <div class="step">
    <div class="step-num">2</div>
    <div class="step-content">
      <h3>Go to Addons</h3>
      <p>Click the puzzle icon (🧩) in the top menu to open the Addons section.</p>
    </div>
  </div>
  <div class="step">
    <div class="step-num">3</div>
    <div class="step-content">
      <h3>Install via URL</h3>
      <p>Click "Community Addons" → paste the manifest URL below → click Install.</p>
    </div>
  </div>
  <div class="url-box">
    <span class="url-text" id="manifest-url">Loading...</span>
    <button class="copy-btn" onclick="copyUrl()">Copy</button>
  </div>
  <a id="install-link" href="#" class="install-btn">⚡ Open in Stremio</a>
</div>
<div class="features">
  <div class="feature-card">
    <div class="feature-icon">🔍</div>
    <h3>Smart Search</h3>
    <p>Finds movies and series from MoviesDrive by IMDB or TMDB ID automatically.</p>
  </div>
  <div class="feature-card">
    <div class="feature-icon">📺</div>
    <h3>Multiple Qualities</h3>
    <p>720p, 1080p, and 4K UHD streams with file size shown.</p>
  </div>
  <div class="feature-card">
    <div class="feature-icon">🎯</div>
    <h3>Season/Episode Aware</h3>
    <p>Correctly scopes results to the exact season and episode requested.</p>
  </div>
  <div class="feature-card">
    <div class="feature-icon">🌍</div>
    <h3>Hindi + English</h3>
    <p>Dual-audio Bollywood, Hollywood, and South Indian films.</p>
  </div>
  <div class="feature-card">
    <div class="feature-icon">📡</div>
    <h3>TMDB Catalog</h3>
    <p>Trending movies and series catalog powered by TMDB.</p>
  </div>
  <div class="feature-card">
    <div class="feature-icon">🆔</div>
    <h3>Cinemeta Compatible</h3>
    <p>Works with Cinemeta and any addon using IMDB or TMDB IDs.</p>
  </div>
</div>
<div class="footer"><p>MoviesDrive Stremio Addon · For personal use only</p></div>
<script>
  const base = window.location.origin + window.location.pathname.replace(/\\/+$/, '');
  const manifestUrl = base + '/manifest.json';
  document.getElementById('manifest-url').textContent = manifestUrl;
  document.getElementById('install-link').href = 'stremio://' + manifestUrl.replace(/^https?:\\/\\//, '');
  function copyUrl() {
    navigator.clipboard.writeText(manifestUrl).then(() => {
      const btn = document.querySelector('.copy-btn');
      btn.textContent = 'Copied!';
      setTimeout(() => btn.textContent = 'Copy', 2000);
    });
  }
</script>
</body>
</html>`;

export default router;
