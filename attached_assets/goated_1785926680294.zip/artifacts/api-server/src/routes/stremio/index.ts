import { Router, type IRouter, type Request, type Response } from 'express';
import { manifest } from './manifest.js';
import { catalogTmdb, metaTmdb, toTmdbId } from './tmdb.js';
import { resolve, toStreams } from './sources.js';
import proxyRouter from './proxy.js';

const router: IRouter = Router();

router.use(proxyRouter);

const CACHE_TTL = Number(process.env.CACHE_TTL_MS || 10 * 60 * 1000);
const cache = new Map<string, { value: unknown; expires: number }>();

async function cached<T>(key: string, fn: () => Promise<T>, ttl = CACHE_TTL): Promise<T> {
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return hit.value as T;
  const value = await fn();
  cache.set(key, { value, expires: Date.now() + ttl });
  return value;
}

function parseExtra(segment: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (!segment) return out;
  const decoded = decodeURIComponent(segment);
  for (const pair of decoded.split('&')) {
    const [k, ...rest] = pair.split('=');
    if (k) out[k] = decodeURIComponent(rest.join('='));
  }
  return out;
}

/** "tmdb:1399:1:2" -> ["tmdb:1399","1","2"]; "tt0944947:1:2" -> ["tt0944947","1","2"] */
function splitId(rawId: string): [string, string | undefined, string | undefined] {
  const parts = rawId.split(':');
  if (parts[0] === 'tmdb') return [`tmdb:${parts[1]}`, parts[2], parts[3]];
  return [parts[0], parts[1], parts[2]];
}

// GET /api/manifest.json
router.get('/manifest.json', (_req: Request, res: Response) => {
  res.json(manifest);
});

// GET /api/ — install page
router.get('/', (req: Request, res: Response) => {
  const origin = `${req.protocol}://${req.headers.host}`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(
    `<!doctype html><meta charset="utf-8"><title>${manifest.name} add-on</title>` +
    `<body style="font-family:system-ui;background:#0b0b0f;color:#eee;padding:40px">` +
    `<h1>${manifest.name}</h1><p>${manifest.description}</p>` +
    `<p>Manifest URL: <code>${origin}/api/manifest.json</code></p>` +
    `<p><a style="color:#8ab4ff" href="stremio://${req.headers.host}/api/manifest.json">Install in Stremio</a></p></body>`,
  );
});

// GET /api/catalog/:type/:catalogId.json  or  /api/catalog/:type/:catalogId/:extra.json
router.get('/catalog/:type/*catalogId', async (req: Request, res: Response) => {
  try {
    const type = String(req.params.type);
    const rawPath = String(req.params.catalogId);
    const segments = rawPath.split('/');
    const catalogId = segments[0].replace(/\.json$/, '');
    const extraSegment = segments.length > 1 ? segments[segments.length - 1].replace(/\.json$/, '') : '';
    const extra = parseExtra(extraSegment);

    const metas = await cached(`cat:${type}:${catalogId}:${JSON.stringify(extra)}`, () =>
      catalogTmdb(type, catalogId, extra),
    );
    res.json({ metas });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/meta/:type/:id.json
router.get('/meta/:type/*id', async (req: Request, res: Response) => {
  try {
    const type = String(req.params.type);
    const id = String(req.params.id).replace(/\.json$/, '');
    const data = await cached(`meta:${type}:${id}`, () => metaTmdb(type, id));
    if (!data) { res.status(404).json({ meta: null }); return; }
    res.json({ meta: data });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/stream/:type/:id.json
router.get('/stream/:type/*id', async (req: Request, res: Response) => {
  try {
    const type = String(req.params.type);
    const rawId = String(req.params.id).replace(/\.json$/, '');
    const [baseId, seasonStr, episodeStr] = splitId(rawId);

    const tmdbId = await toTmdbId(type, baseId);
    if (!tmdbId) { res.json({ streams: [] }); return; }

    const isTv = type === 'series';
    const resolved = await resolve({
      type: isTv ? 'tv' : 'movie',
      tmdbId,
      season: isTv ? Number(seasonStr) || 1 : undefined,
      episode: isTv ? Number(episodeStr) || 1 : undefined,
    });

    const title = isTv ? `S${seasonStr || 1}E${episodeStr || 1}` : '';
    const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = (req.headers['x-forwarded-host'] as string) || req.headers.host || '';
    const proxyBase = `${proto}://${host}/api/proxy`;
    res.setHeader('Cache-Control', 'public, max-age=60');
    res.json({ streams: toStreams(resolved, title, proxyBase) });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
});

export default router;
