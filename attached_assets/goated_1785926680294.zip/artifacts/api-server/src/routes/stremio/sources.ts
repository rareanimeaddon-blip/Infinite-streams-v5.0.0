import { getStreams } from './goated.js';

function isPlayable(url: unknown): url is string {
  if (typeof url !== 'string') return false;
  if (!/^https?:\/\//i.test(url)) return false;
  const clean = url.split('?')[0].toLowerCase();
  return (
    /\.(m3u8|mp4|mkv|webm|mpd)(\/|$)/.test(clean) ||
    /\/(hls|manifest|playlist)\//.test(clean) ||
    /m3u8-proxy/.test(url)
  );
}

interface Source {
  url: string;
  quality?: string;
  label?: string;
  type?: string;
  headers?: Record<string, string>;
}

export async function resolve(params: {
  type: string;
  tmdbId: number;
  season?: number;
  episode?: number;
}): Promise<Source[]> {
  if (process.env.DISABLE_GOATED === '1') return [];
  const streams: Source[] = await getStreams(params).catch(() => []);
  const seen = new Set<string>();
  return streams.filter((s) => isPlayable(s.url) && !seen.has(s.url) && seen.add(s.url));
}

/**
 * Map resolved sources to Stremio stream objects.
 * All stream URLs are routed through our own HLS proxy so that
 * required Referer/Origin headers are added server-side — this
 * makes streams work on Stremio mobile without needing proxyHeaders.
 */
export function toStreams(sources: Source[], title: string, proxyBase: string) {
  return sources.map((s, i) => {
    const proxiedUrl = `${proxyBase}?url=${encodeURIComponent(s.url)}`;
    return {
      url: proxiedUrl,
      name: `Goated\n${s.quality || 'auto'}`,
      description: [title, s.label].filter(Boolean).join('\n'),
      behaviorHints: {
        bingeGroup: i === 0 ? 'goated-best' : `goated-${s.quality || 'auto'}`,
        notWebReady: false,
      },
    };
  });
}
