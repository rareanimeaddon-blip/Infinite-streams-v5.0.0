const TMDB_BASE = (process.env.TMDB_BASE_URL || 'https://api.themoviedb.org/3').replace(/\/$/, '');
const IMG = 'https://image.tmdb.org/t/p';
const DEFAULT_TMDB_KEY = 'aa8db17cefbe569dc21a8809090b7b93';

function tmdbKey(): string {
  return process.env.TMDB_API_KEY || DEFAULT_TMDB_KEY;
}

export async function tmdbFetch(path: string, params: Record<string, string | number | undefined> = {}): Promise<unknown> {
  const url = new URL(TMDB_BASE + path);
  url.searchParams.set('api_key', tmdbKey());
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }
  const res = await fetch(url.toString(), { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`TMDB ${path} failed: ${res.status}`);
  return res.json();
}

const poster = (p?: string) => (p ? `${IMG}/w500${p}` : undefined);
const background = (p?: string) => (p ? `${IMG}/original${p}` : undefined);
const logo = (p?: string) => (p ? `${IMG}/original${p}` : undefined);

export async function toTmdbId(type: string, id: string): Promise<number | null> {
  if (/^tmdb:/i.test(id)) return Number(id.split(':')[1]);
  if (/^tt\d+$/i.test(id)) {
    const found = await tmdbFetch(`/find/${id}`, { external_source: 'imdb_id' }) as Record<string, unknown[]>;
    const list = (type === 'series' ? found.tv_results : found.movie_results) as Record<string, unknown>[];
    if (list && list[0]) return (list[0] as { id: number }).id;
    const other = (type === 'series' ? found.movie_results : found.tv_results) as Record<string, unknown>[];
    if (other && other[0]) return (other[0] as { id: number }).id;
    return null;
  }
  const n = Number(id);
  return Number.isFinite(n) ? n : null;
}

function toMetaPreview(item: Record<string, unknown>, type: string) {
  const isTv = type === 'series';
  return {
    id: `tmdb:${item.id}`,
    type,
    name: isTv ? item.name : item.title,
    poster: poster(item.poster_path as string | undefined),
    posterShape: 'poster',
    background: background(item.backdrop_path as string | undefined),
    description: (item.overview as string) || undefined,
    releaseInfo: ((isTv ? item.first_air_date : item.release_date) as string || '').slice(0, 4) || undefined,
    imdbRating: (item.vote_average as number) ? (item.vote_average as number).toFixed(1) : undefined,
  };
}

export async function catalogTmdb(type: string, catalogId: string, extra: Record<string, string>) {
  const isTv = type === 'series';
  const page = Math.floor((Number(extra.skip) || 0) / 20) + 1;

  if (extra.search) {
    const data = await tmdbFetch(isTv ? '/search/tv' : '/search/movie', {
      query: extra.search,
      page,
      include_adult: 'false',
    }) as { results: Record<string, unknown>[] };
    return data.results.map((r) => toMetaPreview(r, type));
  }

  let path: string;
  const params: Record<string, string | number | undefined> = { page };
  switch (catalogId) {
    case 'goated-trending':
      path = isTv ? '/trending/tv/week' : '/trending/movie/week';
      break;
    case 'goated-popular':
      path = isTv ? '/tv/popular' : '/movie/popular';
      break;
    case 'goated-top':
      path = isTv ? '/discover/tv' : '/discover/movie';
      params.sort_by = 'vote_average.desc';
      params['vote_count.gte'] = 500;
      break;
    default:
      path = isTv ? '/trending/tv/week' : '/trending/movie/week';
  }

  if (extra.genre) {
    const genres = await tmdbFetch(isTv ? '/genre/tv/list' : '/genre/movie/list') as { genres: { id: number; name: string }[] };
    const g = genres.genres.find((x) => x.name.toLowerCase() === String(extra.genre).toLowerCase());
    if (g) {
      path = isTv ? '/discover/tv' : '/discover/movie';
      params.with_genres = g.id;
    }
  }

  const data = await tmdbFetch(path, params) as { results: Record<string, unknown>[] };
  return data.results.map((r) => toMetaPreview(r, type));
}

export async function metaTmdb(type: string, id: string) {
  const tmdbId = await toTmdbId(type, id);
  if (!tmdbId) return null;
  const isTv = type === 'series';
  const detail = await tmdbFetch(isTv ? `/tv/${tmdbId}` : `/movie/${tmdbId}`, {
    append_to_response: 'images,videos,credits,external_ids',
    include_image_language: 'en,null',
  }) as Record<string, unknown>;

  const base: Record<string, unknown> = {
    id,
    type,
    name: isTv ? detail.name : detail.title,
    poster: poster(detail.poster_path as string | undefined),
    background: background(detail.backdrop_path as string | undefined),
    logo: logo(((detail.images as Record<string, unknown>)?.logos as Record<string, string>[])?.[0]?.file_path),
    description: (detail.overview as string) || undefined,
    releaseInfo: ((isTv ? detail.first_air_date : detail.release_date) as string || '').slice(0, 4) || undefined,
    imdbRating: (detail.vote_average as number) ? (detail.vote_average as number).toFixed(1) : undefined,
    genres: ((detail.genres as { name: string }[]) || []).map((g) => g.name),
    cast: (((detail.credits as Record<string, unknown>)?.cast as { name: string }[]) || []).slice(0, 8).map((c) => c.name),
    director: (((detail.credits as Record<string, unknown>)?.crew as { job: string; name: string }[]) || [])
      .filter((c) => c.job === 'Director')
      .map((c) => c.name),
    runtime: isTv
      ? (detail.episode_run_time as number[])?.[0]
        ? `${(detail.episode_run_time as number[])[0]} min`
        : undefined
      : (detail.runtime as number)
        ? `${detail.runtime} min`
        : undefined,
    trailers: ((((detail.videos as Record<string, unknown>)?.results as { site: string; type: string; key: string }[]) || [])
      .filter((v) => v.site === 'YouTube' && v.type === 'Trailer')
      .slice(0, 3)
      .map((v) => ({ source: v.key, type: 'Trailer' }))),
    behaviorHints: { defaultVideoId: isTv ? undefined : id, hasScheduledVideos: isTv },
  };

  if (!isTv) return base;

  const seasons = ((detail.seasons as { season_number: number }[]) || []).filter((s) => s.season_number > 0);
  const videos: unknown[] = [];
  for (const s of seasons) {
    const season = await tmdbFetch(`/tv/${tmdbId}/season/${s.season_number}`).catch(() => null) as Record<string, unknown> | null;
    if (!season) continue;
    for (const ep of (season.episodes as Record<string, unknown>[]) || []) {
      videos.push({
        id: `${id}:${ep.season_number}:${ep.episode_number}`,
        title: ep.name,
        season: ep.season_number,
        episode: ep.episode_number,
        released: ep.air_date ? new Date(ep.air_date as string).toISOString() : undefined,
        overview: (ep.overview as string) || undefined,
        thumbnail: ep.still_path ? `${IMG}/w300${ep.still_path}` : undefined,
      });
    }
  }
  base.videos = videos;
  return base;
}
