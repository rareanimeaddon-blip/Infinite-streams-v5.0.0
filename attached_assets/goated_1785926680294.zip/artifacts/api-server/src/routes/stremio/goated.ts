import { createHash } from 'crypto';

const API = process.env.GOATED_API || 'https://api.reallyfast.xyz';
const TIMEOUT_MS = Number(process.env.SOURCE_TIMEOUT_MS || 20000);

export const PLAYBACK_HEADERS: Record<string, string> = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  Referer: 'https://goated.cx/',
  Origin: 'https://goated.cx',
};

const HEADERS: Record<string, string> = {
  ...PLAYBACK_HEADERS,
  'Content-Type': 'application/json',
  Accept: 'application/json',
};

async function fetchT(url: string, options: RequestInit = {}, timeout = TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function solveChallenge(): Promise<{ challenge: string; nonce: string }> {
  const res = await fetchT(`${API}/api/challenge`, { headers: PLAYBACK_HEADERS });
  if (!res.ok) throw new Error(`challenge failed: ${res.status}`);
  const { challenge, difficulty } = await res.json() as { challenge: string; difficulty: number };
  const prefix = '0'.repeat(difficulty);
  for (let nonce = 0; nonce < 5e6; nonce++) {
    if (createHash('sha256').update(challenge + nonce).digest('hex').startsWith(prefix)) {
      return { challenge, nonce: String(nonce) };
    }
  }
  throw new Error('proof-of-work timed out');
}

async function resolveOnce(body: Record<string, unknown>): Promise<Record<string, unknown> | null> {
  try {
    const pow = await solveChallenge();
    const res = await fetchT(`${API}/api/resolve`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({ ...body, ...pow }),
    });
    if (!res.ok) return null;
    const data = await res.json() as Record<string, unknown>;
    return data && data.url ? data : null;
  } catch {
    return null;
  }
}

interface StreamResult {
  url: string;
  quality: string;
  label: string;
  type: string;
  headers: Record<string, string>;
}

const RANKS: [RegExp, number][] = [
  [/auto/i, 0],
  [/2160|4k|uhd/i, 1],
  [/1080/i, 2],
  [/720/i, 3],
];
const rank = (q = '') => (RANKS.find(([re]) => re.test(q)) || [null, 4])[1];

export async function getStreams({
  tmdbId,
  type,
  season,
  episode,
}: {
  tmdbId: number;
  type: string;
  season?: number;
  episode?: number;
}): Promise<StreamResult[]> {
  const isTv = type === 'tv' || type === 'series';
  const body: Record<string, unknown> = {
    mediaType: isTv ? 'tv' : 'movie',
    id: String(tmdbId),
    ...(isTv ? { season: season || 1, episode: episode || 1 } : {}),
  };

  const first = await resolveOnce(body);
  if (!first) return [];

  const others = ((first.availableSources as string[]) || []).filter((s) => s !== first.source);
  const rest = await Promise.all(others.map((source) => resolveOnce({ ...body, source })));

  const out: StreamResult[] = [];
  const seen = new Set<string>();
  for (const r of [first, ...rest.filter(Boolean)] as Record<string, unknown>[]) {
    if (!r.url || seen.has(r.url as string)) continue;
    seen.add(r.url as string);
    const isHls = r.format === 'hls' || (r.url as string).includes('.m3u8');
    out.push({
      url: r.url as string,
      quality: isHls ? 'Auto (up to 4K)' : '1080p',
      label: `Goated [${r.source}]`,
      type: isHls ? 'hls' : 'video',
      headers: PLAYBACK_HEADERS,
    });
  }

  return out.sort((a, b) => rank(a.quality) - rank(b.quality));
}
