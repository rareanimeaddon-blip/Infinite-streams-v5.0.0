export const manifest = {
  id: 'community.goated.addon',
  version: '1.0.0',
  name: 'Goated',
  description:
    'Movies and series catalogs from TMDB with streams from both goated.cx servers (Orbit and Valenox). Playback happens inside the Stremio player only.',
  logo: 'https://goated.cx/favicon.ico',
  background: 'https://image.tmdb.org/t/p/original/vjMvFSmGUxEtqVdaZgvFee9XkZl.jpg',
  resources: ['catalog', 'meta', 'stream'],
  types: ['movie', 'series'],
  idPrefixes: ['tt', 'tmdb:'],
  catalogs: [
    {
      type: 'movie',
      id: 'goated-trending',
      name: 'Goated Trending',
      extra: [{ name: 'search' }, { name: 'genre' }, { name: 'skip' }],
    },
    {
      type: 'movie',
      id: 'goated-popular',
      name: 'Goated Popular Movies',
      extra: [{ name: 'genre' }, { name: 'skip' }],
    },
    {
      type: 'movie',
      id: 'goated-top',
      name: 'Goated Top Rated Movies',
      extra: [{ name: 'genre' }, { name: 'skip' }],
    },
    {
      type: 'series',
      id: 'goated-trending',
      name: 'Goated Trending Shows',
      extra: [{ name: 'search' }, { name: 'genre' }, { name: 'skip' }],
    },
    {
      type: 'series',
      id: 'goated-popular',
      name: 'Goated Popular Shows',
      extra: [{ name: 'genre' }, { name: 'skip' }],
    },
    {
      type: 'series',
      id: 'goated-top',
      name: 'Goated Top Rated Shows',
      extra: [{ name: 'genre' }, { name: 'skip' }],
    },
  ],
  behaviorHints: { configurable: false, adult: false, p2p: false },
};
