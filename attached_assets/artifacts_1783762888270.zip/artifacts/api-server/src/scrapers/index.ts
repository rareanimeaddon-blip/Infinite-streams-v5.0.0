/**
 * Combined scraper — runs all engines in parallel and merges results.
 */

import type { StremioStream, AddonConfig } from "./types.js";
import { resolveByIMDB } from "./tmdb.js";
import { getMovies4uStreams } from "./movies4u.js";
import { getCastleStreams } from "./castle.js";
import { getCineFreakStreams } from "./cinefreak.js";
import { logger } from "../lib/logger.js";

export type { StremioStream, AddonConfig };

export async function getAllStreams(
  imdbId: string,
  type: "movie" | "series",
  season?: number,
  episode?: number,
  config: AddonConfig = {},
): Promise<StremioStream[]> {
  const s = season ?? 1;
  const e = episode ?? 1;

  // Resolve TMDB ID from IMDB ID (needed for Castle and CineFreak)
  const tmdbInfo = await resolveByIMDB(imdbId, type);
  const tmdbId = tmdbInfo?.tmdbId ?? 0;

  // Run all three scrapers in parallel
  const [movies4uStreams, castleStreams, cineFreakStreams] =
    await Promise.allSettled([
      getMovies4uStreams(imdbId, type, s, e),
      tmdbId
        ? getCastleStreams(tmdbId, type, s, e)
        : Promise.resolve([] as StremioStream[]),
      tmdbId
        ? getCineFreakStreams(tmdbId, type, s, e)
        : Promise.resolve([] as StremioStream[]),
    ]);

  const streams: StremioStream[] = [];

  if (movies4uStreams.status === "fulfilled") {
    streams.push(...movies4uStreams.value);
  } else {
    logger.error({ err: movies4uStreams.reason, imdbId }, "movies4u scraper failed");
  }
  if (castleStreams.status === "fulfilled") {
    streams.push(...castleStreams.value);
  } else {
    logger.error({ err: castleStreams.reason, imdbId }, "castle scraper failed");
  }
  if (cineFreakStreams.status === "fulfilled") {
    streams.push(...cineFreakStreams.value);
  } else {
    logger.error({ err: cineFreakStreams.reason, imdbId }, "cinefreak scraper failed");
  }

  return streams;
}
