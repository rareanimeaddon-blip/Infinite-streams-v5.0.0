const TMDB_API_KEY = "439c478a771f35c05022f9feabcca01c";
const TMDB_BASE = "https://api.themoviedb.org/3";

const BROWSER_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
  Accept: "application/json",
};

export interface TMDBDetails {
  tmdbId: number;
  title: string;
  year: string | null;
  imdbId: string;
  runtime: number;
  type: "movie" | "series";
}

/** Resolve a TMDB entry from an IMDB ID using the /find endpoint */
export async function resolveByIMDB(
  imdbId: string,
  type: "movie" | "series",
): Promise<TMDBDetails | null> {
  try {
    const res = await fetch(
      `${TMDB_BASE}/find/${imdbId}?external_source=imdb_id&api_key=${TMDB_API_KEY}`,
      { headers: BROWSER_HEADERS },
    );
    if (!res.ok) return null;
    const data = (await res.json()) as {
      movie_results: Array<{
        id: number;
        title?: string;
        name?: string;
        release_date?: string;
        first_air_date?: string;
      }>;
      tv_results: Array<{
        id: number;
        name?: string;
        title?: string;
        first_air_date?: string;
        release_date?: string;
      }>;
    };
    const results =
      type === "movie" ? data.movie_results : data.tv_results;
    if (!results || results.length === 0) return null;
    const entry = results[0];
    if (!entry) return null;

    const dateStr =
      (entry as { release_date?: string; first_air_date?: string })
        .release_date ||
      (entry as { first_air_date?: string }).first_air_date ||
      "";
    const year = dateStr.split("-")[0] || null;

    return {
      tmdbId: entry.id,
      title: (entry.title ?? entry.name) || "",
      year,
      imdbId,
      runtime: 0,
      type,
    };
  } catch {
    return null;
  }
}

/** Fetch TMDB details directly by TMDB ID (for scrapers that want title/year) */
export async function getTMDBDetails(
  tmdbId: number,
  type: "movie" | "series",
  season = 1,
  episode = 1,
): Promise<TMDBDetails | null> {
  try {
    const endpoint = type === "series" ? "tv" : "movie";
    const res = await fetch(
      `${TMDB_BASE}/${endpoint}/${tmdbId}?api_key=${TMDB_API_KEY}&append_to_response=external_ids`,
      { headers: BROWSER_HEADERS },
    );
    if (!res.ok) return null;
    const data = (await res.json()) as {
      id: number;
      title?: string;
      name?: string;
      release_date?: string;
      first_air_date?: string;
      runtime?: number;
      episode_run_time?: number[];
      external_ids?: { imdb_id?: string };
    };

    const dateStr = data.release_date ?? data.first_air_date ?? "";
    const year = dateStr.split("-")[0] || null;
    const title = data.title ?? data.name ?? "";
    const imdbId = data.external_ids?.imdb_id ?? "";

    let runtime = data.runtime ?? 0;
    if (type === "series") {
      runtime = data.episode_run_time?.[0] ?? 45;
      // Try to get episode-specific runtime
      try {
        const epRes = await fetch(
          `${TMDB_BASE}/tv/${tmdbId}/season/${season}/episode/${episode}?api_key=${TMDB_API_KEY}`,
          { headers: BROWSER_HEADERS },
        );
        if (epRes.ok) {
          const epData = (await epRes.json()) as { runtime?: number };
          if (epData.runtime) runtime = epData.runtime;
        }
      } catch {
        // ignore
      }
    }

    return { tmdbId, title, year, imdbId, runtime, type };
  } catch {
    return null;
  }
}
