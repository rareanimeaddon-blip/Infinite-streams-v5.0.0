/** A stream object returned to Stremio */
export interface StremioStream {
  /** Provider label shown in Stremio source picker */
  name?: string;
  /** Multi-line details block shown below the name */
  title?: string;
  /** Direct playable URL (m3u8, mp4, etc.) */
  url: string;
  /** Behaviour hints passed to the Stremio player */
  behaviorHints?: {
    /** True if the stream requires a native player (not web-ready HLS) */
    notWebReady?: boolean;
    /** Group key for binge-watching auto-play */
    bingeGroup?: string;
    /** Headers to inject into player requests */
    proxyHeaders?: {
      request?: Record<string, string>;
      response?: Record<string, string>;
    };
  };
}

export interface AddonConfig {
  /** FebBox "ui" cookie value for direct download links */
  uiToken?: string;
  /** Optional FebBox OSS group */
  ossGroup?: string;
}
