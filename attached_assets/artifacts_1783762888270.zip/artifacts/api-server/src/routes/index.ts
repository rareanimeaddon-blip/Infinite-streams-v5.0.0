import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import addonInfoRouter from "./addonInfo.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(addonInfoRouter);

export default router;
