import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

router.get("/addon/info", (req: Request, res: Response) => {
  const proto = (req.headers["x-forwarded-proto"] as string) ?? "https";
  const host = (req.headers["x-forwarded-host"] as string) ?? req.hostname;
  const origin = `${proto}://${host}`;

  res.json({
    name: "StreamFlow",
    version: "2.0.0",
    description:
      "Multi-engine Stremio add-on powered by Movies4u web scraper, Castle streaming API, and CineFreak direct links. Supports 1080P+ streams for movies and TV series.",
    manifestUrl: `${origin}/api/addon/manifest.json`,
    sources: [
      {
        name: "Movies4u",
        description:
          "Web scraper resolving HubCloud and M4U Player links. Supports 4K, 1080p, 720p streams.",
        quality: "4K / 1080p / 720p",
        active: true,
      },
      {
        name: "Castle",
        description:
          "AES-128-CBC encrypted streaming API (api.hlowb.com). Searches by TMDB title, returns per-language dubbed/subbed streams with automatic fallback to shared stream.",
        quality: "720p / 1080p",
        active: true,
      },
      {
        name: "CineFreak",
        description:
          "WordPress scraper (cinefreak.nl) resolving FSL CDN links via cinecloud.site. Returns direct MKV/MP4 downloads up to 4K with Dual-Audio support.",
        quality: "4K / 1080p / 720p",
        active: true,
      },
    ],
  });
});

export default router;
