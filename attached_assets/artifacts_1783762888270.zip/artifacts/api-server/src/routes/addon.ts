/**
 * Stremio Add-on Routes
 *
 * Implements the Stremio Add-on Protocol:
 *   GET /addon/manifest.json
 *   GET /addon/:config/manifest.json
 *   GET /addon/stream/:type/:id.json
 *   GET /addon/:config/stream/:type/:id.json
 *   GET /addon/configure  → redirect to web UI
 *
 * Config is a base64url-encoded JSON object with optional fields:
 *   { uiToken?: string; ossGroup?: string }
 */

import { Router, type IRouter, type Request, type Response } from "express";
import cors from "cors";
import { getAllStreams, type AddonConfig } from "../scrapers/index.js";
import type { StremioStream } from "../scrapers/types.js";

const router: IRouter = Router();

// Stremio requires CORS: *
router.use(cors({ origin: "*", methods: ["GET", "HEAD", "OPTIONS"] }));

// ─── Manifest ────────────────────────────────────────────────────────────────

const MANIFEST = {
  id: "community.streamflow.replit",
  version: "2.0.0",
  name: "StreamFlow",
  description:
    "Multi-engine Stremio add-on — Movies4u web scraper + Castle streaming API + CineFreak direct links. Supports movies & TV series with 1080P+ streams.",
  logo: "https://i.imgur.com/7EoUkpH.png",
  background: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1280",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: [],
  behaviorHints: {
    configurable: false,
    configurationRequired: false,
    adult: false,
  },
  config: [],
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function parseConfig(raw?: string): AddonConfig {
  if (!raw) return {};
  try {
    return JSON.parse(Buffer.from(raw, "base64url").toString("utf8")) as AddonConfig;
  } catch {
    return {};
  }
}

function sendManifest(res: Response): void {
  res.setHeader("Content-Type", "application/json");
  res.json(MANIFEST);
}

/**
 * Wrap a stream URL through the local proxy when the CDN requires custom
 * request headers (Origin / Referer). The proxy itself sniffs the response
 * body to decide whether it's an HLS playlist (needs URL rewriting) or a
 * binary segment (streamed through untouched).
 */
function proxyStreamUrl(
  streamUrl: string,
  headers: Record<string, string>,
  proxyBase: string,
): string {
  const params = new URLSearchParams({
    url: Buffer.from(streamUrl).toString("base64url"),
    h:   Buffer.from(JSON.stringify(headers)).toString("base64url"),
  });
  return `${proxyBase}?${params.toString()}`;
}

function applyProxy(
  streams: StremioStream[],
  proxyBase: string,
): StremioStream[] {
  return streams.map((s) => {
    const reqHeaders = s.behaviorHints?.proxyHeaders?.request;
    if (!reqHeaders || Object.keys(reqHeaders).length === 0) return s;

    return {
      ...s,
      url: proxyStreamUrl(s.url, reqHeaders as Record<string, string>, proxyBase),
      behaviorHints: {
        ...s.behaviorHints,
        proxyHeaders: undefined,   // remove — proxy handles it
      },
    };
  });
}

// ─── Manifest Endpoints ───────────────────────────────────────────────────────

router.get("/manifest.json", (_req, res) => sendManifest(res));
router.get("/:config/manifest.json", (_req, res) => sendManifest(res));

// ─── Stream Handler ───────────────────────────────────────────────────────────

async function handleStream(req: Request, res: Response): Promise<void> {
  const { type, id } = req.params;
  const config = parseConfig(
    (req.params as Record<string, string | undefined>)["config"],
  );

  if (type !== "movie" && type !== "series") {
    res.json({ streams: [] });
    return;
  }

  // Parse Stremio id: "tt1234567" or "tt1234567:1:2"
  const parts = (Array.isArray(id) ? id[0] : (id ?? "")).split(":");
  const imdbId = parts[0];
  const season = parts[1] ? parseInt(parts[1]) : undefined;
  const episode = parts[2] ? parseInt(parts[2]) : undefined;

  if (!imdbId?.startsWith("tt")) {
    res.json({ streams: [] });
    return;
  }

  // Derive the public proxy base URL so Stremio can reach it
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? req.protocol;
  const host =
    (req.headers["x-forwarded-host"] as string | undefined) ?? req.get("host") ?? "localhost";
  const proxyBase = `${proto}://${host}/api/addon/proxy`;

  try {
    const rawStreams = await getAllStreams(
      imdbId,
      type as "movie" | "series",
      season,
      episode,
      config,
    );
    // Wrap any stream that carries proxyHeaders through our own proxy endpoint,
    // so Stremio receives plain URLs it can play without custom headers.
    const streams = applyProxy(rawStreams, proxyBase);
    res.setHeader("Cache-Control", "max-age=3600, s-maxage=3600");
    res.json({ streams });
  } catch (err) {
    req.log.error({ err }, "stream handler failed");
    res.json({ streams: [] });
  }
}

router.get("/stream/:type/:id.json", handleStream);
router.get("/:config/stream/:type/:id.json", handleStream);

// ─── Configure Redirect ───────────────────────────────────────────────────────

router.get("/configure", (_req, res) => {
  res.redirect("/");
});

export default router;
