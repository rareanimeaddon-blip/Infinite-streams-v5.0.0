/**
 * Stream Proxy
 * Fetches remote stream URLs (HLS playlists, segments, direct files) with
 * the correct Origin/Referer headers and pipes the response to the client.
 *
 * GET /addon/proxy
 *   ?url=<base64url-encoded target URL>
 *   &h=<base64url-encoded JSON headers object>   (optional)
 *
 * For HLS: rewrites all segment / child playlist URLs in the m3u8 to also
 * go through this proxy, so Stremio can fetch every chunk.
 *
 * HLS-vs-binary detection is done by sniffing the first bytes of the actual
 * response body (does it start with "#EXTM3U"?) rather than trusting the
 * upstream Content-Type header or the request URL. Some CDNs (e.g. the
 * LordFlix segment host) serve binary video segments with a misleading
 * `text/html` Content-Type, and segment/playlist URLs can share the exact
 * same host and query-string shape -- so header/URL heuristics misclassify
 * binary segments as playlists, corrupting playback. Body sniffing is the
 * only reliable signal.
 *
 * Security: only HTTPS URLs targeting public internet hosts are allowed;
 * private/loopback address ranges are blocked (SSRF mitigation).
 */

import { Router, type IRouter, type Request, type Response } from "express";
import cors from "cors";
import { promises as dns } from "node:dns";

const router: IRouter = Router();
router.use(cors({ origin: "*" }));

// ─── DNS cache ───────────────────────────────────────────────────────────────
// Each call to validateAndResolveUrl does dns.lookup(), which is called once
// per redirect hop (busycdn, googleusercontent, etc.).  Caching the results
// for 30 s removes repeated syscall/OS-cache round-trips and shaves ~50–150 ms
// off every redirected stream fetch.

const DNS_CACHE_TTL = 30_000; // ms
const dnsCache = new Map<string, { address: string; expiresAt: number }>();

async function cachedDnsLookup(hostname: string): Promise<string | null> {
  const cached = dnsCache.get(hostname);
  if (cached && Date.now() < cached.expiresAt) return cached.address;
  try {
    const { address } = await dns.lookup(hostname, { verbatim: true });
    // Evict oldest entry if we're at the size cap (prevents unbounded growth
    // with attacker-controlled hostnames coming through /addon/proxy).
    if (dnsCache.size >= 256) {
      dnsCache.delete(dnsCache.keys().next().value!);
    }
    dnsCache.set(hostname, { address, expiresAt: Date.now() + DNS_CACHE_TTL });
    return address;
  } catch {
    return null; // DNS failure — caller treats null as rejected
  }
}

// ─── Direct-redirect passthrough ─────────────────────────────────────────────
//
// For direct-file CDN chains (busycdn → fastcdn-dl interstitial → Google Video)
// we can resolve the entire chain upfront via a single HEAD request, then issue
// a 302 to the client so Stremio connects DIRECTLY to the final CDN rather than
// streaming through this proxy server. This drops play-start TTFB from ~5 s to
// ~400 ms because the proxy no longer buffers the entire video.
//
// Safety: only redirect to explicitly allow-listed hostnames to prevent open
// redirects to arbitrary attacker-supplied targets.

const SAFE_REDIRECT_HOSTS = new Set([
  "video-downloads.googleusercontent.com",
  "pixeldrain.com",
  "pixeldrain.dev",
  "r2.dev",           // Cloudflare R2 public buckets
]);

/**
 * Walk the redirect chain for `startUrl` using HEAD requests (no body
 * download) and interstitial unwrapping, and return the final URL.
 * Returns null if any hop is blocked by the SSRF guard or on timeout.
 */
async function resolveRedirectChain(startUrl: string): Promise<string | null> {
  let current = startUrl;
  for (let hop = 0; hop <= 6; hop++) {
    // Interstitials (fastcdn-dl, gamerxyt) embed the real URL in a query
    // param — extract it without making a network request.
    const unwrapped = unwrapInterstitial(current);
    if (unwrapped) {
      current = unwrapped;
      // If the unwrapped URL is on our allow list we trust it immediately
      // without a further HEAD probe — interstitials embed the real CDN URL
      // directly, so probing it is redundant and costs ~500 ms.
      try {
        const { hostname } = new URL(current);
        if (SAFE_REDIRECT_HOSTS.has(hostname)) {
          const validated = await validateAndResolveUrl(current);
          return validated ? current : null;
        }
      } catch { /* invalid URL — fall through to HEAD below */ }
      continue;
    }

    const validated = await validateAndResolveUrl(current);
    if (!validated) return null;

    const res = await fetch(current, {
      method: "HEAD",
      headers: { "User-Agent": PROXY_UA },
      redirect: "manual",
      signal: AbortSignal.timeout(5_000),
    });

    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get("location");
      if (!location) return current;
      current = new URL(location, current).toString();
      continue;
    }

    return res.ok ? current : null;
  }
  return null;
}

// ─── Security ────────────────────────────────────────────────────────────────

/**
 * Check whether a resolved IP address falls within a private, loopback,
 * link-local, or otherwise reserved range. Handles both IPv4 and IPv6,
 * including IPv4-mapped IPv6 addresses (::ffff:192.168.x.x).
 *
 * This is the authoritative check -- applied AFTER DNS resolution so that
 * attacker-controlled public domains that resolve to internal IPs are caught.
 */
function isPrivateIp(ip: string): boolean {
  // Strip IPv6 zone ID (e.g. "fe80::1%eth0")
  const addr = ip.replace(/%.*$/, "").toLowerCase();

  // Unwrap IPv4-mapped IPv6 (::ffff:192.168.1.1  or  ::ffff:c0a8:101)
  const v4mapped = addr.match(/^::(?:ffff:)?(\d+\.\d+\.\d+\.\d+)$/);
  const target = v4mapped ? v4mapped[1]! : addr;

  // ── IPv4 checks ──────────────────────────────────────────────────────────
  if (/^\d+\.\d+\.\d+\.\d+$/.test(target)) {
    const [a, b, c] = target.split(".").map(Number) as [number, number, number, number];
    if (a === 0) return true;                                   // 0.x.x.x
    if (a === 10) return true;                                  // 10/8
    if (a === 127) return true;                                 // loopback
    if (a === 169 && b === 254) return true;                    // link-local / metadata
    if (a === 172 && b >= 16 && b <= 31) return true;          // 172.16/12
    if (a === 192 && b === 168) return true;                    // 192.168/16
    if (a === 192 && b === 0 && c === 0) return true;          // IANA special
    if (a === 198 && (b === 18 || b === 19)) return true;      // benchmarking
    if (a === 198 && b === 51 && c === 100) return true;       // TEST-NET-2
    if (a === 203 && b === 0 && c === 113) return true;        // TEST-NET-3
    if (a >= 224) return true;                                  // multicast + reserved
    return false;
  }

  // ── IPv6 checks ──────────────────────────────────────────────────────────
  if (target === "::1") return true;                            // loopback
  if (target === "::") return true;                             // unspecified
  if (target.startsWith("fc") || target.startsWith("fd")) return true; // ULA (fc00::/7)
  if (target.startsWith("fe80")) return true;                   // link-local
  if (target.startsWith("ff")) return true;                     // multicast
  if (target.startsWith("64:ff9b")) return true;               // NAT64 well-known prefix
  return false;
}

/**
 * Validate a URL string (scheme, port) and resolve its hostname to an IP,
 * checking that the IP is not private/reserved. This is the SSRF guard:
 * pattern-matching hostnames alone is insufficient because an attacker can
 * point a public domain at an internal IP (DNS rebinding). We resolve first,
 * then decide.
 *
 * Returns the URL object on success, null on any failure.
 */
async function validateAndResolveUrl(raw: string): Promise<URL | null> {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }

  // HTTPS-only — no http:, ftp:, file:, etc.
  if (u.protocol !== "https:") return null;

  const hostname = u.hostname;

  // Reject bare IPs that are obviously private without needing DNS
  // (saves a round-trip for the common loopback/RFC-1918 cases).
  if (isPrivateIp(hostname)) return null;

  // Resolve the hostname to its IP and check that too.
  // This catches public domains that resolve to private IPs.
  // Results are cached for 30 s — DNS lookups otherwise repeat for every hop
  // in fetchWithValidatedRedirects and add visible latency.
  try {
    const address = await cachedDnsLookup(hostname);
    if (address === null || isPrivateIp(address)) return null;
  } catch {
    // DNS failure → reject (fail-closed)
    return null;
  }

  return u;
}

/**
 * HubCloud's and GDFlix's "worker" CDN chains (gpdl2.hubcloud.cx →
 * *.workers.dev → gamerxyt.com/dl.php, and instant.busycdn.xyz →
 * fastcdn-dl.pages.dev) don't end in a redirect to the real file — they end
 * in a client-side "Instant DL Page" / "Generating Download Link" HTML page
 * that uses JS to read a `url=`/`link=` query param and navigate there. A
 * video player has no JS engine, so it just renders that HTML as if it were
 * the stream (the "playback error" the Stremio/3rd-party player shows).
 *
 * The real destination is already sitting in that page's own query string —
 * no JS execution needed — so we short-circuit straight to it instead of
 * ever fetching the interstitial page.
 */
const INTERSTITIAL_HOSTS = new Set(["fastcdn-dl.pages.dev", "gamerxyt.com"]);

function unwrapInterstitial(url: string): string | null {
  try {
    const u = new URL(url);
    if (!INTERSTITIAL_HOSTS.has(u.hostname)) return null;
    const inner = u.searchParams.get("url") ?? u.searchParams.get("link");
    if (inner && /^https?:\/\//i.test(inner)) return inner;
  } catch {
    // fall through
  }
  return null;
}

/**
 * Fetch `url`, following redirects manually and re-validating (scheme +
 * DNS-resolved IP check) at every hop. Using `redirect: "follow"` would let a
 * validated public URL silently redirect to a private/internal target — a
 * classic SSRF bypass. We handle each hop ourselves, capped at maxHops.
 *
 * Also unwraps known JS-only "Instant DL Page" interstitials (see above)
 * straight to their embedded target instead of fetching the interstitial.
 */
async function fetchWithValidatedRedirects(
  url: string,
  init: RequestInit,
  maxHops = 5,
): Promise<globalThis.Response> {
  let current = url;
  for (let hop = 0; hop <= maxHops; hop++) {
    const unwrapped = unwrapInterstitial(current);
    if (unwrapped) {
      current = unwrapped;
      continue;
    }

    // Validate + DNS-resolve before every fetch (including after redirects)
    const validated = await validateAndResolveUrl(current);
    if (!validated) throw new Error(`URL not allowed: ${current}`);

    const res = await fetch(current, { ...init, redirect: "manual" });
    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get("location");
      if (!location) return res; // redirect with no Location — return as-is
      current = new URL(location, current).toString();
      continue;
    }
    return res;
  }
  throw new Error("Too many redirects");
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function encodeBase64url(s: string): string {
  return Buffer.from(s).toString("base64url");
}

function buildProxyUrl(
  base: string,
  targetUrl: string,
  headers: Record<string, string>,
): string {
  const params = new URLSearchParams({
    url: encodeBase64url(targetUrl),
    h:   encodeBase64url(JSON.stringify(headers)),
  });
  return `${base}?${params.toString()}`;
}

/**
 * Resolve a (possibly relative) HLS segment URL against the playlist's base URL.
 * Handles absolute URLs, protocol-relative (//…), and relative paths.
 */
function resolveSegmentUrl(segment: string, playlistUrl: string): string {
  if (segment.startsWith("http://") || segment.startsWith("https://")) {
    return segment;
  }
  if (segment.startsWith("//")) {
    return `https:${segment}`;
  }
  try {
    return new URL(segment, playlistUrl).toString();
  } catch {
    return segment;
  }
}

/**
 * Rewrite an m3u8 file so every URL line and URI= value goes through the proxy.
 * All relative URLs are resolved against `playlistUrl` first.
 */
function rewriteM3u8(
  playlist: string,
  playlistUrl: string,
  headers: Record<string, string>,
  proxyBase: string,
): string {
  const lines = playlist.split("\n");
  return lines
    .map((line) => {
      const trimmed = line.trim();

      // Rewrite URI="..." inside tags (EXT-X-KEY, EXT-X-MAP, EXT-X-MEDIA, EXT-X-I-FRAME-STREAM-INF)
      if (trimmed.startsWith("#") && trimmed.includes('URI="')) {
        return trimmed.replace(/URI="([^"]+)"/g, (_match, uri) => {
          const abs = resolveSegmentUrl(uri, playlistUrl);
          return `URI="${buildProxyUrl(proxyBase, abs, headers)}"`;
        });
      }

      // Skip comment/tag lines and blank lines
      if (trimmed.startsWith("#") || trimmed === "") return line;

      // Segment or sub-playlist URL line — resolve relative paths first
      const abs = resolveSegmentUrl(trimmed, playlistUrl);
      return buildProxyUrl(proxyBase, abs, headers);
    })
    .join("\n");
}

// ─── Lazy CDN Intermediate-Page Resolvers ────────────────────────────────────
//
// Movies4u streams link to CDN gating pages (hubcloud.cx, vcloud.zip, gdflix.dev)
// rather than directly to video files. These pages embed short-lived tokens that
// expire within seconds. Pre-resolving at search time means the token is stale by
// the time Stremio plays it → "Upstream error: 500".
//
// Fix: detect these intermediate pages in the proxy and resolve them LAZILY at
// play time, so every token is freshly generated for each play request.

const PROXY_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

type IntermediateKind = "hubcloud" | "vcloud" | "gdflix";

function detectIntermediatePage(url: string): IntermediateKind | null {
  try {
    const { hostname } = new URL(url);
    if (hostname === "hubcloud.cx" || hostname === "hubcloud.bond" || hostname === "hubcloud.lat")
      return "hubcloud";
    if (hostname === "vcloud.zip") return "vcloud";
    // gdflix operates under several domains and aliases:
    //   gdflix.dev / gdflix.lol  — original domains (now redirect to new2.gdflix.app)
    //   new2.gdflix.app          — current primary domain (as of mid-2026)
    //   new1.gdflix.io           — previous primary domain
    //   gdlink.dev               — alias/shortlink that redirects into gdflix
    if (
      hostname === "gdflix.dev" ||
      hostname === "gdflix.lol" ||
      hostname === "new1.gdflix.io" ||
      hostname === "new2.gdflix.app" ||
      hostname === "gdlink.dev"
    ) return "gdflix";
  } catch { /* invalid URL */ }
  return null;
}

/**
 * Probe a candidate CDN URL with a tiny ranged GET (through the same
 * redirect-validating + interstitial-unwrapping fetch used for real
 * playback) to confirm it's actually a live, playable file before we commit
 * to it. Mirror hosts (pixeldrain, R2 buckets, workers.dev CDN chains, etc.)
 * frequently go dead/expire independently of each other on the same page —
 * picking the first regex match without checking led to serving a dead
 * mirror's URL to Stremio while a working sibling mirror sat unused lower in
 * the page.
 */
async function isLikelyPlayableUrl(candidate: string): Promise<boolean> {
  try {
    const res = await fetchWithValidatedRedirects(candidate, {
      headers: { "User-Agent": PROXY_UA, Range: "bytes=0-256" },
      // Short per-probe timeout — this runs serially at PLAY TIME, so a slow
      // dead mirror must not stall startup; a live mirror answers in well
      // under a second in practice.
      signal: AbortSignal.timeout(4_000),
    });
    if (!res.ok && res.status !== 206) return false;
    const ct = (res.headers.get("content-type") ?? "").toLowerCase();
    if (ct.includes("text/html") || ct.includes("application/json")) return false;
    return true;
  } catch {
    return false;
  }
}

/**
 * Return the first candidate that passes {@link isLikelyPlayableUrl}, checked
 * in order and capped at MAX_PROBES to bound play-start latency when many
 * mirrors are dead in a row (each probe has its own short timeout above, but
 * we still cap total attempts so a page with 10 dead mirrors doesn't chain
 * 10 timeouts before giving up).
 */
async function pickFirstWorking(candidates: string[]): Promise<string | null> {
  const MAX_PROBES = 4;
  for (const c of candidates.slice(0, MAX_PROBES)) {
    if (await isLikelyPlayableUrl(c)) return c;
  }
  return null;
}

/**
 * Resolve a hubcloud.cx page to a streamable CDN URL (fresh token at call time).
 *
 * Chain: hubcloud.cx/drive/<id>
 *        → gamerxyt.com/hubcloud.php?token=<fresh>  (download landing page)
 *        → one of several sibling mirrors: hub.whistle.lat, pixeldrain,
 *          gpdl.hubcloud.cx (→ workers.dev → gamerxyt.com/dl.php, unwrapped
 *          straight to the googleusercontent CDN URL), or any other button.
 *
 * These mirrors are independent and go dead independently — we collect all
 * of them and probe in priority order, falling through to the next mirror
 * instead of committing to whichever regex happened to match first.
 */
async function resolveHubcloudPage(
  hubUrl: string,
  passedReferer: string,
): Promise<string | null> {
  try {
    // Step 1 — fetch the hubcloud landing page (redirects manually validated
    // hop-by-hop to keep the SSRF guard intact even through this chain)
    const hubRes = await fetchWithValidatedRedirects(hubUrl, {
      headers: {
        "User-Agent": PROXY_UA,
        Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        Referer: passedReferer,
      },
      signal: AbortSignal.timeout(12_000),
    });
    if (!hubRes.ok) return null;
    const hubHtml = await hubRes.text();

    // Extract the gamerxyt download link embedded in the page.
    // Only accept gamerxyt.com URLs — reject any attempt to redirect to other hosts.
    const gamerxytMatch = hubHtml.match(
      /href="(https:\/\/gamerxyt\.com\/hubcloud\.php[^"]{0,500})"/i,
    );
    if (!gamerxytMatch?.[1]) {
      // Fallback: direct mp4/mkv on hubcloud page
      const direct = hubHtml.match(
        /href="(https?:\/\/[^"]+\.(?:mp4|mkv)(?:\?[^"]{0,300})?)"/i,
      );
      return direct?.[1] ?? null;
    }

    // SSRF guard: validate the gamerxyt URL before fetching it
    const gxValidated = await validateAndResolveUrl(gamerxytMatch[1]);
    if (!gxValidated) return null;

    // Step 2 — fetch gamerxyt landing page (generates fresh CDN token)
    const gxRes = await fetchWithValidatedRedirects(gamerxytMatch[1], {
      headers: {
        "User-Agent": PROXY_UA,
        Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        Referer: "https://hubcloud.cx/",
      },
      signal: AbortSignal.timeout(12_000),
    });
    if (!gxRes.ok) return null;
    const gxHtml = await gxRes.text();

    // Collect every candidate mirror on the page, in priority order. Each
    // pattern can match more than once (a page can list several whistle/
    // pixeldrain/button mirrors) so we harvest ALL matches per pattern, not
    // just the first — a dead first mirror must not shadow a live sibling of
    // the same kind further down the page.
    const candidates: string[] = [];
    const seen = new Set<string>();
    const addCandidate = (url: string | undefined | null): void => {
      if (url && !seen.has(url)) { seen.add(url); candidates.push(url); }
    };

    for (const m of gxHtml.matchAll(/href="(https:\/\/[^"]*whistle\.[^"]{10,500})"/gi)) {
      addCandidate(m[1]);
    }

    // pixeldrain has two link shapes on this page: `/u/<id>` (an HTML landing
    // page, NOT playable — streaming it as "video" serves an HTML doc that
    // fails to play) and `/api/file/<id>` (the actual binary file, correct
    // Content-Type/Content-Length). Prefer the direct file link; if only the
    // landing-page form is present, convert it rather than following it.
    for (const m of gxHtml.matchAll(
      /href="(https:\/\/pixeldrain\.[a-z]+\/api\/file\/[a-zA-Z0-9]+)[^"]*"/gi,
    )) {
      addCandidate(m[1]);
    }
    for (const m of gxHtml.matchAll(
      /href="(https:\/\/(pixeldrain\.[a-z]+)\/u\/([a-zA-Z0-9]+))"/gi,
    )) {
      if (m[2] && m[3]) addCandidate(`https://${m[2]}/api/file/${m[3]}`);
    }

    // gpdl.hubcloud.cx → *.workers.dev → gamerxyt.com/dl.php?link=<CDN url>
    // fetchWithValidatedRedirects follows this whole chain and unwraps the
    // final dl.php interstitial straight to the embedded CDN URL.
    for (const m of gxHtml.matchAll(/href="(https:\/\/gpdl\.hubcloud\.[a-z]+\/[^"]{5,500})"/gi)) {
      addCandidate(m[1]);
    }

    // Any other download button on the gamerxyt page — exclude known non-CDN hosts
    for (const m of gxHtml.matchAll(
      /href="(https:\/\/(?!gamerxyt\.|hubcloud\.|google\.|cloudflare\.|t\.me)[^"]{20,500})"[^>]*class="btn/gi,
    )) {
      addCandidate(m[1]);
    }

    if (candidates.length === 0) return null;
    return (await pickFirstWorking(candidates)) ?? candidates[0]!;
  } catch {
    return null;
  }
}

/**
 * Resolve a vcloud.zip page to a direct CDN URL.
 * vcloud often uses a two-hop chain: first page encodes another vcloud URL via
 * atob(atob(…)); following that URL yields the `var url = '…'` CDN address.
 * Also handles a self-referential "please wait" interstitial with one retry.
 */
async function resolveVcloudPage(startUrl: string): Promise<string | null> {
  /** True only when the URL is a vcloud.zip hop (we follow it); false = final CDN URL (return it). */
  function isVcloudHost(url: string): boolean {
    try { return new URL(url).hostname === "vcloud.zip"; } catch { return false; }
  }

  try {
    let current = startUrl;
    for (let hop = 0; hop < 5; hop++) {
      const res = await fetch(current, {
        headers: {
          "User-Agent": PROXY_UA,
          Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
          Referer: "https://vcloud.zip/",
        },
        redirect: "manual",  // validate any redirect before following
        signal: AbortSignal.timeout(12_000),
      });

      // Handle manual redirects with SSRF validation
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get("location");
        if (!location) return null;
        const abs = new URL(location, current).toString();
        if (!(await validateAndResolveUrl(abs))) return null;
        current = abs;
        continue;
      }
      if (!res.ok) return null;
      const html = await res.text();

      // Format 1 — plain JS string: var url = 'https://...'
      const plain = html.match(/var\s+url\s*=\s*['"`](https?:\/\/[^'"`\s]{10,})['"`]/);
      if (plain?.[1]) {
        const next = plain[1];
        if (next === current) {
          // Self-referential interstitial — wait and retry once
          await new Promise((r) => setTimeout(r, 2_000));
          const r2 = await fetch(current, {
            headers: { "User-Agent": PROXY_UA, Referer: "https://vcloud.zip/" },
            redirect: "manual",
            signal: AbortSignal.timeout(12_000),
          });
          if (!r2.ok) return null;
          const html2 = await r2.text();
          const plain2 = html2.match(/var\s+url\s*=\s*['"`](https?:\/\/[^'"`\s]{10,})['"`]/);
          if (!plain2?.[1] || plain2[1] === current) return null;
          if (!isVcloudHost(plain2[1])) return plain2[1]; // final CDN URL
          // Next vcloud hop — validate before following
          if (!(await validateAndResolveUrl(plain2[1]))) return null;
          current = plain2[1];
          continue;
        }
        if (!isVcloudHost(next)) return next; // final CDN URL
        // Next vcloud hop — SSRF check before following
        if (!(await validateAndResolveUrl(next))) return null;
        current = next;
        continue;
      }

      // Format 2 — double base64: atob(atob('…'))
      const b64 = html.match(/atob\(atob\(['"`]([^'"`]{10,})['"`]\)\)/);
      if (b64?.[1]) {
        try {
          const step1 = Buffer.from(b64[1], "base64").toString("utf8");
          const step2 = Buffer.from(step1, "base64").toString("utf8");
          if (step2.startsWith("https://")) {
            if (!isVcloudHost(step2)) return step2; // final CDN URL
            // Next vcloud hop — SSRF check
            if (!(await validateAndResolveUrl(step2))) return null;
            current = step2;
            continue;
          }
        } catch { /* malformed base64 */ }
      }

      return null; // unrecognised page format
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Resolve a gdflix.dev page to a direct CDN URL. The page can expose several
 * independent mirrors (instant.busycdn.xyz, drivebot, ...) that go dead on
 * their own schedule, so we collect all of them and probe in priority order
 * instead of committing to whichever regex matched first.
 */
/** Decode HTML entities that appear inside href attributes on gdflix pages. */
function decodeHtmlEntities(s: string): string {
  return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"');
}

async function resolveGdflixPage(gdflixUrl: string): Promise<string | null> {
  try {
    const res = await fetchWithValidatedRedirects(gdflixUrl, {
      headers: {
        "User-Agent": PROXY_UA,
        Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        Referer: "https://m4ulinks.site/",
      },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return null;
    const html = await res.text();

    // Harvest ALL matches per pattern (not just the first) — a page can list
    // more than one busycdn/drivebot mirror, and a dead first one must not
    // shadow a live sibling further down.
    //
    // NOTE: href values on gdflix pages may contain &amp; HTML entities — always
    // decode before using the URL. The [^"] regex captures the raw HTML text
    // (including entities) which we decode below.
    const candidates: string[] = [];
    const seen = new Set<string>();
    const addCandidate = (raw: string | undefined | null): void => {
      if (!raw) return;
      const url = decodeHtmlEntities(raw.trim());
      if (url && !seen.has(url)) { seen.add(url); candidates.push(url); }
    };

    // Priority 1: instant.busycdn.xyz — content-addressed CDN, stable URL.
    // Redirects via fastcdn-dl.pages.dev interstitial which fetchWithValidatedRedirects
    // unwraps automatically (fastcdn-dl is in INTERSTITIAL_HOSTS).
    for (const m of html.matchAll(/href="(https?:\/\/instant\.busycdn\.xyz\/[^"]{20,})"/gi)) {
      addCandidate(m[1]);
    }

    // Priority 2: drivebot — direct 50 MB/s download link.
    // These URLs frequently contain &amp; entities in the query string.
    for (const m of html.matchAll(/href="(https?:\/\/drivebot\.[^"]{10,})"/gi)) {
      addCandidate(m[1]);
    }

    if (candidates.length === 0) return null;

    // Return the first candidate directly without probing — the probe uses a
    // short 4-second timeout which the busycdn→fastcdn-dl→Google Video chain
    // reliably exceeds, causing pickFirstWorking to return null even when the
    // stream is perfectly valid. Trust the extracted URL; bad URLs will fail at
    // actual play time rather than silently killing valid streams at pick time.
    return candidates[0]!;
  } catch {
    return null;
  }
}

// ─── Route ───────────────────────────────────────────────────────────────────

router.get("/", async (req: Request, res: Response): Promise<void> => {
  const { url: rawUrl, h: rawHeaders } = req.query as Record<string, string | undefined>;

  if (!rawUrl) {
    res.status(400).json({ error: "Missing url parameter" });
    return;
  }

  let targetUrl: string;
  let headers: Record<string, string> = {};

  try {
    targetUrl = Buffer.from(rawUrl, "base64url").toString("utf8");
  } catch {
    res.status(400).json({ error: "Invalid url encoding" });
    return;
  }

  // SSRF guard — resolves DNS and checks the resulting IP, not just the hostname string
  const parsedTarget = await validateAndResolveUrl(targetUrl);
  if (!parsedTarget) {
    res.status(403).json({ error: "Target URL not allowed" });
    return;
  }

  if (rawHeaders) {
    try {
      headers = JSON.parse(Buffer.from(rawHeaders, "base64url").toString("utf8")) as Record<string, string>;
    } catch {
      headers = {};
    }
  }

  // ── Lazy CDN resolution ───────────────────────────────────────────────────
  // If the URL is a CDN gating page (hubcloud, vcloud, gdflix), resolve it to
  // a streamable CDN URL right now — at PLAY TIME — so the token is fresh.
  const intermediateKind = detectIntermediatePage(targetUrl);
  if (intermediateKind !== null) {
    const passedReferer = (headers["Referer"] ?? headers["referer"]) || "https://m4ulinks.site/";
    let resolvedCdn: string | null = null;

    if (intermediateKind === "hubcloud") {
      resolvedCdn = await resolveHubcloudPage(targetUrl, passedReferer);
    } else if (intermediateKind === "vcloud") {
      resolvedCdn = await resolveVcloudPage(targetUrl);
    } else if (intermediateKind === "gdflix") {
      resolvedCdn = await resolveGdflixPage(targetUrl);
    }

    if (!resolvedCdn) {
      res.status(502).json({ error: `Could not resolve ${intermediateKind} page` });
      return;
    }

    const validCdn = await validateAndResolveUrl(resolvedCdn);
    if (!validCdn) {
      res.status(403).json({ error: "Resolved CDN URL not allowed" });
      return;
    }

    // Use the resolved CDN URL for streaming; CDN direct downloads don't need
    // custom referers — just a standard User-Agent is sufficient.
    targetUrl = resolvedCdn;
    headers = { "User-Agent": PROXY_UA };
  }
  // ── End lazy resolution ───────────────────────────────────────────────────

  // ── Direct-redirect passthrough ───────────────────────────────────────────
  // For direct-file CDN chains (e.g. busycdn → fastcdn-dl → Google Video) try
  // to walk the full redirect chain via HEAD and 302 the client straight to the
  // final URL.  Stremio follows the redirect and streams directly — this proxy
  // is no longer in the data path, cutting play-start latency from ~5 s to
  // ~400 ms for the user.
  //
  // Restricted to explicitly allow-listed hostnames to prevent open-redirect
  // abuse.  Falls through to full proxy for HLS (needs segment URL rewriting)
  // or if the chain ends on an unknown host.
  try {
    const finalUrl = await resolveRedirectChain(targetUrl);
    if (finalUrl) {
      const finalHost = new URL(finalUrl).hostname;
      if (SAFE_REDIRECT_HOSTS.has(finalHost)) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Cache-Control", "public, max-age=300");
        res.redirect(302, finalUrl);
        return;
      }
    }
  } catch { /* chain resolution failed — fall through to full proxy */ }
  // ── End direct-redirect passthrough ──────────────────────────────────────

  // Build the proxy base URL so rewritten segment URLs point back here
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? req.protocol;
  const host =
    (req.headers["x-forwarded-host"] as string | undefined) ?? req.get("host") ?? "localhost";
  const proxyBase = `${proto}://${host}/api/addon/proxy`;

  // Forward Range header from client for seek/resume support
  const upstreamHeaders: Record<string, string> = { ...headers };
  const rangeHeader = req.headers["range"];
  if (rangeHeader) upstreamHeaders["Range"] = rangeHeader;
  const ifRangeHeader = req.headers["if-range"];
  if (ifRangeHeader) upstreamHeaders["If-Range"] = String(ifRangeHeader);

  try {
    const upstream = await fetchWithValidatedRedirects(targetUrl, {
      headers: upstreamHeaders,
      signal: AbortSignal.timeout(20000),
    });

    if (!upstream.ok && upstream.status !== 206) {
      res.status(upstream.status).send(`Upstream error: ${upstream.status}`);
      return;
    }

    if (!upstream.body) { res.end(); return; }

    // Sniff the first chunk to decide HLS-playlist vs binary passthrough.
    // A valid m3u8 always begins with "#EXTM3U" per the HLS spec -- this is
    // the only signal that isn't spoofed/misleading on this CDN.
    const reader = upstream.body.getReader();
    const chunks: Uint8Array[] = [];
    let sniffedLen = 0;
    const SNIFF_TARGET = 16;
    while (sniffedLen < SNIFF_TARGET) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      sniffedLen += value.length;
    }
    const head = Buffer.concat(chunks.map((c) => Buffer.from(c)));
    const isHlsContent = head.subarray(0, 7).toString("utf8") === "#EXTM3U";

    if (isHlsContent) {
      // Drain the rest of the body as text and rewrite every URL in it.
      let rest = "";
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        rest += decoder.decode(value, { stream: true });
      }
      rest += decoder.decode();
      const text = head.toString("utf8") + rest;
      const rewritten = rewriteM3u8(text, targetUrl, headers, proxyBase);
      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Cache-Control", "no-store");
      res.send(rewritten);
      return;
    }

    // Binary stream passthrough with range support
    const statusCode = upstream.status; // 200 or 206
    res.status(statusCode);

    const forwardHeaders = [
      "content-type",
      "content-length",
      "content-range",
      "accept-ranges",
      "last-modified",
    ];
    for (const h of forwardHeaders) {
      const val = upstream.headers.get(h);
      if (val) res.setHeader(h, val);
    }
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=3600");

    // Flush the already-read sniff chunk(s) first, then keep streaming.
    for (const chunk of chunks) res.write(Buffer.from(chunk));
    const pump = async (): Promise<void> => {
      const { done, value } = await reader.read();
      if (done) { res.end(); return; }
      res.write(Buffer.from(value));
      return pump();
    };
    await pump();
  } catch (err) {
    if (!res.headersSent) {
      res.status(502).json({ error: "Proxy fetch failed", detail: String(err) });
    }
  }
});

export { buildProxyUrl };
export default router;
