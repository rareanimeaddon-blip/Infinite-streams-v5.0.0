import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes/index.js";
import addonRouter from "./routes/addon.js";
import proxyRouter from "./routes/proxy.js";
import { logger } from "./lib/logger.js";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Standard API routes
app.use(
  "/api",
  cors({ origin: "*" }),
  router,
);

// Stream proxy — must be mounted BEFORE the addon router so Express matches
// /api/addon/proxy before the wildcard /api/addon prefix swallows the path.
// Fetches CDN content with required headers and pipes it; rewrites HLS playlists.
// Mounted under /api because the shared proxy only routes the /api path
// prefix to this service (paths are not rewritten — see pnpm-workspace skill).
app.use("/api/addon/proxy", proxyRouter);

// Stremio add-on protocol routes — must allow CORS *
app.use("/api/addon", addonRouter);

export default app;
