import { gunzip } from "node:zlib";
import { promisify } from "node:util";
import { Readable } from "node:stream";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  getStreams,
  imdbToTmdb,
  fetchSubtitles,
  clearAllCaches,
  type AddonConfig,
  type StremioStream,
} from "../lib/netmirror.js";

// ─── SSRF guard for subtitle proxy ──────────────────────────────────────────
// Only HTTPS URLs on these known subtitle/caption hosts are allowed through
// subproxy. Anything else (private IPs, internal hostnames, unknown domains)
// is rejected with 403.
const ALLOWED_SUBTITLE_HOSTS = new Set([
  "dl.opensubtitles.org",
  "www.opensubtitles.org",
  "opensubtitles.org",
  "rest.opensubtitles.org",
  "net27.cc",
  "www.net27.cc",
  // env-configured base may use a different hostname — added dynamically below
]);

const PRIVATE_IP_RE = /^(localhost|127\.|0\.|10\.|192\.168\.|169\.254\.|::1$|fc00:|fe80:)/;

function isAllowedSubtitleUrl(rawUrl: string): boolean {
  let parsed: URL;
  try { parsed = new URL(rawUrl); } catch { return false; }

  // HTTPS only
  if (parsed.protocol !== "https:") return false;

  const host = parsed.hostname.toLowerCase();

  // Block private / link-local / metadata addresses
  if (PRIVATE_IP_RE.test(host)) return false;

  // Dynamically trust whatever host is set in NETMIRROR_API_BASE
  const configuredBase = process.env["NETMIRROR_API_BASE"];
  if (configuredBase) {
    try { ALLOWED_SUBTITLE_HOSTS.add(new URL(configuredBase).hostname.toLowerCase()); }
    catch { /* ignore bad env */ }
  }

  return ALLOWED_SUBTITLE_HOSTS.has(host);
}

const gunzipAsync = promisify(gunzip);
const router: IRouter = Router();

const ADDON_ID = "community.netmirror.streams";
const ADDON_VERSION = "1.0.0";
const ADDON_NAME = "NetMirror";
const ADDON_DESCRIPTION =
  "Stream movies & TV shows from Netflix, Prime Video, Hotstar and Disney+ via NetMirror. Content is sourced from third-party APIs.";

function buildManifest(_baseUrl: string, _config?: AddonConfig) {
  return {
    id: ADDON_ID,
    version: ADDON_VERSION,
    name: ADDON_NAME,
    description: ADDON_DESCRIPTION,
    logo: "https://i.imgur.com/MZnSxMB.png",
    resources: [
      "stream",
      // Stremio calls the subtitles endpoint for every piece of content,
      // letting us inject OpenSubtitles tracks even when the source has none.
      {
        name: "subtitles",
        types: ["movie", "series"],
        idPrefixes: ["tt"],
      },
    ],
    types: ["movie", "series"],
    idPrefixes: ["tt"],
    catalogs: [],
    behaviorHints: {
      configurable: true,
      configurationRequired: false,
    },
    config: [
      {
        key: "preferredPlatform",
        type: "select",
        title: "Preferred Platform",
        options: ["all", "netflix", "primevideo", "hotstar"],
        default: "all",
      },
      {
        key: "forceHd",
        type: "checkbox",
        title: "Force HD Quality",
        default: true,
      },
    ],
  };
}

function parseConfig(configStr?: string): AddonConfig {
  if (!configStr) return {};
  try {
    return JSON.parse(Buffer.from(configStr, "base64url").toString("utf-8")) as AddonConfig;
  } catch {
    try {
      return JSON.parse(Buffer.from(configStr, "base64").toString("utf-8")) as AddonConfig;
    } catch {
      return {};
    }
  }
}

function getBaseUrl(req: Request): string {
  const proto = req.headers["x-forwarded-proto"] ?? req.protocol;
  const host = req.headers["x-forwarded-host"] ?? req.get("host");
  return `${proto}://${host}`;
}

function setCorsHeaders(res: Response) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Cache-Control", "max-age=86400, stale-while-revalidate=86400");
}

// ─── Proxy helpers ───────────────────────────────────────────────────────────

function toProxyUrl(
  targetUrl: string,
  streamHeaders: Record<string, string>,
  apiBase: string,
): string {
  const u = Buffer.from(targetUrl).toString("base64url");
  const params = new URLSearchParams({ u });
  const ref = streamHeaders["Referer"] ?? streamHeaders["referer"];
  const ua = streamHeaders["User-Agent"] ?? streamHeaders["user-agent"];
  if (ref) params.set("r", Buffer.from(ref).toString("base64url"));
  if (ua) params.set("a", Buffer.from(ua).toString("base64url"));
  return `${apiBase}/api/stremio/proxy?${params.toString()}`;
}

function toSubProxyUrl(originalUrl: string, apiBase: string): string {
  const u = Buffer.from(originalUrl).toString("base64url");
  return `${apiBase}/api/stremio/subproxy?u=${u}`;
}

function resolveSegmentUrl(raw: string, base: URL): string {
  if (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
  if (raw.startsWith("//")) return base.protocol + raw;
  if (raw.startsWith("/")) return base.origin + raw;
  return new URL(raw, base.href).href;
}

function rewriteM3u8(
  content: string,
  m3u8Url: string,
  apiBase: string,
  referer?: string,
  userAgent?: string,
): string {
  const base = new URL(m3u8Url);
  const hdrs: Record<string, string> = {};
  if (referer) hdrs["Referer"] = referer;
  if (userAgent) hdrs["User-Agent"] = userAgent;

  return content
    .split("\n")
    .map((line) => {
      const trimmed = line.trim();
      if (trimmed.startsWith("#") && trimmed.includes('URI="')) {
        return line.replace(/URI="([^"]+)"/, (_, uri: string) =>
          `URI="${toProxyUrl(resolveSegmentUrl(uri, base), hdrs, apiBase)}"`,
        );
      }
      if (trimmed === "" || trimmed.startsWith("#")) return line;
      return toProxyUrl(resolveSegmentUrl(trimmed, base), hdrs, apiBase);
    })
    .join("\n");
}

// ─── Stream proxy ────────────────────────────────────────────────────────────

router.get("/stremio/proxy", async (req: Request, res: Response) => {
  const query = req.query as Record<string, string>;
  if (!query.u) { res.status(400).json({ error: "Missing url param" }); return; }

  let targetUrl: string, referer: string | undefined, userAgent: string;
  try {
    targetUrl = Buffer.from(query.u, "base64url").toString("utf-8");
    referer = query.r ? Buffer.from(query.r, "base64url").toString("utf-8") : undefined;
    userAgent = query.a
      ? Buffer.from(query.a, "base64url").toString("utf-8")
      : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36";
  } catch {
    res.status(400).json({ error: "Invalid param encoding" }); return;
  }

  const fetchHeaders: Record<string, string> = {
    "User-Agent": userAgent,
    Accept: "*/*",
    "Accept-Encoding": "identity",
  };
  if (referer) fetchHeaders["Referer"] = referer;
  const rangeHeader = req.headers["range"];
  if (rangeHeader) fetchHeaders["Range"] = rangeHeader;

  try {
    const upstream = await fetch(targetUrl, { headers: fetchHeaders, redirect: "follow" });
    const contentType = upstream.headers.get("content-type") ?? "application/octet-stream";
    const finalUrl = upstream.url ?? targetUrl;
    const isM3u8 =
      contentType.toLowerCase().includes("mpegurl") ||
      finalUrl.split("?")[0].endsWith(".m3u8") ||
      finalUrl.split("?")[0].endsWith(".m3u");

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "no-cache");

    if (isM3u8 && upstream.ok) {
      const text = await upstream.text();
      const rewritten = rewriteM3u8(text, finalUrl, getBaseUrl(req), referer, userAgent);
      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.send(rewritten);
      return;
    }

    res.status(upstream.status);
    res.setHeader("Content-Type", contentType);
    for (const h of ["content-length", "content-range", "accept-ranges", "last-modified", "etag"]) {
      const v = upstream.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    if (!upstream.body) { res.end(); return; }

    const readable = Readable.fromWeb(
      upstream.body as import("node:stream/web").ReadableStream<Uint8Array>,
    );
    res.on("close", () => { if (!readable.destroyed) readable.destroy(); });
    readable.pipe(res);
  } catch {
    if (!res.headersSent) res.status(502).json({ error: "Upstream fetch failed" });
  }
});

// ─── Subtitle proxy ──────────────────────────────────────────────────────────
// OpenSubtitles serves .srt.gz files. This endpoint decompresses them so
// Stremio's player gets a plain UTF-8 SRT it can render directly.

router.get("/stremio/subproxy", async (req: Request, res: Response) => {
  const query = req.query as Record<string, string>;
  if (!query.u) { res.status(400).json({ error: "Missing url param" }); return; }

  let targetUrl: string;
  try {
    targetUrl = Buffer.from(query.u, "base64url").toString("utf-8");
  } catch {
    res.status(400).json({ error: "Invalid param encoding" }); return;
  }

  // SSRF guard — only allow known subtitle/caption hosts over HTTPS
  if (!isAllowedSubtitleUrl(targetUrl)) {
    res.status(403).json({ error: "Host not allowed" });
    return;
  }

  try {
    const upstream = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; NetMirror/1.0)",
        Accept: "*/*",
      },
      redirect: "follow",
    });

    if (!upstream.ok) {
      res.status(upstream.status).json({ error: "Upstream subtitle fetch failed" });
      return;
    }

    const contentType = upstream.headers.get("content-type") ?? "";
    const contentEncoding = upstream.headers.get("content-encoding") ?? "";
    const finalUrl = upstream.url ?? targetUrl;
    const isGzip =
      contentType.includes("gzip") ||
      contentType.includes("x-gzip") ||
      contentEncoding === "gzip" ||
      contentEncoding === "x-gzip" ||
      finalUrl.split("?")[0].endsWith(".gz");

    const rawBuffer = Buffer.from(await upstream.arrayBuffer());
    const text = isGzip
      ? (await gunzipAsync(rawBuffer)).toString("utf-8")
      : rawBuffer.toString("utf-8");

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=3600");

    // Serve as VTT if it looks like WebVTT, otherwise SRT
    if (text.trimStart().startsWith("WEBVTT")) {
      res.setHeader("Content-Type", "text/vtt; charset=utf-8");
    } else {
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
    }
    res.send(text);
  } catch {
    if (!res.headersSent) res.status(502).json({ error: "Subtitle proxy error" });
  }
});

// ─── Routes ──────────────────────────────────────────────────────────────────

router.get("/stremio/manifest.json", (req: Request, res: Response) => {
  setCorsHeaders(res);
  res.json(buildManifest(getBaseUrl(req)));
});

router.get("/stremio/:config/manifest.json", (req: Request, res: Response) => {
  setCorsHeaders(res);
  const raw = Array.isArray(req.params.config) ? req.params.config[0] : req.params.config;
  res.json(buildManifest(getBaseUrl(req), parseConfig(raw)));
});

router.get("/stremio/stream/:type/:id", async (req: Request, res: Response) => {
  setCorsHeaders(res);
  await handleStream(req, res, {});
});

router.get("/stremio/:config/stream/:type/:id", async (req: Request, res: Response) => {
  setCorsHeaders(res);
  const raw = Array.isArray(req.params.config) ? req.params.config[0] : req.params.config;
  await handleStream(req, res, parseConfig(raw));
});

// ─── Subtitle resource ───────────────────────────────────────────────────────
// Stremio calls this for every movie/episode. We return OpenSubtitles tracks
// so the user can pick subtitles even when the stream source has none.

router.get("/stremio/subtitles/:type/:id.json", async (req: Request, res: Response) => {
  setCorsHeaders(res);
  await handleSubtitles(req, res);
});

router.get("/stremio/:config/subtitles/:type/:id.json", async (req: Request, res: Response) => {
  setCorsHeaders(res);
  await handleSubtitles(req, res);
});

// ─── Handlers ────────────────────────────────────────────────────────────────

async function handleStream(req: Request, res: Response, config: AddonConfig): Promise<void> {
  const { type, id } = req.params as { type: string; id: string };
  const cleanId = id.endsWith(".json") ? id.slice(0, -5) : id;

  if (type !== "movie" && type !== "series") { res.json({ streams: [] }); return; }

  let imdbId: string;
  let season: number | null = null;
  let episode: number | null = null;

  if (type === "series") {
    const parts = cleanId.split(":");
    if (parts.length < 3) { res.json({ streams: [] }); return; }
    imdbId = parts[0];
    const s = parseInt(parts[1], 10);
    const e = parseInt(parts[2], 10);
    if (isNaN(s) || isNaN(e)) { res.json({ streams: [] }); return; }
    season = s;
    episode = e;
  } else {
    imdbId = cleanId;
  }

  const tmdbInfo = await imdbToTmdb(imdbId, type === "series" ? "series" : "movie");
  if (!tmdbInfo) { res.json({ streams: [] }); return; }

  const rawStreams = await getStreams(
    tmdbInfo.tmdbId,
    type === "series" ? "series" : "movie",
    tmdbInfo.title,
    season,
    episode,
    config,
  );

  const apiBase = getBaseUrl(req);
  const streams = rawStreams.map((s: StremioStream) => ({
    name: s.name,
    title: s.title,
    url: toProxyUrl(s.url, s.behaviorHints?.headers ?? {}, apiBase),
    behaviorHints: { notWebReady: false },
    ...(s.subtitles && s.subtitles.length > 0
      ? {
          subtitles: s.subtitles.map((sub) => ({
            id: sub.lang,
            url: isAllowedSubtitleUrl(sub.url)
              ? toSubProxyUrl(sub.url, apiBase)
              : sub.url,
            lang: sub.lang,
          })),
        }
      : {}),
  }));

  res.json({ streams });
}

async function handleSubtitles(req: Request, res: Response): Promise<void> {
  const { type, id } = req.params as { type: string; id: string };
  const cleanId = id.endsWith(".json") ? id.slice(0, -5) : id;

  if (type !== "movie" && type !== "series") { res.json({ subtitles: [] }); return; }

  let imdbId: string;
  let season: number | null = null;
  let episode: number | null = null;

  if (type === "series") {
    const parts = cleanId.split(":");
    if (parts.length < 3) { res.json({ subtitles: [] }); return; }
    imdbId = parts[0];
    const s = parseInt(parts[1], 10);
    const e = parseInt(parts[2], 10);
    if (isNaN(s) || isNaN(e)) { res.json({ subtitles: [] }); return; }
    season = s;
    episode = e;
  } else {
    imdbId = cleanId;
  }

  const apiBase = getBaseUrl(req);
  const rawSubs = await fetchSubtitles(
    imdbId,
    type === "series" ? "series" : "movie",
    season,
    episode,
  );

  // Route every subtitle download through our subproxy (decompresses .gz, adds CORS)
  const subtitles = rawSubs.map((sub) => ({
    id: sub.id,
    url: toSubProxyUrl(sub.url, apiBase),
    lang: sub.lang,
  }));

  res.json({ subtitles });
}

// ─── Admin: cache reload ─────────────────────────────────────────────────────
// Update NETMIRROR_API_BASE / NETMIRROR_STREAM_REFERER / NEWTV_DOMAINS secrets
// then hit this endpoint — no redeploy needed.
// Auth: ?key=<SESSION_SECRET value>

router.get("/stremio/admin/reload", (req: Request, res: Response) => {
  const secret = process.env["SESSION_SECRET"];
  if (!secret || req.query["key"] !== secret) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  clearAllCaches();
  res.json({
    ok: true,
    message: "All caches cleared. Next request will re-resolve source URLs from current env vars.",
    env: {
      NETMIRROR_API_BASE: process.env["NETMIRROR_API_BASE"] ?? "(default: https://net27.cc)",
      NETMIRROR_STREAM_REFERER: process.env["NETMIRROR_STREAM_REFERER"] ?? "(default: https://videodownloader.site/)",
      NEWTV_DOMAINS: process.env["NEWTV_DOMAINS"] ? "(set)" : "(using built-in list)",
    },
  });
});

// OPTIONS preflight handled by cors() middleware in app.ts
export default router;
