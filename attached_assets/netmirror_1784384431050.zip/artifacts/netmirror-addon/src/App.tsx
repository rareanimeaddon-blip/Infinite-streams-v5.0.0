import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { useState, useMemo } from 'react';
import { Check, Copy, Settings2, Play, Flame, Layers } from 'lucide-react';

const queryClient = new QueryClient();

function Home() {
  const [platform, setPlatform] = useState("all");
  const [forceHd, setForceHd] = useState(true);
  const [copied, setCopied] = useState(false);

  const manifestUrl = useMemo(() => {
    let url = "";
    if (platform === "all" && forceHd) {
      url = `${window.location.origin}/api/stremio/manifest.json`;
    } else {
      const config = { preferredPlatform: platform, forceHd };
      const configEncoded = btoa(JSON.stringify(config))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
      url = `${window.location.origin}/api/stremio/${configEncoded}/manifest.json`;
    }
    return url;
  }, [platform, forceHd]);

  const stremioUrl = manifestUrl.replace(/^https?:\/\//, 'stremio://');

  const copyToClipboard = () => {
    navigator.clipboard.writeText(manifestUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen w-full bg-background text-foreground font-sans selection:bg-primary/30 flex flex-col">
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-500/5 blur-[120px]" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay" />
      </div>

      <main className="flex-1 flex flex-col items-center justify-center p-6 relative z-10">
        <div className="w-full max-w-4xl mx-auto space-y-16 py-12">
          
          {/* Header */}
          <div className="text-center space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700 ease-out">
            <div className="inline-flex items-center justify-center p-4 bg-card border border-border rounded-2xl mb-2 shadow-2xl shadow-primary/10">
              <Flame className="w-10 h-10 text-primary drop-shadow-[0_0_15px_rgba(255,102,0,0.5)]" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-foreground">
              NetMirror
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              The ultimate aggregator for Stremio. Find and play content from premium OTT platforms automatically.
            </p>
            
            <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
              {['Netflix', 'Prime Video', 'Hotstar', 'Disney+'].map(plat => (
                <span key={plat} className="px-4 py-1.5 bg-secondary/50 border border-border rounded-full text-sm font-semibold text-secondary-foreground tracking-wide backdrop-blur-sm">
                  {plat}
                </span>
              ))}
            </div>
          </div>

          {/* Configurator */}
          <div className="grid md:grid-cols-5 gap-8 items-stretch animate-in fade-in slide-in-from-bottom-8 duration-1000 ease-out delay-150 fill-mode-both">
            
            {/* Form Side */}
            <div className="md:col-span-2 flex flex-col">
              <div className="bg-card border border-border rounded-3xl p-7 shadow-xl h-full flex flex-col space-y-6">
                <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-muted-foreground mb-2">
                  <Settings2 className="w-4 h-4" /> Configuration
                </div>
                
                <div className="space-y-3">
                  <label className="text-sm font-semibold text-foreground">Preferred Platform</label>
                  <div className="relative group">
                    <select 
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value)}
                      className="w-full appearance-none bg-background/50 border border-border rounded-xl pl-4 pr-10 py-3.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary text-foreground transition-all cursor-pointer hover:bg-background group-hover:border-primary/50"
                    >
                      <option value="all">All Sources (Auto)</option>
                      <option value="netflix">Netflix</option>
                      <option value="primevideo">Prime Video</option>
                      <option value="hotstar">Hotstar / Disney+</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none text-muted-foreground group-hover:text-primary transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7"></path></svg>
                    </div>
                  </div>
                </div>

                <label className="flex items-start gap-4 p-4 bg-background/30 border border-border rounded-xl cursor-pointer hover:border-primary/50 transition-all group hover:bg-background/80 mt-auto">
                  <div className="flex items-center h-5 mt-0.5 relative">
                    <input 
                      type="checkbox" 
                      checked={forceHd}
                      onChange={(e) => setForceHd(e.target.checked)}
                      className="peer appearance-none w-5 h-5 border-2 border-muted-foreground rounded bg-input checked:bg-primary checked:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors"
                    />
                    <Check className="w-3.5 h-3.5 text-primary-foreground absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 peer-checked:opacity-100 pointer-events-none transition-opacity" strokeWidth={3} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-foreground group-hover:text-primary transition-colors">Force HD Quality</span>
                    <span className="text-xs text-muted-foreground mt-1 leading-relaxed">Filter out SD streams automatically</span>
                  </div>
                </label>
              </div>
            </div>

            {/* Output Side */}
            <div className="md:col-span-3 flex flex-col">
              <div className="bg-card border border-border rounded-3xl p-7 shadow-xl h-full flex flex-col justify-between space-y-8 relative overflow-hidden">
                {/* Decorative glow inside card */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px] pointer-events-none" />

                <div className="relative z-10">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-4 flex items-center gap-2">
                    <Layers className="w-4 h-4" /> Generated Manifest
                  </h3>
                  <div className="relative group">
                    <pre className="p-5 rounded-2xl bg-background border border-border/80 text-sm font-mono text-primary/90 overflow-x-auto whitespace-pre-wrap break-all shadow-inner leading-relaxed">
                      {manifestUrl}
                    </pre>
                    <button 
                      onClick={copyToClipboard}
                      className="absolute top-3 right-3 p-2.5 bg-card/90 backdrop-blur border border-border rounded-xl text-muted-foreground hover:text-primary hover:border-primary/50 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 shadow-sm"
                      title="Copy URL"
                    >
                      {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-border/50 relative z-10">
                  <a 
                    href={stremioUrl}
                    className="flex-1 flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground py-4 px-6 rounded-2xl font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98] shadow-[0_0_20px_rgba(255,102,0,0.3)]"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    Install in Stremio
                  </a>
                  <button 
                    onClick={copyToClipboard}
                    className="flex items-center justify-center gap-2 bg-secondary hover:bg-secondary/80 text-secondary-foreground py-4 px-8 rounded-2xl font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    {copied ? "Copied" : "Copy Link"}
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* How it works */}
          <div className="grid md:grid-cols-3 gap-8 pt-16 animate-in fade-in slide-in-from-bottom-8 duration-1000 ease-out delay-300 fill-mode-both">
            <div className="space-y-4 bg-background/30 p-6 rounded-3xl border border-border/50">
              <div className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center text-primary shadow-lg shadow-primary/5">
                <span className="font-bold text-xl font-mono">1</span>
              </div>
              <h4 className="font-bold text-foreground text-lg">Find Content</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                NetMirror intercepts Stremio's TMDB requests and automatically searches for matches across configured OTT platforms.
              </p>
            </div>
            <div className="space-y-4 bg-background/30 p-6 rounded-3xl border border-border/50">
              <div className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center text-primary shadow-lg shadow-primary/5">
                <span className="font-bold text-xl font-mono">2</span>
              </div>
              <h4 className="font-bold text-foreground text-lg">Extract Streams</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                It bypasses geo-blocks and extracts direct, high-speed streaming links directly from the source providers.
              </p>
            </div>
            <div className="space-y-4 bg-background/30 p-6 rounded-3xl border border-border/50">
              <div className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center text-primary shadow-lg shadow-primary/5">
                <span className="font-bold text-xl font-mono">3</span>
              </div>
              <h4 className="font-bold text-foreground text-lg">Instant Play</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Links are piped directly back to Stremio. No buffering, no external players needed. Just pure streaming.
              </p>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
