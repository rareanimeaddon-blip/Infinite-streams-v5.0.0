export const STREMIO_MANIFEST = {
  id: "community.hdghartv.vaplayer.stremio.addon",
  version: "2.0.0",
  name: "HDGharTV + VaPlayer",
  description:
    "Stream movies & TV shows from HDGharTV and VaPlayer. Multiple quality options. Works with IMDB/Cinemeta catalogs.",
  logo: "https://hdghartv.cc/favicon.ico",
  background: "https://i.imgur.com/t8wVwcg.jpg",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: [],
  behaviorHints: {
    adult: false,
    configurationRequired: false,
    p2p: false,
  },
};
