import { logger } from "../../lib/logger";

const HDGHARTV_API = "https://hdghartv.cc/api";
const CINEMETA_API = "https://v3-cinemeta.strem.io";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  Accept: "application/json, */*",
  Referer: "https://hdghartv.cc/",
};

export interface StreamResult {
  name: string;
  title: string;
  url: string;
  behaviorHints?: {
    bingeGroup?: string;
    notWebReady?: boolean;
  };
}

// ─── Helpers ────────────────────────────────────────────────────────────────

async function fetchJson<T>(url: string, timeoutMs = 10_000): Promise<T | null> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, { headers: HEADERS, signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch (err) {
    logger.warn({ url, err }, "fetch failed");
    return null;
  }
}

/** Get the title (and year) for an IMDB ID using Cinemeta — no API key needed. */
async function getTitleFromImdb(
  imdbId: string,
  type: "movie" | "series"
): Promise<string | null> {
  const data = await fetchJson<{ meta?: { name?: string } }>(
    `${CINEMETA_API}/meta/${type}/${imdbId}.json`
  );
  return data?.meta?.name ?? null;
}

interface HdgSearchResult {
  movies: Array<{ _id: string; title: string; tmdbId?: number }>;
  series: Array<{ _id: string; title: string; tmdbId?: number }>;
}

/** Search HDGharTV by title and return the best-matching internal _id. */
async function searchHdghartv(
  title: string,
  kind: "movie" | "series"
): Promise<string | null> {
  const encoded = encodeURIComponent(title);
  const data = await fetchJson<HdgSearchResult>(
    `${HDGHARTV_API}/search?q=${encoded}`
  );
  if (!data) return null;

  const results = kind === "movie" ? data.movies : data.series;
  if (!results?.length) return null;

  // Try exact title match first, fall back to first result.
  const exact = results.find(
    (r) => r.title.toLowerCase() === title.toLowerCase()
  );
  return (exact ?? results[0])!._id;
}

interface HdgStreamingLink {
  quality: string;
  url: string;
  type: string;
  isActive: boolean;
}

// Quality sort order (best first)
const QUALITY_RANK: Record<string, number> = {
  "4K": 0,
  "1080p": 1,
  "720p": 2,
  "480p": 3,
  "360p": 4,
};

function sortLinks(links: HdgStreamingLink[]): HdgStreamingLink[] {
  return [...links].sort(
    (a, b) =>
      (QUALITY_RANK[a.quality] ?? 99) - (QUALITY_RANK[b.quality] ?? 99)
  );
}

function linksToStreams(
  links: HdgStreamingLink[],
  labelSuffix = "",
  behaviorHints: StreamResult["behaviorHints"] = {}
): StreamResult[] {
  return sortLinks(links.filter((l) => l.isActive && l.url)).map((l) => ({
    name: "HDGharTV",
    title: `HDGharTV${labelSuffix ? " " + labelSuffix : ""} · ${l.quality}`,
    url: l.url,
    behaviorHints,
  }));
}

// ─── Movie streams ───────────────────────────────────────────────────────────

interface HdgMovie {
  _id: string;
  title: string;
  streamingLinks?: HdgStreamingLink[];
  enableWatch?: boolean;
}

export async function getMovieStreams(imdbId: string): Promise<StreamResult[]> {
  // 1. Resolve title
  const title = await getTitleFromImdb(imdbId, "movie");
  if (!title) {
    logger.warn({ imdbId }, "Could not resolve title from Cinemeta");
    return [];
  }
  logger.info({ imdbId, title }, "Resolved movie title");

  // 2. Find internal ID
  const internalId = await searchHdghartv(title, "movie");
  if (!internalId) {
    logger.warn({ title }, "Movie not found on HDGharTV");
    return [];
  }

  // 3. Fetch movie detail with fresh-signed streaming links
  const movie = await fetchJson<HdgMovie>(
    `${HDGHARTV_API}/movies/public/${internalId}`
  );
  if (!movie?.streamingLinks?.length) {
    logger.warn({ internalId, title }, "No streaming links on HDGharTV movie");
    return [];
  }

  const streams = linksToStreams(movie.streamingLinks);
  logger.info({ title, count: streams.length }, "Got movie streams from HDGharTV");
  return streams;
}

// ─── Series streams ──────────────────────────────────────────────────────────

interface HdgEpisode {
  episodeNumber: number;
  streamingLinks?: HdgStreamingLink[];
}

interface HdgSeason {
  seasonNumber: number;
  episodes?: HdgEpisode[];
}

interface HdgSeries {
  _id: string;
  title: string;
  seasons?: HdgSeason[];
  enableWatch?: boolean;
}

export async function getSeriesStreams(
  imdbId: string,
  season: number,
  episode: number
): Promise<StreamResult[]> {
  // 1. Resolve title
  const title = await getTitleFromImdb(imdbId, "series");
  if (!title) {
    logger.warn({ imdbId }, "Could not resolve series title from Cinemeta");
    return [];
  }
  logger.info({ imdbId, title, season, episode }, "Resolved series title");

  // 2. Find internal ID
  const internalId = await searchHdghartv(title, "series");
  if (!internalId) {
    logger.warn({ title }, "Series not found on HDGharTV");
    return [];
  }

  // 3. Fetch series detail
  const series = await fetchJson<HdgSeries>(
    `${HDGHARTV_API}/series/public/${internalId}`
  );
  if (!series?.seasons?.length) {
    logger.warn({ internalId, title }, "No seasons on HDGharTV series");
    return [];
  }

  // 4. Find the right season + episode
  const seasonData = series.seasons.find((s) => s.seasonNumber === season);
  if (!seasonData) {
    logger.warn({ title, season }, "Season not found on HDGharTV");
    return [];
  }

  const episodeData = seasonData.episodes?.find(
    (e) => e.episodeNumber === episode
  );
  if (!episodeData?.streamingLinks?.length) {
    logger.warn({ title, season, episode }, "Episode or links not found on HDGharTV");
    return [];
  }

  const bingeGroup = `${imdbId}:s${season}`;
  const streams = linksToStreams(
    episodeData.streamingLinks,
    `S${season}E${episode}`,
    { bingeGroup }
  );
  logger.info({ title, season, episode, count: streams.length }, "Got episode streams from HDGharTV");
  return streams;
}
