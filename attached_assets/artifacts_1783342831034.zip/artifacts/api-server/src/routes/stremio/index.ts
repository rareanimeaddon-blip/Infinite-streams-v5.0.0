import { Router, type IRouter } from "express";
import { STREMIO_MANIFEST } from "./manifest";
import { getMovieStreams, getSeriesStreams } from "./providers";
import { getVaPlayerMovieStreams, getVaPlayerSeriesStreams } from "./vaplayer";
import { logger } from "../../lib/logger";

const router: IRouter = Router();

// CORS headers required by Stremio for all responses
router.use((_req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,HEAD,OPTIONS");
  next();
});

router.options("/{*path}", (_req, res) => {
  res.sendStatus(200);
});

/**
 * Stremio addon manifest
 * Install via: stremio://[base-url]/stremio/manifest.json
 */
router.get("/manifest.json", (_req, res) => {
  res.json(STREMIO_MANIFEST);
});

/**
 * Stream handler — returns playable stream URLs for movies and series.
 * 
 * Movie:  /stream/movie/{imdbId}.json          (e.g. tt1375666)
 * Series: /stream/series/{imdbId}:{s}:{e}.json (e.g. tt0944947:1:1)
 */
router.get("/stream/:type/:id.json", async (req, res) => {
  const { type, id } = req.params;

  logger.info({ type, id }, "Stremio stream request");

  try {
    let streams: Awaited<ReturnType<typeof getMovieStreams>>;

    if (type === "movie") {
      if (!id.startsWith("tt")) {
        res.json({ streams: [] });
        return;
      }
      // Run both providers in parallel — neither depends on the other
      const [hdgStreams, vaStreams] = await Promise.all([
        getMovieStreams(id),
        getVaPlayerMovieStreams(id),
      ]);
      streams = [...hdgStreams, ...vaStreams];
    } else if (type === "series") {
      const parts = id.split(":");
      if (parts.length < 3) {
        res.json({ streams: [] });
        return;
      }
      const [imdbId, seasonStr, episodeStr] = parts;
      if (!imdbId || !imdbId.startsWith("tt")) {
        res.json({ streams: [] });
        return;
      }
      const season = parseInt(seasonStr ?? "", 10);
      const episode = parseInt(episodeStr ?? "", 10);
      if (isNaN(season) || isNaN(episode)) {
        res.json({ streams: [] });
        return;
      }
      // Run both providers in parallel
      const [hdgStreams, vaStreams] = await Promise.all([
        getSeriesStreams(imdbId, season, episode),
        getVaPlayerSeriesStreams(imdbId, season, episode),
      ]);
      streams = [...hdgStreams, ...vaStreams];
    } else {
      res.json({ streams: [] });
      return;
    }

    logger.info({ type, id, count: streams.length }, "Returning streams");
    res.json({ streams });
  } catch (err) {
    logger.error({ err, type, id }, "Error fetching streams");
    res.json({ streams: [] });
  }
});

/**
 * Addon catalog endpoint — we don't provide catalogs, but handle gracefully
 */
router.get("/catalog/:type/:id.json", (_req, res) => {
  res.json({ metas: [] });
});

/**
 * Meta endpoint — we don't provide meta, handled by Cinemeta
 */
router.get("/meta/:type/:id.json", (_req, res) => {
  res.json({ meta: null });
});

export default router;
