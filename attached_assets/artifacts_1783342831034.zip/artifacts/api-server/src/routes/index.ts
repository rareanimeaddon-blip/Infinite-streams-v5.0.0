import { Router, type IRouter } from "express";
import healthRouter from "./health";
import stremioRouter from "./stremio/index";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/stremio", stremioRouter);

export default router;
