import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Copy, 
  CheckCircle2, 
  MonitorPlay, 
  Layers, 
  Settings,
  Film,
  Sparkles,
  Clapperboard,
  Tv2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function InstallPage() {
  const [manifestUrl, setManifestUrl] = useState('');
  const [stremioUrl, setStremioUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const origin = window.location.origin;
    setManifestUrl(`${origin}/api/stremio/manifest.json`);
    setStremioUrl(`stremio://${window.location.host}/api/stremio/manifest.json`);
  }, []);

  const handleCopy = async () => {
    if (!manifestUrl) return;
    try {
      await navigator.clipboard.writeText(manifestUrl);
      setCopied(true);
      toast({
        title: "URL Copied",
        description: "Manifest URL has been copied to clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Please manually copy the URL.",
        variant: "destructive"
      });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 100, damping: 15 }
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-background">
      {/* Background ambient effects */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute top-[40%] left-[60%] w-[30%] h-[30%] bg-blue-500/10 rounded-full blur-[120px] pointer-events-none" />
      
      {/* Noise texture overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
        }}
      />

      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10 max-w-6xl">
        <motion.div 
          className="flex flex-col items-center text-center mb-24 mt-12"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel text-primary-foreground text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>The premium streaming experience</span>
          </motion.div>

          <motion.h1 variants={itemVariants} className="text-7xl md:text-9xl font-bold mb-6 tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white via-white/90 to-white/20">
            HDGhar<span className="text-primary glow-text">TV</span>
          </motion.h1>

          <motion.p variants={itemVariants} className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-12 font-light leading-relaxed">
            Instantly unlock premium movie and TV show catalogs in Stremio. Multiple ultra-fast providers, zero buffering, absolute freedom.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col md:flex-row items-center gap-4 w-full max-w-2xl">
            <a 
              href={stremioUrl}
              className="group relative flex items-center justify-center gap-3 w-full md:w-auto px-10 py-5 bg-primary text-primary-foreground rounded-2xl font-semibold text-lg overflow-hidden transition-all hover:scale-105 active:scale-95 glow-purple"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
              <Play className="w-6 h-6 fill-current relative z-10" />
              <span className="relative z-10">Install in Stremio</span>
            </a>

            <div className="flex w-full md:flex-1 items-center gap-2 glass-panel p-2 rounded-2xl border-white/10">
              <code className="flex-1 px-4 py-3 text-sm text-muted-foreground text-left overflow-hidden text-ellipsis whitespace-nowrap font-mono selection:bg-primary/30">
                {manifestUrl || "Generating manifest..."}
              </code>
              <button
                onClick={handleCopy}
                className="flex items-center justify-center w-12 h-12 bg-white/5 hover:bg-white/10 rounded-xl transition-colors shrink-0 border border-white/5"
                aria-label="Copy URL"
              >
                {copied ? <CheckCircle2 className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5 text-white" />}
              </button>
            </div>
          </motion.div>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-32"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={containerVariants}
        >
          {/* Primary Provider */}
          <motion.div variants={itemVariants} className="lg:col-span-4 glass-panel rounded-3xl p-8 md:p-12 relative overflow-hidden border-primary/30">
            <div className="absolute top-[-50%] right-[-10%] w-96 h-96 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 relative z-10">
              <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/20 text-primary text-xs font-bold uppercase tracking-wider mb-5 border border-primary/30">
                  Primary Source
                </div>
                <h3 className="text-4xl font-display font-bold text-white mb-4">HDGharTV Engine</h3>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Lightning-fast direct streams with superior quality, robust multi-language subtitle support, and unparalleled reliability for your late-night binges.
                </p>
              </div>
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/30 shrink-0">
                <MonitorPlay className="w-12 h-12 text-white" />
              </div>
            </div>
          </motion.div>

          {/* Backup Providers */}
          {[
            { name: "VidSrc", icon: Film, desc: "Reliable 4K & HD fallback network" },
            { name: "2Embed", icon: Layers, desc: "Massive historical content archive" },
            { name: "AutoEmbed", icon: Clapperboard, desc: "Smart source routing and delivery" },
            { name: "Embed.su", icon: Tv2, desc: "International streaming network" }
          ].map((provider) => (
            <motion.div key={provider.name} variants={itemVariants} className="glass-panel rounded-3xl p-6 md:p-8 hover:bg-white/[0.08] transition-colors border-white/5 group">
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-6 border border-white/10 group-hover:bg-white/10 transition-colors">
                <provider.icon className="w-7 h-7 text-accent" />
              </div>
              <h4 className="text-2xl font-display font-bold text-white mb-3">{provider.name}</h4>
              <p className="text-muted-foreground leading-relaxed">{provider.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <motion.h2 variants={itemVariants} className="text-4xl font-display font-bold mb-8 text-white">Universal Catalogs</motion.h2>
            <div className="space-y-4">
              {[
                { title: "IMDB Integration", desc: "Access the world's most popular top-rated movies, shows, and curated user lists instantly." },
                { title: "TMDB Network", desc: "Discover trending content, upcoming releases, and incredibly deep metadata for everything." },
                { title: "Cinemeta Ready", desc: "Works flawlessly with Stremio's default rich catalog integration right out of the box." }
              ].map((catalog) => (
                <motion.div key={catalog.title} variants={itemVariants} className="flex gap-6 p-6 rounded-3xl hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                    <CheckCircle2 className="w-7 h-7 text-primary" />
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-xl mb-2">{catalog.title}</h5>
                    <p className="text-muted-foreground leading-relaxed">{catalog.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="glass-panel rounded-3xl p-8 md:p-12 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-[80px] pointer-events-none" />
            
            <motion.h2 variants={itemVariants} className="text-3xl font-display font-bold mb-10 flex items-center gap-4 text-white">
              <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                <Settings className="w-6 h-6 text-primary" />
              </div>
              Manual Install
            </motion.h2>
            
            <div className="space-y-8 relative before:absolute before:top-4 before:bottom-4 before:left-[21px] before:w-[2px] before:bg-gradient-to-b before:from-primary/50 before:via-white/10 before:to-transparent">
              {[
                "Copy the manifest URL from the top of this page.",
                "Open your Stremio application (Desktop, Web, or Mobile).",
                "Navigate to the Addons section in the settings menu.",
                "Paste the URL into the search bar and click Install."
              ].map((step, i) => (
                <motion.div key={i} variants={itemVariants} className="relative flex items-start gap-8">
                  <div className="w-11 h-11 rounded-full bg-background border border-primary/30 flex items-center justify-center text-primary font-bold z-10 shrink-0 shadow-lg shadow-black/50 glow-purple">
                    {i + 1}
                  </div>
                  <div className="pt-2.5">
                    <p className="text-white/80 text-lg leading-relaxed">{step}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="relative z-10 py-12 mt-24 border-t border-white/5 text-center text-muted-foreground">
        <p className="text-sm tracking-wide">HDGharTV &copy; {new Date().getFullYear()}. Not affiliated with Stremio.</p>
      </footer>
    </div>
  );
}