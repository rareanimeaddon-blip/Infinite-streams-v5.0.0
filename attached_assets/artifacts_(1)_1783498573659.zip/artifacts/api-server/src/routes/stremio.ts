import { Router, type IRouter, type Request, type Response } from "express";
import { getMovieMeta, getSeriesMeta } from "../lib/cinemeta.js";
import { getStreams as getOTCStreams } from "../lib/onetouchtv.js";
import { fetchVidLinkStream, ensureVidLinkReady, type VidLinkQuality } from "../lib/vidlink.js";
import { buildProxyUrl } from "./proxy.js";
import { logger } from "../lib/logger.js";

const router: IRouter = Router();

// ─── Manifest ─────────────────────────────────────────────────────────────────

const MANIFEST = {
  id: "com.combined.stremio",
  version: "1.0.0",
  name: "OneTouchTV + VidLink",
  description:
    "Streams from OneTouchTV (Asian dramas & movies) and VidLink.pro (multi-quality MP4). OneTouchTV results appear first.",
  logo: "https://static.devcorp.me/logo.png",
  resources: ["stream"],
  types: ["movie", "series"],
  idPrefixes: ["tt"],
  catalogs: [],
  behaviorHints: {
    adult: false,
    p2p: false,
  },
} as const;

// ─── Warm up VidLink WASM on first request ─────────────────────────────────

let warmupStarted = false;
function maybeWarmUp() {
  if (!warmupStarted) {
    warmupStarted = true;
    ensureVidLinkReady().catch((err) =>
      logger.error({ err }, "VidLink WASM warmup failed"),
    );
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function serverBase(req: Request): string {
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? "https";
  const host =
    (req.headers["x-forwarded-host"] as string | undefined) ??
    (req.headers["host"] as string | undefined) ??
    "localhost";
  return `${proto}://${host}/api`;
}

function filenameFromUrl(cdnUrl: string, label: string): string {
  try {
    const pathname = new URL(cdnUrl).pathname;
    const base = pathname.split("/").pop() ?? "stream.mp4";
    return base.endsWith(".mp4") ? base : `${label.replace(/\s+/g, "_")}.mp4`;
  } catch {
    return `${label.replace(/\s+/g, "_")}.mp4`;
  }
}

const QUALITY_ORDER = ["1080", "720", "480", "360"] as const;
type QualityKey = (typeof QUALITY_ORDER)[number];
const QUALITY_LABELS: Record<string, string> = {
  "1080": "1080p",
  "720": "720p",
  "480": "480p",
  "360": "360p",
};

function buildVidLinkStreams(
  qualities: Record<string, VidLinkQuality>,
  base: string,
): Array<Record<string, unknown>> {
  const streams: Array<Record<string, unknown>> = [];

  for (const q of QUALITY_ORDER) {
    const quality = qualities[q];
    if (!quality?.url) continue;
    const codec = quality.codecName ? ` • ${quality.codecName.toUpperCase()}` : "";
    const label = QUALITY_LABELS[q] ?? `${q}p`;
    const filename = filenameFromUrl(quality.url, label);
    streams.push({
      name: "VidLink",
      description: `${label}${codec}`,
      url: buildProxyUrl(base, quality.url, filename),
      behaviorHints: { notWebReady: false, filename },
    });
  }

  for (const [key, quality] of Object.entries(qualities)) {
    if (QUALITY_ORDER.includes(key as QualityKey)) continue;
    if (!quality?.url) continue;
    const codec = quality.codecName ? ` • ${quality.codecName.toUpperCase()}` : "";
    const filename = filenameFromUrl(quality.url, `${key}p`);
    streams.push({
      name: "VidLink",
      description: `${key}p${codec}`,
      url: buildProxyUrl(base, quality.url, filename),
      behaviorHints: { notWebReady: false, filename },
    });
  }

  return streams;
}

// ─── Landing page ──────────────────────────────────────────────────────────────

router.get("/", (req: Request, res: Response) => {
  maybeWarmUp();
  const base = serverBase(req);
  const manifestUrl = `${base}/manifest.json`;
  const host = manifestUrl.replace("https://", "").replace("http://", "").split("/")[0];
  const installUrl = `stremio://${host}/api/manifest.json`;

  res.type("html").send(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>OneTouchTV + VidLink Stremio Addon</title>
<style>
  body{font-family:system-ui,sans-serif;background:#1a1a2e;color:#eee;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;box-sizing:border-box}
  .card{background:#16213e;border-radius:12px;padding:2rem;max-width:620px;width:100%;box-shadow:0 4px 24px #0008}
  h1{font-size:1.8rem;margin:0 0 .5rem}
  p{color:#aaa;margin:.5rem 0 1.5rem;line-height:1.6}
  .url{background:#0f3460;border-radius:8px;padding:1rem;font-family:monospace;font-size:.82rem;word-break:break-all;margin:.5rem 0 1.5rem;color:#7ec8e3}
  a.btn{display:inline-block;background:#e94560;color:#fff;padding:.7rem 1.8rem;border-radius:8px;text-decoration:none;font-weight:700}
  a.btn:hover{background:#c73652}
  .label{color:#888;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;margin-top:1.2rem}
  .providers{display:flex;gap:1rem;margin:1rem 0;flex-wrap:wrap}
  .badge{background:#20304f;border-radius:6px;padding:.3rem .8rem;font-size:.85rem;color:#7ec8e3}
</style>
</head>
<body>
<div class="card">
  <h1>OneTouchTV + VidLink</h1>
  <div class="providers">
    <span class="badge">📺 OneTouchTV — Asian dramas &amp; movies</span>
    <span class="badge">🎬 VidLink — Multi-quality MP4</span>
  </div>
  <p>Install once — get streams from both providers. OneTouchTV results appear first in Stremio.</p>
  <div class="label">Manifest URL</div>
  <div class="url">${manifestUrl}</div>
  <a class="btn" href="${installUrl}">Install in Stremio</a>
  <div class="label" style="margin-top:1.5rem">Or paste the URL above in Stremio → Addons → Community Addons → Add URL</div>
</div>
</body>
</html>`);
});

// ─── Manifest ──────────────────────────────────────────────────────────────────

router.get("/manifest.json", (_req: Request, res: Response) => {
  maybeWarmUp();
  res
    .set("Access-Control-Allow-Origin", "*")
    .set("Access-Control-Allow-Headers", "*")
    .json(MANIFEST);
});

// ─── Movie streams ─────────────────────────────────────────────────────────────

router.get(
  "/stream/movie/:id.json",
  async (req: Request, res: Response): Promise<void> => {
    const imdbId = String(req.params["id"]);
    res.set("Access-Control-Allow-Origin", "*");
    logger.info({ imdbId }, "Stream request: movie");

    // Single cinemeta call — both providers use the result
    const meta = await getMovieMeta(imdbId);
    if (!meta) {
      logger.warn({ imdbId }, "Could not resolve movie meta");
      res.json({ streams: [] });
      return;
    }

    const year = meta.year ? parseInt(meta.year, 10) : null;

    // Run both providers in parallel
    const [otcResult, vlResult] = await Promise.allSettled([
      getOTCStreams(meta.name, "movie", year, null, null, imdbId, meta.country),
      meta.moviedbId
        ? fetchVidLinkStream({ type: "movie", tmdbId: meta.moviedbId })
        : Promise.resolve(null),
    ]);

    const streams: Array<Record<string, unknown>> = [];

    // OneTouchTV first
    if (otcResult.status === "fulfilled") {
      for (const s of otcResult.value) {
        streams.push({ name: s.name, description: s.title, url: s.url });
      }
    } else {
      logger.warn({ err: otcResult.reason }, "OneTouchTV movie stream failed");
    }

    // VidLink second
    if (vlResult.status === "fulfilled" && vlResult.value?.stream?.qualities) {
      streams.push(...buildVidLinkStreams(vlResult.value.stream.qualities, serverBase(req)));
    } else if (vlResult.status === "rejected") {
      logger.warn({ err: vlResult.reason }, "VidLink movie stream failed");
    }

    logger.info({ imdbId, count: streams.length }, "Returning streams");
    res.json({ streams });
  },
);

// ─── Series streams ─────────────────────────────────────────────────────────────

router.get(
  "/stream/series/:id.json",
  async (req: Request, res: Response): Promise<void> => {
    // Stremio format: tt0903747:1:1
    const rawId = String(req.params["id"]);
    res.set("Access-Control-Allow-Origin", "*");

    const parts = rawId.split(":");
    if (parts.length < 3) { res.json({ streams: [] }); return; }

    const [imdbId, rawSeason, rawEpisode] = parts;
    const season = Number(rawSeason);
    const episode = Number(rawEpisode);

    if (!imdbId || Number.isNaN(season) || Number.isNaN(episode)) {
      res.json({ streams: [] });
      return;
    }

    logger.info({ imdbId, season, episode }, "Stream request: series");

    // Single cinemeta call
    const meta = await getSeriesMeta(imdbId);
    if (!meta) {
      logger.warn({ imdbId }, "Could not resolve series meta");
      res.json({ streams: [] });
      return;
    }

    const year = meta.year ? parseInt(meta.year, 10) : null;

    // Run both providers in parallel
    const [otcResult, vlResult] = await Promise.allSettled([
      getOTCStreams(meta.name, "series", year, season, episode, imdbId, meta.country),
      meta.moviedbId
        ? fetchVidLinkStream({ type: "tv", tmdbId: meta.moviedbId, season, episode })
        : Promise.resolve(null),
    ]);

    const streams: Array<Record<string, unknown>> = [];

    // OneTouchTV first
    if (otcResult.status === "fulfilled") {
      for (const s of otcResult.value) {
        streams.push({ name: s.name, description: s.title, url: s.url });
      }
    } else {
      logger.warn({ err: otcResult.reason }, "OneTouchTV series stream failed");
    }

    // VidLink second
    if (vlResult.status === "fulfilled" && vlResult.value?.stream?.qualities) {
      streams.push(...buildVidLinkStreams(vlResult.value.stream.qualities, serverBase(req)));
    } else if (vlResult.status === "rejected") {
      logger.warn({ err: vlResult.reason }, "VidLink series stream failed");
    }

    logger.info({ imdbId, season, episode, count: streams.length }, "Returning streams");
    res.json({ streams });
  },
);

export default router;
