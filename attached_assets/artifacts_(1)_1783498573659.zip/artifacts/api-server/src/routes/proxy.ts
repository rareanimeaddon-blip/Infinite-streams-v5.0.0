/**
 * Stream proxy — mirrors the pengu.uk /direct/external/ pattern.
 *
 * URL format:  GET /api/proxy/{base64url(cdnUrl)}/{filename}
 *
 * Returns a 307 redirect straight to the CDN URL (same as pengu.uk does).
 * Stremio follows the redirect and plays from the CDN directly — only one
 * CDN hit total, from the user's IP, avoiding rate-limit 429s.
 *
 * We never buffer the video through our server.
 */

import { Router, type IRouter, type Request, type Response } from "express";
import { logger } from "../lib/logger.js";

const router: IRouter = Router();

/** Encode a CDN URL to a URL-safe base64 string (no padding). */
export function encodeProxyUrl(cdnUrl: string): string {
  return Buffer.from(cdnUrl).toString("base64url");
}

/**
 * Build the full proxy URL that Stremio will call.
 * @param serverBase  public origin + /api prefix, e.g. https://domain.com/api
 * @param cdnUrl      raw signed CDN URL from vidlink.pro
 * @param filename    display filename (e.g. "fight.club.1080p.mp4")
 */
export function buildProxyUrl(
  serverBase: string,
  cdnUrl: string,
  filename: string,
): string {
  return `${serverBase}/proxy/${encodeProxyUrl(cdnUrl)}/${encodeURIComponent(filename)}`;
}

// ─── Handler ──────────────────────────────────────────────────────────────────

router.get(
  "/proxy/:encodedUrl/:filename",
  (req: Request, res: Response): void => {
    const { encodedUrl } = req.params as { encodedUrl: string; filename: string };

    let targetUrl: string;
    try {
      targetUrl = Buffer.from(encodedUrl, "base64url").toString();
    } catch {
      res.status(400).json({ error: "Invalid proxy URL" });
      return;
    }

    // Validate it's a URL we generated (only allow known CDN hosts)
    let parsed: URL;
    try {
      parsed = new URL(targetUrl);
    } catch {
      res.status(400).json({ error: "Malformed URL" });
      return;
    }

    const ALLOWED = [
      "hakunaymatata.com",
      "bcdn.hakunaymatata.com",
      "sacdn.hakunaymatata.com",
    ];
    const ok = ALLOWED.some(
      (h) => parsed.hostname === h || parsed.hostname.endsWith(`.${h}`),
    );
    if (!ok) {
      logger.warn({ host: parsed.hostname }, "Proxy: blocked disallowed host");
      res.status(403).json({ error: "Host not allowed" });
      return;
    }

    logger.info({ host: parsed.hostname }, "Proxy: redirecting to CDN");

    // 307 keeps the HTTP method — Stremio follows this to the CDN directly
    res
      .setHeader("Access-Control-Allow-Origin", "*")
      .setHeader("Cache-Control", "private, max-age=30")
      .redirect(307, targetUrl);
  },
);

// OPTIONS preflight
router.options("/proxy/:encodedUrl/:filename", (_req, res) => {
  res
    .setHeader("Access-Control-Allow-Origin", "*")
    .setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
    .setHeader("Access-Control-Allow-Headers", "*")
    .status(204)
    .end();
});

export default router;
