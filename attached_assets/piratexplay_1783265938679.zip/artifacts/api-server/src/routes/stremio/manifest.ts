import type { Request, Response } from "express";

export const MANIFEST = {
  id: "community.piratexplay.stremio",
  version: "1.3.0",
  name: "PirateXPlay",
  description:
    "Watch free anime, movies and cartoons from PirateXPlay — sub, dub, HD quality. Streams play directly inside Stremio. Compatible with IMDB, TMDB and Cinemeta catalogs.",
  logo: "https://piratexplay.cc/public/img/sitename/logo_img.png",
  background: "https://piratexplay.cc/public/img/sitename/anime-bg.jpg",
  types: ["series", "movie"],
  catalogs: [
    {
      type: "series",
      id: "pxp-anime",
      name: "PirateXPlay — Anime",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
    {
      type: "series",
      id: "pxp-cartoon",
      name: "PirateXPlay — Cartoons",
      extra: [{ name: "skip", isRequired: false }],
    },
    {
      type: "movie",
      id: "pxp-movies",
      name: "PirateXPlay — Movies",
      extra: [
        { name: "search", isRequired: false },
        { name: "skip", isRequired: false },
      ],
    },
    {
      type: "series",
      id: "pxp-popular",
      name: "PirateXPlay — Popular",
      extra: [{ name: "skip", isRequired: false }],
    },
    {
      type: "series",
      id: "pxp-latest",
      name: "PirateXPlay — Latest",
      extra: [{ name: "skip", isRequired: false }],
    },
    {
      type: "series",
      id: "pxp-complete",
      name: "PirateXPlay — Complete",
      extra: [{ name: "skip", isRequired: false }],
    },
    {
      type: "series",
      id: "pxp-ongoing",
      name: "PirateXPlay — Ongoing",
      extra: [{ name: "skip", isRequired: false }],
    },
  ],
  resources: [
    "catalog",
    {
      name: "meta",
      types: ["series", "movie"],
      idPrefixes: ["pxp:"],
    },
    {
      name: "stream",
      types: ["series", "movie"],
      // Handle PirateXPlay native IDs, IMDB IDs (Cinemeta), and TMDB IDs
      idPrefixes: ["pxp:", "tt", "tmdb:"],
    },
  ],
  behaviorHints: {
    adult: false,
    p2p: false,
    configurable: false,
  },
};

export function manifestHandler(_req: Request, res: Response) {
  res.json(MANIFEST);
}
