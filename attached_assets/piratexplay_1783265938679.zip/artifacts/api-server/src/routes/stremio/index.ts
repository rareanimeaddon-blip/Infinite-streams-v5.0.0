import { Router } from "express";
import { manifestHandler } from "./manifest.js";
import { catalogHandler } from "./catalog.js";
import { metaHandler } from "./meta.js";
import { streamHandler } from "./stream.js";
import {
  m3u8ProxyHandler,
  segProxyHandler,
} from "./proxy.js";

export const stremioRouter = Router();

// CORS — Stremio requires fully open CORS on all addon endpoints
stremioRouter.use((_req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Cache-Control", "max-age=300, stale-while-revalidate=600");
  if (_req.method === "OPTIONS") {
    res.sendStatus(200);
    return;
  }
  next();
});

// Manifest
stremioRouter.get("/manifest.json", manifestHandler);

// Catalog with optional extra args:
//   /catalog/:type/:id.json
//   /catalog/:type/:id/:extra.json
stremioRouter.get("/catalog/:type/:id/:extra.json", (req, res) => {
  (req.params as Record<string, string>)[0] = req.params.extra ?? "";
  return catalogHandler(req, res);
});
stremioRouter.get("/catalog/:type/:id.json", catalogHandler);

// Meta
stremioRouter.get("/meta/:type/:id.json", metaHandler);

// Stream — handles both pxp: IDs and IMDB tt IDs (with optional :season:episode)
stremioRouter.get("/stream/:type/:id.json", streamHandler);

// HLS m3u8 proxy — rewrites relative URIs to absolute so Stremio's player works
stremioRouter.get("/proxy/m3u8", m3u8ProxyHandler);
// HLS segment proxy — fetches binary segments with correct Referer/IP for CDNs
// that enforce session-based or Referer-based auth on segment requests
stremioRouter.get("/proxy/seg", segProxyHandler);
