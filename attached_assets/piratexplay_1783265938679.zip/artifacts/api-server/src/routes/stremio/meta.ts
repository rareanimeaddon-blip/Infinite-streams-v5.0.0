import type { Request, Response } from "express";
import {
  fetchAnimeMeta,
  type AnimeMeta,
  type ContentType,
} from "../../lib/piratexplay.js";

interface StremioVideo {
  id: string;
  title: string;
  season: number;
  episode: number;
  released?: string;
  thumbnail?: string;
  overview?: string;
}

interface StremioMetaObject {
  id: string;
  type: string;
  name: string;
  poster: string;
  posterShape: string;
  description?: string;
  genres?: string[];
  year?: string;
  imdbRating?: string;
  videos?: StremioVideo[];
  links?: Array<{ name: string; category: string; url: string }>;
}

function buildStremioMeta(meta: AnimeMeta): StremioMetaObject {
  const result: StremioMetaObject = {
    id: meta.id,
    type: meta.type === "movies" ? "movie" : "series",
    name: meta.title,
    poster: meta.poster,
    posterShape: "poster",
  };

  if (meta.description) result.description = meta.description;
  if (meta.genres?.length) result.genres = meta.genres;
  if (meta.year) result.year = meta.year;
  if (meta.rating) result.imdbRating = meta.rating;

  if (meta.type === "series" && meta.episodes.length > 0) {
    result.videos = meta.episodes.map((ep) => ({
      id: ep.id,
      title: ep.title || `Episode ${ep.episode}`,
      season: ep.season,
      episode: ep.episode,
    }));
  }

  result.links = [
    {
      name: "Watch on PirateXPlay",
      category: "Source",
      url: meta.detailUrl,
    },
  ];

  return result;
}

// Bounded cache (15 min TTL for meta since it's slow to fetch all seasons, max 500 entries)
const CACHE_TTL = 15 * 60 * 1000;
const CACHE_MAX = 500;
const cache = new Map<string, { data: StremioMetaObject; ts: number }>();

function cacheSet(key: string, data: StremioMetaObject) {
  if (cache.size >= CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, { data, ts: Date.now() });
}

function paramStr(v: string | string[]): string {
  return Array.isArray(v) ? (v[0] ?? "") : v;
}

function parseId(id: string): { type: ContentType; slug: string } | null {
  const parts = id.split(":");
  if (parts.length < 3 || parts[0] !== "pxp") return null;
  const type = parts[1] as ContentType;
  if (type !== "series" && type !== "movies") return null;
  const slug = parts[2];
  if (!slug) return null;
  return { type, slug };
}

export async function metaHandler(req: Request, res: Response) {
  const id = paramStr(req.params.id);
  const parsed = parseId(id);
  if (!parsed) { res.json({ meta: null }); return; }

  const cacheKey = `meta:${parsed.type}:${parsed.slug}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.ts < CACHE_TTL) {
    res.json({ meta: hit.data });
    return;
  }

  try {
    const animeMeta = await fetchAnimeMeta(parsed.type, parsed.slug);
    if (!animeMeta) { res.json({ meta: null }); return; }

    const stremioMeta = buildStremioMeta(animeMeta);
    cacheSet(cacheKey, stremioMeta);
    res.json({ meta: stremioMeta });
  } catch (err) {
    req.log?.error({ err }, "Meta fetch error");
    res.json({ meta: null });
  }
}
