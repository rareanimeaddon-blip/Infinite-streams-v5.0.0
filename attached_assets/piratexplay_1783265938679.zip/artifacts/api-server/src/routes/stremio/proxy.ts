import type { Request, Response } from "express";
import * as dns from "dns";
import * as net from "net";

const PROXY_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ---------------------------------------------------------------------------
// SSRF protection — resolve DNS and reject any private/reserved IP
// ---------------------------------------------------------------------------

/** Returns true if the IPv4 address belongs to a private/reserved range. */
function isPrivateIPv4(ip: string): boolean {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) return true; // malformed → deny
  const [a, b, c] = parts;
  return (
    a === 0 ||                                     // 0.0.0.0/8
    a === 10 ||                                    // 10.0.0.0/8
    a === 127 ||                                   // 127.0.0.0/8 loopback
    (a === 100 && b! >= 64 && b! <= 127) ||        // 100.64.0.0/10 shared
    (a === 169 && b === 254) ||                    // 169.254.0.0/16 link-local
    (a === 172 && b! >= 16 && b! <= 31) ||         // 172.16.0.0/12
    (a === 192 && b === 0 && c === 2) ||           // 192.0.2.0/24 TEST-NET-1
    (a === 192 && b === 168) ||                    // 192.168.0.0/16
    (a === 198 && b === 18) ||                     // 198.18.0.0/15 benchmarking
    (a === 198 && b === 51 && c === 100) ||        // 198.51.100.0/24 TEST-NET-2
    (a === 203 && b === 0 && c === 113) ||         // 203.0.113.0/24 TEST-NET-3
    a >= 224                                       // 224.0.0.0+ (multicast, reserved, broadcast)
  );
}

/** Returns true if the IPv6 address belongs to a private/reserved range. */
function isPrivateIPv6(raw: string): boolean {
  // Strip brackets if present
  const ip = raw.replace(/^\[|\]$/g, "").toLowerCase();

  // Unspecified / loopback
  if (ip === "::" || ip === "::1") return true;

  // IPv4-mapped / IPv4-compatible (::ffff:a.b.c.d or ::a.b.c.d)
  const v4mapped = ip.match(/^::(?:ffff:)?(\d+\.\d+\.\d+\.\d+)$/);
  if (v4mapped) return isPrivateIPv4(v4mapped[1]!);

  // Link-local fe80::/10
  if (/^fe[89ab][0-9a-f]/.test(ip)) return true;

  // ULA fc00::/7 (fc and fd)
  if (/^f[cd]/.test(ip)) return true;

  // Multicast ff00::/8
  if (ip.startsWith("ff")) return true;

  // 6to4 (2002::) — can tunnel to private IPv4
  if (ip.startsWith("2002:")) return true;

  // NAT64 (64:ff9b::/96)
  if (ip.startsWith("64:ff9b:")) return true;

  return false;
}

/**
 * SSRF guard: resolves the hostname via DNS and rejects the URL if any
 * resolved IP is in a private/loopback/reserved range.
 * Fails closed (returns false) on any error.
 */
async function isAllowedProxyTarget(url: string): Promise<boolean> {
  try {
    const parsed = new URL(url);

    // Only allow http/https
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;

    // Strip brackets from IPv6 literals
    const hostname = parsed.hostname.replace(/^\[|\]$/g, "").toLowerCase();

    // Block common internal names without DNS round-trip
    if (
      hostname === "localhost" ||
      hostname.endsWith(".local") ||
      hostname.endsWith(".internal") ||
      hostname.endsWith(".localhost")
    ) return false;

    // If already a raw IP, check it directly (no DNS needed)
    if (net.isIPv4(hostname)) return !isPrivateIPv4(hostname);
    if (net.isIPv6(hostname)) return !isPrivateIPv6(hostname);

    // Resolve DNS — all returned addresses must be public
    const addresses = await dns.promises.lookup(hostname, { all: true, family: 0 });
    if (!addresses || addresses.length === 0) return false;

    for (const { address, family } of addresses) {
      if (family === 4 && isPrivateIPv4(address)) return false;
      if (family === 6 && isPrivateIPv6(address)) return false;
    }
    return true;
  } catch {
    return false; // fail closed
  }
}

// ---------------------------------------------------------------------------
// m3u8 proxy
// ---------------------------------------------------------------------------

/**
 * HLS m3u8 proxy — fetches a remote m3u8 with the correct CDN headers and
 * rewrites URIs:
 *
 *  • Sub-playlist (.m3u8) URIs → back through this proxy (same server IP →
 *    CDN session auth stays valid for all playlist fetches).
 *
 *  • Segment / key URIs:
 *    - If ?proxyseg=1 → through /proxy/seg so segments also come from our IP
 *      with the correct Referer.  Required for CDNs (e.g. SprintCDN/Filemoon,
 *      SprintCDN/Filemoon) that verify the requesting IP or Referer on segment GETs.
 *    - Otherwise → absolute CDN URLs returned as-is; Stremio fetches directly.
 *
 * GET /api/stremio/proxy/m3u8?url=BASE64URL&referer=BASE64URL[&proxyseg=1]
 */

/**
 * Core m3u8 fetch + rewrite logic shared by m3u8ProxyHandler (fm/cdn21/etc.).
 */
async function fetchAndRewriteM3u8(
  req: Request,
  res: Response,
  targetUrl: string,
  referer: string | undefined,
  proxySegments: boolean,
): Promise<void> {
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? req.protocol ?? "https";
  const host =
    (req.headers["x-forwarded-host"] as string | undefined) ??
    (req.headers.host as string | undefined) ??
    "";
  const m3u8Endpoint = `${proto}://${host}/api/stremio/proxy/m3u8`;
  const segEndpoint = proxySegments ? `${proto}://${host}/api/stremio/proxy/seg` : undefined;

  const headers: Record<string, string> = { "User-Agent": PROXY_UA };
  if (referer) {
    headers["Referer"] = referer;
    try { headers["Origin"] = new URL(referer).origin; } catch { /* ignore */ }
  }

  const upstream = await fetch(targetUrl, { headers });
  if (!upstream.ok) {
    res.status(upstream.status).send(`Upstream ${upstream.status}`);
    return;
  }

  const m3u8 = await upstream.text();
  const base = new URL(targetUrl);
  let rewritten = rewriteM3u8(m3u8, base, m3u8Endpoint, segEndpoint, referer, proxySegments);

  // Force Hindi as the default audio track on all multi-audio streams.
  // This covers CDN-21/AWSStream and any other CDN that embeds multiple audio tracks.
  rewritten = setHindiAsDefaultAudio(rewritten);

  res.setHeader("Content-Type", "application/x-mpegURL");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Cache-Control", "max-age=60");
  res.send(rewritten);
}

export async function m3u8ProxyHandler(req: Request, res: Response) {
  const rawUrl = req.query.url as string | undefined;
  const rawRef = req.query.referer as string | undefined;
  const proxySegments = req.query.proxyseg === "1";

  if (!rawUrl) {
    res.status(400).json({ error: "url param required" });
    return;
  }

  let targetUrl: string;
  let referer: string | undefined;
  try {
    targetUrl = Buffer.from(rawUrl, "base64url").toString("utf8");
    if (rawRef) referer = Buffer.from(rawRef, "base64url").toString("utf8");
  } catch {
    res.status(400).json({ error: "bad base64url encoding" });
    return;
  }

  if (!(await isAllowedProxyTarget(targetUrl))) {
    res.status(403).json({ error: "target not allowed" });
    return;
  }

  try {
    await fetchAndRewriteM3u8(req, res, targetUrl, referer, proxySegments);
  } catch (err) {
    req.log?.error({ err }, "m3u8 proxy error");
    res.status(502).send("proxy error");
  }
}

// ---------------------------------------------------------------------------
// Segment proxy
// ---------------------------------------------------------------------------

/**
 * Binary segment proxy — fetches a CDN segment (.ts / .aac / .mp4 etc.) with
 * the correct Referer and streams the response back to Stremio.
 *
 * Required for CDNs that enforce Referer *or* IP-session auth on segment GETs.
 * (If only the m3u8 was proxied but segments were fetched directly by Stremio,
 * those CDNs would return 403/404 and playback would fail after ~2 seconds.)
 *
 * Forwards Range headers so Stremio's player can seek within segments.
 *
 * GET /api/stremio/proxy/seg?url=BASE64URL&referer=BASE64URL
 */
export async function segProxyHandler(req: Request, res: Response) {
  const rawUrl = req.query.url as string | undefined;
  const rawRef = req.query.referer as string | undefined;

  if (!rawUrl) {
    res.status(400).send("url required");
    return;
  }

  let targetUrl: string;
  let referer: string | undefined;
  try {
    targetUrl = Buffer.from(rawUrl, "base64url").toString("utf8");
    if (rawRef) referer = Buffer.from(rawRef, "base64url").toString("utf8");
  } catch {
    res.status(400).send("bad encoding");
    return;
  }

  if (!(await isAllowedProxyTarget(targetUrl))) {
    res.status(403).send("target not allowed");
    return;
  }

  const fetchHeaders: Record<string, string> = { "User-Agent": PROXY_UA };
  if (referer) {
    fetchHeaders["Referer"] = referer;
    try { fetchHeaders["Origin"] = new URL(referer).origin; } catch { /* ignore */ }
  }
  // Forward Range header so seeking works (VLC sends Range for byte-range segments)
  const range = req.headers.range;
  if (range) fetchHeaders["Range"] = range;

  try {
    const upstream = await fetch(targetUrl, { headers: fetchHeaders });

    // Forward status + relevant headers
    res.status(upstream.status);
    const rawCt = upstream.headers.get("content-type") ?? "";
    const cl = upstream.headers.get("content-length");
    const cr = upstream.headers.get("content-range");
    // Some CDNs (notably Google Drive) misidentify MPEG-TS segment files as
    // "image/png" or other non-media types.  ExoPlayer / Stremio on Android
    // reject segments with non-media Content-Types, causing 2-3 second playback
    // failure.  The seg proxy ONLY ever serves video/audio segments, so we
    // force video/MP2T whenever the upstream returns a wrong Content-Type.
    const fixedCt = isMediaContentType(rawCt) ? rawCt : "video/MP2T";
    res.setHeader("Content-Type", fixedCt);
    if (cl) res.setHeader("Content-Length", cl);
    if (cr) res.setHeader("Content-Range", cr);
    res.setHeader("Access-Control-Allow-Origin", "*");

    if (!upstream.body) {
      res.end();
      return;
    }

    // Stream body directly to response without buffering the whole segment
    const reader = upstream.body.getReader();
    const pump = async (): Promise<void> => {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (!res.write(value)) {
          // Backpressure — wait for drain
          await new Promise<void>((resolve) => res.once("drain", resolve));
        }
      }
      res.end();
    };
    await pump();
  } catch (err) {
    req.log?.error({ err }, "seg proxy error");
    if (!res.headersSent) res.status(502).send("proxy error");
  }
}

// ---------------------------------------------------------------------------
// m3u8 rewriting helpers
// ---------------------------------------------------------------------------

/** Resolve a URI from an m3u8 against its base URL. */
function resolveUri(uri: string, base: URL): string {
  if (uri.startsWith("http://") || uri.startsWith("https://")) return uri;
  if (uri.startsWith("//")) return base.protocol + uri;
  if (uri.startsWith("/")) return `${base.protocol}//${base.host}${uri}`;
  const dir = base.href.slice(0, base.href.lastIndexOf("/") + 1);
  return dir + uri;
}

/** Returns true if the URI is an m3u8 playlist (not a media segment). */
function isM3u8Uri(uri: string): boolean {
  try {
    const path = new URL(uri).pathname;
    return path.endsWith(".m3u8") || path.endsWith(".m3u");
  } catch {
    return uri.includes(".m3u8") || uri.includes(".m3u");
  }
}

/** Build a URL that routes a playlist through our m3u8 proxy endpoint. */
function buildM3u8ProxyUrl(
  endpoint: string,
  targetUrl: string,
  referer: string | undefined,
  proxySegments: boolean,
): string {
  const params = new URLSearchParams({
    url: Buffer.from(targetUrl).toString("base64url"),
  });
  if (referer) params.set("referer", Buffer.from(referer).toString("base64url"));
  // Propagate proxyseg so nested playlists also proxy their segments
  if (proxySegments) params.set("proxyseg", "1");
  return `${endpoint}?${params.toString()}`;
}

/** Build a URL that routes a segment through our seg proxy endpoint. */
function buildSegProxyUrl(
  endpoint: string,
  targetUrl: string,
  referer: string | undefined,
): string {
  const params = new URLSearchParams({
    url: Buffer.from(targetUrl).toString("base64url"),
  });
  if (referer) params.set("referer", Buffer.from(referer).toString("base64url"));
  return `${endpoint}?${params.toString()}`;
}

/**
 * Per-CDN Referer overrides for cross-host playlist chains.
 * When a master playlist on host A contains variant/segment URIs on host B,
 * host B may expect a different Referer than host A's caller provided.
 * Listed as [hostname-substring, expected-Referer] pairs.
 *
 * Example: turboviplay.com masters embed turbosplayer.com variants.
 * The master fetch uses Referer: emturbovid.com (the embed origin), but
 * turbosplayer.com sub-playlists and segments require Referer: turboviplay.com.
 */
const CDN_REFERER_OVERRIDES: Array<[match: string, referer: string]> = [
  ["turbosplayer.com", "https://turboviplay.com/"],
];

/**
 * Returns the correct Referer for a given CDN URL, using per-host overrides
 * first, then falling back to the caller-supplied default.
 */
function cdnReferer(url: string, fallback: string | undefined): string | undefined {
  try {
    const host = new URL(url).hostname;
    for (const [match, ref] of CDN_REFERER_OVERRIDES) {
      if (host.includes(match)) return ref;
    }
  } catch { /* ignore */ }
  return fallback;
}

/**
 * Rewrites #EXT-X-MEDIA lines that contain TYPE=AUDIO (in any attribute order)
 * so that Hindi audio tracks (LANGUAGE="hin"/"hi" or NAME contains "Hindi")
 * have DEFAULT=YES / AUTOSELECT=YES, and all other audio tracks have DEFAULT=NO.
 *
 * HLS spec does not mandate attribute order within #EXT-X-MEDIA tags, so we
 * match on the presence of TYPE=AUDIO anywhere in the line rather than requiring
 * it to appear immediately after the tag name.
 */
function setHindiAsDefaultAudio(m3u8: string): string {
  const HINDI = /\b(hin|hi|hindi)\b/i;
  return m3u8
    .split("\n")
    .map((line) => {
      // Match any #EXT-X-MEDIA line that carries TYPE=AUDIO regardless of attribute order
      if (!line.startsWith("#EXT-X-MEDIA:") || !/TYPE=AUDIO\b/i.test(line)) return line;
      const langM = line.match(/LANGUAGE="([^"]*)"/i);
      const nameM = line.match(/NAME="([^"]*)"/i);
      const isHindi =
        HINDI.test(langM?.[1] ?? "") || HINDI.test(nameM?.[1] ?? "");
      const want = isHindi ? "YES" : "NO";
      let out = line;
      if (/DEFAULT=(YES|NO)/i.test(out)) {
        out = out.replace(/DEFAULT=(YES|NO)/gi, `DEFAULT=${want}`);
      } else {
        out += `,DEFAULT=${want}`;
      }
      if (/AUTOSELECT=(YES|NO)/i.test(out)) {
        out = out.replace(/AUTOSELECT=(YES|NO)/gi, `AUTOSELECT=${want}`);
      }
      return out;
    })
    .join("\n");
}

/**
 * Returns true for Content-Types that represent video/audio media data.
 * Used to detect CDNs (e.g. Google Drive) that misidentify .ts segments.
 */
function isMediaContentType(ct: string): boolean {
  const l = ct.toLowerCase();
  return (
    l.startsWith("video/") ||
    l.startsWith("audio/") ||
    l.startsWith("application/octet-stream") ||
    l.startsWith("application/mp4") ||
    l.startsWith("binary/")
  );
}

function rewriteM3u8(
  m3u8: string,
  base: URL,
  m3u8Endpoint: string,
  segEndpoint: string | undefined,
  referer: string | undefined,
  proxySegments: boolean,
): string {
  return m3u8
    .split("\n")
    .map((line) => {
      const trimmed = line.trim();

      if (trimmed.startsWith("#")) {
        // Rewrite URI="..." attributes (EXT-X-MEDIA, EXT-X-KEY, EXT-X-MAP, etc.)
        return line.replace(/URI="([^"]+)"/g, (_, uri) => {
          const abs = resolveUri(uri, base);
          if (isM3u8Uri(abs)) {
            return `URI="${buildM3u8ProxyUrl(m3u8Endpoint, abs, cdnReferer(abs, referer), proxySegments)}"`;
          }
          if (segEndpoint) {
            return `URI="${buildSegProxyUrl(segEndpoint, abs, cdnReferer(abs, referer))}"`;
          }
          return `URI="${abs}"`;
        });
      }

      if (trimmed === "") return line;

      // Non-comment, non-empty line → sub-playlist or segment URI
      const abs = resolveUri(trimmed, base);

      if (isM3u8Uri(abs)) {
        // Sub-playlist: always proxy through our server (CDN session auth)
        return buildM3u8ProxyUrl(m3u8Endpoint, abs, cdnReferer(abs, referer), proxySegments);
      }

      if (segEndpoint) {
        // Segment: proxy through our server (CDN Referer/IP auth on segments)
        return buildSegProxyUrl(segEndpoint, abs, cdnReferer(abs, referer));
      }

      // Segment: return as absolute CDN URL; Stremio fetches directly
      return abs;
    })
    .join("\n");
}
