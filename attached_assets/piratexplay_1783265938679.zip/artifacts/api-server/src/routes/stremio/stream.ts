import type { Request, Response } from "express";
import {
  fetchStreams,
  fetchAnimeMeta,
  fetchStreamsByImdbId,
  fetchStreamsByTmdbId,
  type ContentType,
  type StreamResult,
} from "../../lib/piratexplay.js";

interface StremioStream {
  name: string;
  title: string;
  url?: string;
  externalUrl?: string;
  behaviorHints?: Record<string, unknown>;
}

// Bounded cache (90 sec TTL — short enough that signed CDN URLs stay fresh)
const CACHE_TTL = 90 * 1000;
const CACHE_MAX = 1000;
const cache = new Map<string, { data: StremioStream[]; ts: number }>();

function cacheSet(key: string, data: StremioStream[]) {
  if (cache.size >= CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, { data, ts: Date.now() });
}

function paramStr(v: string | string[]): string {
  return Array.isArray(v) ? (v[0] ?? "") : v;
}

/**
 * CDN hosts that require our server-side HLS proxy for playlists (m3u8).
 * Reasons: relative URIs that need rewriting, and/or session-based CDN auth
 * where the IP fetching sub-playlists must match the IP that fetched the master.
 */
const M3U8_PROXY_HOSTS = [
  // CDN-21 / AWSStream — relative URIs in m3u8
  "as-cdn21.top",
  "awstream.net",
  // Vidmoly CDN — relative URIs in m3u8
  "vmeas.cloud",
  "vidmoly",
  // Filemoon / SprintCDN — session-based CDN auth + relative sub-playlist URIs
  "bysezejataos.com",
  "bysetayico.com",   // gdmirr Byse Frontend mirror
  "moonembd.online",  // gdmirr Byse Frontend mirror
  "moonfeel.online",  // gdmirr Byse Frontend mirror
  "moonfast.online",  // gdmirr Byse Frontend mirror
  "filemoon.sx",
  "filemoon.to",
  "filemoon.in",
  "moona.",
  "sprintcdn",
  "sprint-cdn",
  // Emturbovid resolves to turboviplay.com master playlists with
  // turbosplayer.com quality-variant sub-playlists — both require proxying
  // so sub-playlist fetches come from our IP with the correct Referer.
  "turboviplay.com",
  "turbosplayer.com",
];

/**
 * CDN hosts that ALSO require our server-side proxy for segment (.ts) fetches.
 * These CDNs enforce Referer or IP-session auth on every request, including
 * segments.  Without segment proxying, Stremio fetches segments directly
 * (different IP, no Referer) → CDN returns 403/404 → playback fails after
 * the initial 2-3 second pre-buffer is exhausted.
 */
const SEG_PROXY_HOSTS = [
  "bysezejataos.com",
  "bysetayico.com",   // gdmirr Byse Frontend mirror
  "moonembd.online",
  "moonfeel.online",
  "moonfast.online",
  "filemoon.sx",
  "filemoon.to",
  "filemoon.in",
  "moona.",
  "sprintcdn",
  "sprint-cdn",
  "turboviplay.com",
  "turbosplayer.com",
];

function needsM3u8Proxy(url: string): boolean {
  try {
    const host = new URL(url).hostname;
    return M3U8_PROXY_HOSTS.some((h) => host.includes(h));
  } catch {
    return false;
  }
}

function needsSegProxy(url: string): boolean {
  try {
    const host = new URL(url).hostname;
    return SEG_PROXY_HOSTS.some((h) => host.includes(h));
  } catch {
    return false;
  }
}

/**
 * Build a URL for our server-side HLS m3u8 proxy.
 * When proxySeg is true, adds ?proxyseg=1 so the proxy also routes segment
 * fetches through /proxy/seg (required for CDNs with Referer/IP auth on segs).
 */
function buildProxyUrl(req: Request, cdnUrl: string, referer?: string, proxySeg?: boolean): string {
  const proto =
    (req.headers["x-forwarded-proto"] as string | undefined) ?? req.protocol ?? "https";
  const host =
    (req.headers["x-forwarded-host"] as string | undefined) ??
    (req.headers.host as string | undefined) ??
    "";
  const base = `${proto}://${host}`;

  const params = new URLSearchParams({
    url: Buffer.from(cdnUrl).toString("base64url"),
  });
  if (referer) params.set("referer", Buffer.from(referer).toString("base64url"));
  if (proxySeg) params.set("proxyseg", "1");
  return `${base}/api/stremio/proxy/m3u8?${params.toString()}`;
}

function getRefererForUrl(url: string): string | undefined {
  try {
    const host = new URL(url).hostname;
    if (host.includes("as-cdn21") || host.includes("awstream")) return "https://as-cdn21.top/";
    if (host.includes("emturbo")) return "https://emturbovid.com/";
    if (host.includes("turboviplay")) return "https://emturbovid.com/";
    if (host.includes("turbosplayer")) return "https://turboviplay.com/";
    if (host.includes("vmeas") || host.includes("vidmoly")) return "https://vidmoly.to/";
    if (host.includes("sprintcdn") || host.includes("sprint-cdn")) return "https://bysetayico.com/";
    if (
      host.includes("bysezejataos") ||
      host.includes("bysetayico") ||
      host.includes("moonembd") ||
      host.includes("moonfeel") ||
      host.includes("moonfast") ||
      host.includes("filemoon") ||
      host.includes("moona")
    ) return "https://filemoon.sx/";
  } catch { /* ignore */ }
  return undefined;
}

function streamResultToStremio(s: StreamResult, req: Request): StremioStream | null {
  if (!s.url) return null;

  let finalUrl = s.url;

  if (s.url.includes(".m3u8") && needsM3u8Proxy(s.url)) {
    const referer =
      (s.behaviorHints?.proxyHeaders as { request?: Record<string, string> } | undefined)
        ?.request?.["Referer"] ?? getRefererForUrl(s.url);
    const proxySeg = needsSegProxy(s.url);
    finalUrl = buildProxyUrl(req, s.url, referer, proxySeg);
  }

  return {
    name: s.name,
    title: s.title,
    url: finalUrl,
    behaviorHints: {
      ...s.behaviorHints,
      // Always clear proxyHeaders — our proxy handles all CDN auth server-side.
      proxyHeaders: undefined,
    },
  };
}

/**
 * Parse a pxp stream ID:
 *   pxp:movies:{slug}                    → movie stream
 *   pxp:series:{slug}:{season}:{episode} → episode stream
 */
function parsePxpId(id: string): {
  type: ContentType;
  slug: string;
  season?: number;
  episode?: number;
} | null {
  const parts = id.split(":");
  if (parts.length < 3 || parts[0] !== "pxp") return null;
  const type = parts[1] as ContentType;
  if (type !== "series" && type !== "movies") return null;
  const slug = parts[2];
  if (!slug) return null;

  if (parts.length >= 5) {
    const season = parseInt(parts[3]!, 10);
    const episode = parseInt(parts[4]!, 10);
    if (!isNaN(season) && !isNaN(episode)) {
      return { type, slug, season, episode };
    }
  }
  return { type, slug };
}

/**
 * Parse a Stremio IMDB-style stream ID.
 * Stremio sends IMDB series episodes as:  tt1234567:1:1  (id:season:episode)
 * Movies as: tt1234567
 */
function parseImdbId(raw: string): {
  imdbId: string;
  season?: number;
  episode?: number;
} | null {
  if (!raw.startsWith("tt")) return null;
  const parts = raw.split(":");
  const imdbId = parts[0]!;
  const season = parts[1] !== undefined ? parseInt(parts[1], 10) : undefined;
  const episode = parts[2] !== undefined ? parseInt(parts[2], 10) : undefined;
  return {
    imdbId,
    season: season !== undefined && !isNaN(season) ? season : undefined,
    episode: episode !== undefined && !isNaN(episode) ? episode : undefined,
  };
}

/**
 * Parse a TMDB-style stream ID.
 * Format: tmdb:{id}  (movie)  or  tmdb:{id}:{season}:{episode}  (series)
 */
function parseTmdbId(raw: string): {
  tmdbId: string;
  season?: number;
  episode?: number;
} | null {
  if (!raw.startsWith("tmdb:")) return null;
  const parts = raw.split(":");
  const tmdbId = parts[1];
  if (!tmdbId) return null;
  const season = parts[2] !== undefined ? parseInt(parts[2], 10) : undefined;
  const episode = parts[3] !== undefined ? parseInt(parts[3], 10) : undefined;
  return {
    tmdbId,
    season: season !== undefined && !isNaN(season) ? season : undefined,
    episode: episode !== undefined && !isNaN(episode) ? episode : undefined,
  };
}

export async function streamHandler(req: Request, res: Response) {
  const rawId = paramStr(req.params.id).replace(/\.json$/, "");
  const stremioType = paramStr(req.params.type); // "series" or "movie"

  // ── IMDB / Cinemeta IDs (tt…) ──────────────────────────────────────────────
  if (rawId.startsWith("tt")) {
    const parsed = parseImdbId(rawId);
    if (!parsed) {
      res.json({ streams: [] });
      return;
    }

    const cacheKey = `stream:imdb:${rawId}:${stremioType}`;
    const hit = cache.get(cacheKey);
    if (hit && Date.now() - hit.ts < CACHE_TTL) {
      res.json({ streams: hit.data });
      return;
    }

    try {
      const rawStreams = await fetchStreamsByImdbId(
        stremioType,
        parsed.imdbId,
        parsed.season,
        parsed.episode
      );
      const streams = rawStreams
        .map((s) => streamResultToStremio(s, req))
        .filter((s): s is StremioStream => s !== null);
      cacheSet(cacheKey, streams);
      res.json({ streams });
    } catch (err) {
      req.log?.error({ err }, "IMDB stream fetch error");
      res.json({ streams: [] });
    }
    return;
  }

  // ── TMDB IDs (tmdb:…) ──────────────────────────────────────────────────────
  if (rawId.startsWith("tmdb:")) {
    const parsed = parseTmdbId(rawId);
    if (!parsed) {
      res.json({ streams: [] });
      return;
    }

    const cacheKey = `stream:tmdb:${rawId}:${stremioType}`;
    const hit = cache.get(cacheKey);
    if (hit && Date.now() - hit.ts < CACHE_TTL) {
      res.json({ streams: hit.data });
      return;
    }

    try {
      const rawStreams = await fetchStreamsByTmdbId(
        stremioType,
        parsed.tmdbId,
        parsed.season,
        parsed.episode
      );
      const streams = rawStreams
        .map((s) => streamResultToStremio(s, req))
        .filter((s): s is StremioStream => s !== null);
      cacheSet(cacheKey, streams);
      res.json({ streams });
    } catch (err) {
      req.log?.error({ err }, "TMDB stream fetch error");
      res.json({ streams: [] });
    }
    return;
  }

  // ── pxp: IDs ───────────────────────────────────────────────────────────────
  const parsed = parsePxpId(rawId);
  if (!parsed) {
    res.json({ streams: [] });
    return;
  }

  const cacheKey = `stream:pxp:${rawId}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.ts < CACHE_TTL) {
    res.json({ streams: hit.data });
    return;
  }

  try {
    let { season, episode } = parsed;

    // Bare series ID (no episode info) → get first episode
    if (parsed.type === "series" && season === undefined) {
      try {
        const meta = await fetchAnimeMeta(parsed.type, parsed.slug);
        if (meta && meta.episodes.length > 0) {
          season = meta.episodes[0]!.season;
          episode = meta.episodes[0]!.episode;
        }
      } catch {
        /* fall through */
      }
    }

    const rawStreams = await fetchStreams(parsed.type, parsed.slug, season, episode);
    const streams = rawStreams
      .map((s) => streamResultToStremio(s, req))
      .filter((s): s is StremioStream => s !== null);

    cacheSet(cacheKey, streams);
    res.json({ streams });
  } catch (err) {
    req.log?.error({ err }, "Stream fetch error");
    res.json({ streams: [] });
  }
}
