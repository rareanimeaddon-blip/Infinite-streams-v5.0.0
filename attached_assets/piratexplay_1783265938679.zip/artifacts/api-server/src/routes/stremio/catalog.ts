import type { Request, Response } from "express";
import {
  fetchCategory,
  searchAnime,
  type AnimeCard,
  type CategoryKey,
} from "../../lib/piratexplay.js";

interface StremioMeta {
  id: string;
  type: string;
  name: string;
  poster: string;
  posterShape: string;
  description?: string;
}

function cardToMeta(card: AnimeCard): StremioMeta {
  return {
    id: card.id,
    type: card.type === "movies" ? "movie" : "series",
    name: card.title,
    poster: card.poster,
    posterShape: "poster",
    description: card.rating ? `TMDB ${card.rating}` : undefined,
  };
}

// Bounded LRU-style cache (5 min TTL, max 200 entries)
const CACHE_TTL = 5 * 60 * 1000;
const CACHE_MAX = 200;
const cache = new Map<string, { data: StremioMeta[]; ts: number }>();

function cacheSet(key: string, data: StremioMeta[]) {
  if (cache.size >= CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, { data, ts: Date.now() });
}

async function cachedFetch(
  key: string,
  fn: () => Promise<AnimeCard[]>
): Promise<StremioMeta[]> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.ts < CACHE_TTL) return hit.data;
  const cards = await fn();
  const metas = cards.map(cardToMeta);
  cacheSet(key, metas);
  return metas;
}

function paramStr(v: string | string[]): string {
  return Array.isArray(v) ? (v[0] ?? "") : v;
}

const CATALOG_MAP: Record<
  string,
  { category: CategoryKey; stremioType: "series" | "movie" | null }
> = {
  "pxp-anime":    { category: "anime",    stremioType: "series" },
  "pxp-cartoon":  { category: "cartoon",  stremioType: "series" },
  "pxp-movies":   { category: "movie",    stremioType: "movie" },
  "pxp-popular":  { category: "popular",  stremioType: null },
  "pxp-latest":   { category: "latest",   stremioType: null },
  "pxp-complete": { category: "complete", stremioType: "series" },
  "pxp-ongoing":  { category: "ongoing",  stremioType: "series" },
};

export async function catalogHandler(req: Request, res: Response) {
  const type    = paramStr(req.params.type);
  const id      = paramStr(req.params.id);
  const extraStr = paramStr(
    (req.params as Record<string, string | string[]>)[0] ?? ""
  );

  const extra = Object.fromEntries(
    extraStr
      .split("&")
      .filter(Boolean)
      .map((kv) => kv.split("=").map(decodeURIComponent) as [string, string])
      .filter((pair) => pair.length === 2)
  );

  const search = (extra["search"] ?? "").trim();
  const skip   = parseInt(extra["skip"] ?? "0", 10) || 0;
  const page   = Math.floor(skip / 20) + 1;

  try {
    let metas: StremioMeta[];

    if (search) {
      metas = await cachedFetch(`search:${search}`, () => searchAnime(search));
      metas = metas.filter((m) => m.type === type);
    } else {
      const info = CATALOG_MAP[id];
      if (!info) { res.json({ metas: [] }); return; }

      metas = await cachedFetch(`catalog:${id}:${page}`, () =>
        fetchCategory(info.category, page)
      );

      if (info.stremioType) {
        metas = metas.filter((m) => m.type === info.stremioType);
      } else {
        metas = metas.filter((m) => m.type === type);
      }
    }

    res.json({ metas });
  } catch (err) {
    req.log?.error({ err }, "Catalog fetch error");
    res.json({ metas: [] });
  }
}
