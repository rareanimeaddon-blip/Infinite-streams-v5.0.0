// Stremio addon for a.111477.xyz
// Streams are wrapped via https://pengu.uk/direct/111477-directory/<base64>/<name>
// which 307-redirects to the dark-moon Cloudflare Worker that actually serves
// the file with CORS + Range support (works in Stremio desktop/web/android).

const { addonBuilder, serveHTTP } = require("stremio-addon-sdk");
const fetch = require("node-fetch");

const INDEX_BASE = "https://a.111477.xyz";
const PENGU_BASE = "https://pengu.uk/direct/111477-directory";
const CINEMETA = "https://v3-cinemeta.strem.io";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36";

// ---------- tiny caches ----------
const cache = new Map(); // key -> { at, ttl, val }
function cget(k) {
  const e = cache.get(k);
  if (!e) return null;
  if (Date.now() - e.at > e.ttl) { cache.delete(k); return null; }
  return e.val;
}
function cset(k, val, ttlMs) { cache.set(k, { at: Date.now(), ttl: ttlMs, val }); }

// ---------- helpers ----------
const VIDEO_EXT = /\.(mkv|mp4|avi|m4v|mov|webm|ts|m2ts)$/i;

function normTitle(s) {
  return s
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function pad2(n) { return String(n).padStart(2, "0"); }

function buildStreamUrl(fileUrlAbsolute, fileName) {
  const payload = Buffer.from(JSON.stringify({ url: fileUrlAbsolute })).toString("base64");
  const safeName = encodeURIComponent(fileName).replace(/%20/g, "-");
  return `${PENGU_BASE}/${payload}/${safeName}`;
}

// ---------- directory scraping ----------
// The autoindex embeds every entry as
//   <tr data-entry="true" data-name="..." data-url="..."> ... <td class="size" data-sort="12345">
async function listDir(path) {
  const key = "list:" + path;
  const hit = cget(key);
  if (hit) return hit;

  const url = INDEX_BASE + path;
  const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "text/html" } });
  if (!res.ok) throw new Error(`listDir ${path} -> ${res.status}`);
  const html = await res.text();

  const entries = [];
  const re = /<tr\s+data-entry="true"\s+data-name="([^"]+)"\s+data-url="([^"]+)"[^>]*>[\s\S]*?data-sort="(-?\d+)"/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    const name = m[1].replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"');
    const rel = m[2];
    const size = parseInt(m[3], 10);
    const isDir = rel.endsWith("/");
    entries.push({ name, path: rel, size, isDir });
  }
  cset(key, entries, 10 * 60 * 1000); // 10 minutes
  return entries;
}

// ---------- Cinemeta lookup ----------
async function cinemeta(type, imdb) {
  const key = `meta:${type}:${imdb}`;
  const hit = cget(key);
  if (hit) return hit;
  const r = await fetch(`${CINEMETA}/meta/${type}/${imdb}.json`);
  if (!r.ok) throw new Error("cinemeta " + r.status);
  const j = await r.json();
  cset(key, j.meta, 60 * 60 * 1000);
  return j.meta;
}

// ---------- fuzzy match a directory ----------
function findBestDir(entries, wanted, year) {
  const wn = normTitle(wanted);
  const dirs = entries.filter(e => e.isDir);
  const scored = dirs.map(d => {
    // name typically looks like "Young Sheldon" or "Young Sheldon (2017)"
    const dn = normTitle(d.name.replace(/\/$/, ""));
    let score = 0;
    if (dn === wn) score = 100;
    else if (dn.startsWith(wn + " ")) score = 90;
    else if (dn.startsWith(wn)) score = 80;
    else if (dn.includes(wn)) score = 60;
    if (year && d.name.includes(String(year))) score += 5;
    return { d, score };
  }).filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score);
  return scored.length ? scored[0].d : null;
}

// ---------- quality / codec parsing for stream label ----------
function parseTags(fname) {
  const s = fname;
  const q = (s.match(/\b(2160p|1080p|720p|480p)\b/i) || [])[1] || "";
  const src = (s.match(/\b(Bluray|BluRay|WEB[-. ]?DL|WEBRip|WEB|HDTV|DVDRip|BDRip|Remux)\b/i) || [])[1] || "";
  const vcodec = (s.match(/\b(x265|x264|HEVC|AVC|H\.?264|H\.?265)\b/i) || [])[1] || "";
  const acodec = (s.match(/\b(DTS-HD MA|DTS-HD|DTS|EAC3|AC3|AAC|Atmos|TrueHD|FLAC|Opus)\b/i) || [])[1] || "";
  const ch = (s.match(/\b(7\.1|5\.1|2\.0)\b/) || [])[1] || "";
  const group = (s.match(/-([A-Za-z0-9]+)\.[a-z0-9]+$/) || [])[1] || "";
  return { q, src, vcodec, acodec, ch, group };
}

function humanSize(bytes) {
  if (!bytes || bytes < 0) return "";
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, n = bytes;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(n >= 100 ? 0 : 1)} ${u[i]}`;
}

function toStream(file) {
  const abs = INDEX_BASE + file.path;
  const t = parseTags(file.name);
  const parts = [t.q, t.src, t.vcodec, [t.acodec, t.ch].filter(Boolean).join(" ")].filter(Boolean);
  const title = [parts.join(" • "), humanSize(file.size), t.group && `-${t.group}`]
    .filter(Boolean).join("\n");
  return {
    name: "111477" + (t.q ? " " + t.q : ""),
    title: title || file.name,
    url: buildStreamUrl(abs, file.name),
    behaviorHints: {
      bingeGroup: `_111477_${t.q}_${t.src}_${t.vcodec}`,
      notWebReady: false,
    },
  };
}

// ---------- resolve series episode ----------
async function seriesStreams(imdb, season, episode) {
  const meta = await cinemeta("series", imdb);
  if (!meta) return [];
  const wanted = meta.name;
  const year = (meta.year || (meta.releaseInfo || "")).toString().slice(0, 4);

  const roots = ["/tvs/", "/asiandrama/", "/kdrama/"];
  let showDir = null;
  for (const root of roots) {
    const entries = await listDir(root).catch(() => []);
    const hit = findBestDir(entries, wanted, year);
    if (hit) { showDir = hit.path; break; } // data-url is absolute from site root
  }
  if (!showDir) return [];

  const seasonEntries = await listDir(showDir).catch(() => []);
  const sPad = pad2(season);
  const seasonDir = seasonEntries.find(
    e => e.isDir && /season/i.test(e.name) &&
         (new RegExp(`\\b0*${season}\\b`).test(e.name) || e.name.toLowerCase().includes(`season ${season}`))
  );

  // Candidate files can live in the season subdir OR flat under the show dir.
  const pools = [];
  if (seasonDir) pools.push(await listDir(seasonDir.path).catch(() => []));
  pools.push(seasonEntries);

  const epRe = new RegExp(`(s0*${season}[ ._-]?e0*${episode}\\b)|(\\b${season}x0*${episode}\\b)`, "i");
  const files = [];
  const seen = new Set();
  for (const pool of pools) {
    for (const f of pool) {
      if (f.isDir) continue;
      if (!VIDEO_EXT.test(f.name)) continue;
      if (!epRe.test(f.name)) continue;
      const key = f.path;
      if (seen.has(key)) continue;
      seen.add(key);
      files.push(f);
    }
  }
  // Bigger/higher quality first
  files.sort((a, b) => (b.size || 0) - (a.size || 0));
  return files.map(toStream);
}

// ---------- resolve movie ----------
async function movieStreams(imdb) {
  const meta = await cinemeta("movie", imdb);
  if (!meta) return [];
  const wanted = meta.name;
  const year = (meta.year || (meta.releaseInfo || "")).toString().slice(0, 4);

  const entries = await listDir("/movies/").catch(() => []);
  const hit = findBestDir(entries, wanted, year);
  if (!hit) return [];

  const inside = await listDir(hit.path).catch(() => []);
  let files = inside.filter(e => !e.isDir && VIDEO_EXT.test(e.name));
  if (!files.length) {
    const sub = inside.find(e => e.isDir);
    if (sub) {
      const sub2 = await listDir(sub.path).catch(() => []);
      files = sub2.filter(e => !e.isDir && VIDEO_EXT.test(e.name));
    }
  }
  files.sort((a, b) => (b.size || 0) - (a.size || 0));
  return files.map(toStream);
}

// ---------- addon manifest ----------
const manifest = {
  id: "community.111477.directory",
  version: "1.0.0",
  name: "111477 Directory",
  description:
    "Streams movies and TV episodes from the a.111477.xyz open directory, " +
    "resolved through the pengu.uk / dark-moon worker proxy.",
  types: ["movie", "series"],
  resources: ["stream"],
  catalogs: [],
  idPrefixes: ["tt"],
  behaviorHints: { configurable: false, configurationRequired: false },
};

const builder = new addonBuilder(manifest);

builder.defineStreamHandler(async ({ type, id }) => {
  try {
    if (type === "series") {
      const [imdb, s, e] = id.split(":");
      if (!imdb || !s || !e) return { streams: [] };
      const streams = await seriesStreams(imdb, parseInt(s, 10), parseInt(e, 10));
      return { streams };
    }
    if (type === "movie") {
      const streams = await movieStreams(id);
      return { streams };
    }
    return { streams: [] };
  } catch (err) {
    console.error("stream error", type, id, err.message);
    return { streams: [] };
  }
});

const port = parseInt(process.env.PORT || "7000", 10);
serveHTTP(builder.getInterface(), { port });
console.log(`Addon running: http://127.0.0.1:${port}/manifest.json`);