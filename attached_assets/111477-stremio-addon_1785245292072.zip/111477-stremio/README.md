# 111477 Directory — Stremio Addon

Streams movies and TV episodes directly from the open directory at
`https://a.111477.xyz/`, resolved through the `pengu.uk` → dark-moon
Cloudflare Worker proxy chain (the same pipeline your friend's addon uses).

## How it works

1. Stremio asks for streams for an IMDb id (movie: `tt1234567`, series:
   `tt1234567:S:E`).
2. The addon looks up the title/year on Cinemeta
   (`https://v3-cinemeta.strem.io/meta/...`).
3. It scrapes the matching folder on `a.111477.xyz` (`/tvs/…/Season N/`
   for series, `/movies/Title (year)/` for movies) by parsing the
   `data-name` / `data-url` / `data-sort` attributes in the HTML index.
4. Each matching video file is wrapped as
   `https://pengu.uk/direct/111477-directory/<base64({"url":"<file url>"})>/<name>.mkv`
   which 307-redirects to the actual dark-moon worker that serves the
   file with `Accept-Ranges: bytes` and `Access-Control-Allow-Origin: *`
   — this is what makes it playable in Stremio's Android / desktop / web
   apps.

No API keys or Turnstile solving required — the pengu.uk endpoint accepts
any `a.111477.xyz` URL you pass in the base64 payload.

## Run locally

```
npm install
npm start
```

The addon listens on `http://127.0.0.1:7000/manifest.json`.

Install in Stremio:

1. Open Stremio → Addons → paste `http://127.0.0.1:7000/manifest.json`
   into the top search bar → Install.
2. Play any movie / series episode. If files exist on `a.111477.xyz` you
   will see multiple qualities (2160p / 1080p / 720p, REMUX / BluRay /
   WEBRip, etc.) sorted largest-first.

## Deploy publicly (recommended for phones / TVs)

Any Node.js host works. Beam.new, Render, Fly.io, Railway, a VPS, etc.

- Set `PORT` env var if the platform requires it.
- No secrets needed.
- Once deployed, install via `https://<your-host>/manifest.json`.

## Tested

- `Young Sheldon S01E04` (tt6226232:1:4) → 4 streams incl. the exact
  `WEBRip-1080p EAC3 x264 NTb` file you shared.
- `Oppenheimer` (tt15398776) → 2160p REMUX / 1080p / etc.

## Files

- `addon.js` — Stremio SDK server + directory scraper + URL builder.
- `package.json` — deps: `stremio-addon-sdk`, `node-fetch@2`.

## Known limits

- Only what's actually indexed at `/tvs/`, `/kdrama/`, `/asiandrama/`,
  `/movies/` is discoverable. `/misc/` is ignored.
- Fuzzy title match is basic — very generic titles (`Alone`, `24`) can
  mis-match. Add a whitelist or IMDb-ID mapping if you need perfect
  accuracy.
- Cached for 10 min in memory to be a good citizen; restart to clear.